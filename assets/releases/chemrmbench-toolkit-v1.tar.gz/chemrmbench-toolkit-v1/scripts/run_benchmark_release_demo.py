"""Reproduce the public CPU contract matrix; zero native/model/training jobs."""
import argparse
import json
from pathlib import Path

from chemrm.papera.benchmark_release_v1 import freeze_task_contract,run_release,verify_release
from chemrm.papera.manifest import ManifestTask,write_task_manifest
from chemrm.papera.semantics import SemanticGrammar,generate_semantic_tasks
from chemrm.papera.thermal_dose import make_thermal_dose_task


def run_demo(out):
    root=Path(out).absolute();root.mkdir(parents=True,exist_ok=False)
    source=Path(__file__).resolve().parents[1]
    grammar=SemanticGrammar.from_dict(json.loads((source/'pilot/paperA/task_grammar_v2.json').read_text()))
    entries=[]
    for family,count in zip(grammar.families,(12,8,4)):
        tasks=generate_semantic_tasks(grammar,split=family.split,count=count,seed=19,novelty_axes=family.novelty_axes)
        entries.extend(ManifestTask(t,'grammar:'+grammar.grammar_id,grammar.sha256) for t in tasks)
    manifest=write_task_manifest(entries,root/'graph/tasks',manifest_id='public-graph-contract-complete-v2',
                                 provenance={'kind':'public_semantic_grammar','grammar_id':grammar.grammar_id,
                                             'grammar_sha256':grammar.sha256,'grammar':grammar.to_dict()})
    rows=[]
    def collect(manifest,backend,target,mode='reference',steps=1000):
        path=run_release(manifest_dir=manifest,backend=backend,policy=mode,out_dir=root/target,
                         release_id=target.replace('/','-'),max_steps=steps)
        result=verify_release(path)
        rows.append(dict(path=str(path.relative_to(root)),backend=backend,policy=mode,**result))
    for mode in ('reference','abstain'):collect(manifest,'graph-contract','graph/'+mode,mode,100)
    for seed in (0,1,19,35,71):
        manifest=freeze_task_contract(root/f'timing/seed{seed}/tasks',seed=seed)
        for mode in ('reference','abstain'):
            collect(manifest,'task-contract',f'timing/seed{seed}/'+mode,mode,200)
    task=make_thermal_dose_task(seed=19)
    manifest=write_task_manifest((ManifestTask(task,'synthetic-uncalibrated','a'*64),),
                                 root/'thermal/tasks',manifest_id='thermal-contract-v1')
    for mode in ('reference','abstain','high-rate'):
        collect(manifest,'thermal-dose','thermal/'+mode,mode,1000)
    total=sum(r['episodes_replayed'] for r in rows)
    report=dict(schema='chemrm-contract-matrix-v1',status='PASS_ALL_RELEASES_INDEPENDENTLY_REPLAYED',
                releases=rows,episodes=total,release_count=len(rows),
                native_workers=0,model_calls=0,training_jobs=0,scientific_admission=False,
                formal_M1_admission=False,full_benchmark_pass=False,
                scope='CPU software contracts and incorrect controls; seeds/splits do not establish native statistical evidence')
    (root/'matrix.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
    parser.add_argument('--out',required=True)
    result=run_demo(parser.parse_args().out)
    print(json.dumps({k:v for k,v in result.items() if k!='releases'},ensure_ascii=False,indent=2))
