"""Package owned source and already-replayed CPU fixtures without native raw data."""
import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

from chemrm.papera.benchmark_release_v1 import verify_release


def package(matrix, native_audit, output):
    source=Path(__file__).resolve().parents[1]
    matrix=Path(matrix);out=Path(output);out.mkdir(parents=True,exist_ok=False)
    report=json.loads((matrix/'matrix.json').read_text())
    for row in report['releases']:
        result=verify_release(matrix/row['path'],expected_sha256=row['release_sha256'])
        if result['episodes_replayed']!=row['episodes_replayed']:raise ValueError('matrix cardinality differs')
    toolkit=out/'chemrmbench-toolkit-v1';toolkit.mkdir()
    def copy_tree(root,target):
        for path in root.rglob('*'):
            if path.is_file() and '__pycache__' not in path.parts and path.suffix in ('.py','.yaml'):
                if path.is_symlink():raise ValueError('source symlink refused')
                dest=target/path.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,dest)
    copy_tree(source/'chemrm',toolkit/'chemrm')
    for name in ['run_benchmark_release_demo.py','package_benchmark_release.py']:
        dest=toolkit/'scripts'/name;dest.parent.mkdir(exist_ok=True);shutil.copy2(source/'scripts'/name,dest)
    for name in ['test_benchmark_release_v1.py','test_native_catalog_v1.py','test_benchmark_release_cli_v1.py']:
        dest=toolkit/'tests'/name;dest.parent.mkdir(exist_ok=True);shutil.copy2(source/'tests'/name,dest)
    dest=toolkit/'pilot/paperA/task_grammar_v2.json';dest.parent.mkdir(parents=True)
    shutil.copy2(source/'pilot/paperA/task_grammar_v2.json',dest)
    shutil.copy2(source/'chemrm/papera/BENCHMARK_RELEASE.md',toolkit/'README.md')
    for name in ['BENCHMARK_READINESS_CURRENT_cn.md','ADR_BENCHMARK_RELEASE_V1.md','BENCHMARK_RECOVERED_SOURCE_V1.json']:
        shutil.copy2(source/'proposal'/name,toolkit/name)
    (toolkit/'requirements.txt').write_text(''.join(name+'=='+importlib.metadata.version(name)+'\n'
                                                 for name in ('numpy','PyYAML','pytest')))
    shutil.copytree(matrix,toolkit/'examples/contract-matrix')
    shutil.copy2(native_audit,toolkit/'examples/native_catalog_audit.json')
    commit=subprocess.run(['git','rev-parse','HEAD'],cwd=source,capture_output=True,text=True,check=True).stdout.strip()
    (toolkit/'BUILD.json').write_text(json.dumps(dict(schema='chemrm-toolkit-build-v1',source_commit=commit,
                                                    native_raw_or_future_actions_included=False,
                                                    scientific_admission=False,full_benchmark_pass=False),indent=2)+'\n')
    archive=out/'chemrmbench-toolkit-v1.tar.gz'
    with tarfile.open(archive,'w:gz') as tar:tar.add(toolkit,arcname=toolkit.name)
    proof=dict(archive=archive.name,bytes=archive.stat().st_size,
               sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),source_commit=commit,
               releases=report['release_count'],episodes=report['episodes'],native_raw_included=False)
    (out/'toolkit.json').write_text(json.dumps(proof,indent=2)+'\n')
    return proof


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
    p.add_argument('--matrix',required=True);p.add_argument('--native-audit',required=True);p.add_argument('--out',required=True)
    a=p.parse_args();print(json.dumps(package(a.matrix,a.native_audit,a.out),indent=2))
