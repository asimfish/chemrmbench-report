"""Release integrity, independent regrading and whole-batch refusal semantics."""
import hashlib
import json
from dataclasses import replace
from pathlib import Path

import pytest

from chemrm.papera.benchmark_release_v1 import run_release, verify_release, freeze_task_contract
from chemrm.papera.manifest import ManifestTask, write_task_manifest
from chemrm.papera.semantics import SemanticGrammar, generate_semantic_tasks
from chemrm.papera.thermal_dose import make_thermal_dose_task


def graph_manifest(tmp_path, count=2):
    grammar = SemanticGrammar.from_dict(json.loads(Path('pilot/paperA/task_grammar_v2.json').read_text()))
    tasks = generate_semantic_tasks(grammar, split='closed', count=count, seed=19, novelty_axes=())
    return write_task_manifest(tuple(ManifestTask(t, 'grammar:'+grammar.grammar_id, grammar.sha256)
                                    for t in tasks), tmp_path/'manifest', manifest_id='release-fixture',
                               provenance={'kind':'public_semantic_grammar','grammar_id':grammar.grammar_id,
                                           'grammar_sha256':grammar.sha256,'grammar':grammar.to_dict()})


def launch(tmp_path, **kwargs):
    return run_release(manifest_dir=graph_manifest(tmp_path), backend='graph-contract',
                       out_dir=tmp_path/'out', release_id='fixture-v1', **kwargs)


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, sort_keys=True, allow_nan=False)+'\n')


def reseal(root):
    """Repair byte hashes, so negative tests exercise semantic checks too."""
    index=read(root/'INDEX.json')
    for name in index['files']:
        raw=(root/name).read_bytes()
        index['files'][name]={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
    write(root/'INDEX.json',index)
    write(root/'COMMITTED.json',{'index_sha256':hashlib.sha256((root/'INDEX.json').read_bytes()).hexdigest()})


def test_success_and_offline_replay_never_construct_world_or_policy(tmp_path, monkeypatch):
    root=launch(tmp_path)
    summary=read(root/'summary.json')
    assert summary['splits']['closed']['episodes']==2
    assert summary['splits']['closed']['successful']==2
    assert summary['admission']=={'scientific_admission':False,'training_admission':False,
                                  'formal_M1_admission':False,'full_benchmark_pass':False}
    monkeypatch.setattr('chemrm.papera.benchmark_release_v1.build_manifest_cases',
                        lambda *_:pytest.fail('offline reader constructed a world'))
    result=verify_release(root)
    assert result['status']=='PASS_RELEASE_INTEGRITY_AND_REPLAY'
    assert result['episodes_replayed']==2


def test_abstention_is_preserved_failure_and_still_correctly_verified(tmp_path):
    root=launch(tmp_path, policy='abstain', max_steps=3)
    summary=read(root/'summary.json')
    assert summary['splits']['closed']=={'episodes':2,'valid':0,'successful':0}
    assert len(read(root/'episodes.json')['episodes'])==2
    assert verify_release(root)['status']=='PASS_RELEASE_INTEGRITY_AND_REPLAY'


@pytest.mark.parametrize('field,value',[('max_steps',True),('max_steps',0),('max_steps',100001),
                                      ('release_id','../escape'),('backend','isaac-unregistered'),
                                      ('policy','oracle')])
def test_bad_configuration_refused_before_output(tmp_path,field,value):
    manifest=graph_manifest(tmp_path)
    args=dict(manifest_dir=manifest,backend='graph-contract',out_dir=tmp_path/'out')
    args[field]=value
    with pytest.raises(ValueError):run_release(**args)
    assert not (tmp_path/'out').exists()


def test_whole_manifest_preflight_before_any_run(tmp_path, monkeypatch):
    from chemrm.papera.manifest import load_task_manifest
    manifest=graph_manifest(tmp_path,count=1)
    entry=load_task_manifest(manifest).tasks[0]
    # Keep the mixed fixture valid as a legacy public manifest; a v2 row
    # without its embedded semantic grammar is rejected before backend preflight.
    entry=replace(entry,task=replace(entry.task,public_spec_version='paper-a-public-grammar-1',metadata={}))
    mixed=write_task_manifest((entry,ManifestTask(replace(make_thermal_dose_task(),task_id='zzz'),
                                                'thermal','a'*64)),tmp_path/'mixed',manifest_id='mixed')
    monkeypatch.setattr('chemrm.papera.benchmark_release_v1.run_episode',
                        lambda *_args,**_kwargs:pytest.fail('preflight called an episode'))
    with pytest.raises(ValueError):run_release(manifest_dir=mixed,backend='graph-contract',out_dir=tmp_path/'out')
    assert not (tmp_path/'out').exists()


def test_source_manifest_may_disappear_after_run_and_output_cannot_be_overwritten(tmp_path):
    import shutil
    root=launch(tmp_path)
    shutil.rmtree(tmp_path/'manifest')
    assert verify_release(root)['episodes_replayed']==2
    with pytest.raises(FileExistsError):
        run_release(manifest_dir=root/'tasks',backend='graph-contract',out_dir=root)


@pytest.mark.parametrize('mutation',['summary','verdict','terminal','task_identity','policy','source','admission'])
def test_resealed_semantic_corruption_cannot_become_success(tmp_path,mutation):
    root=launch(tmp_path)
    episode=root/'episodes/task-00000'
    if mutation=='summary':
        p=root/'summary.json';d=read(p);d['splits']['closed']['successful']=0
    elif mutation=='verdict':
        p=episode/'verdict.json';d=read(p);d['pass_vector']['time']=False
        write(p,d)
        artifacts=read(episode/'artifacts.json');raw=p.read_bytes()
        artifacts['files']['verdict.json']={'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
        write(episode/'artifacts.json',artifacts)
        meta=read(episode/'manifest.json');meta['artifact_index_sha256']=hashlib.sha256((episode/'artifacts.json').read_bytes()).hexdigest()
        write(episode/'manifest.json',meta)
    elif mutation=='terminal':
        p=episode/'execution.json';d=read(p);d['end_time_s']=-1
    elif mutation=='task_identity':
        p=root/'episodes.json';d=read(p);d['episodes'][0]['task_sha256']='f'*64
    elif mutation=='policy':
        p=episode/'manifest.json';d=read(p);d['policy_id']='privileged-oracle'
    elif mutation=='source':
        p=root/'source.json';d=read(p);d['files']['chemrm/events.py']='0'*64
    else:
        p=root/'summary.json';d=read(p);d['admission']['scientific_admission']=True
    write(p,d);reseal(root)
    with pytest.raises(ValueError):verify_release(root)


@pytest.mark.parametrize('mutation',['missing','extra','symlink','root_symlink','duplicate','nonfinite','path_escape'])
def test_ambiguous_or_unsafe_artifacts_refuse_without_execution(tmp_path,mutation):
    root=launch(tmp_path)
    if mutation=='missing':(root/'summary.json').unlink()
    elif mutation=='extra':(root/'extra.json').write_text('{}')
    elif mutation=='symlink':
        p=root/'summary.json';target=tmp_path/'outside';p.rename(target);p.symlink_to(target)
    elif mutation=='root_symlink':
        link=tmp_path/'link';link.symlink_to(root,target_is_directory=True);root=link
    elif mutation=='duplicate':
        (root/'COMMITTED.json').write_text('{"index_sha256":"a","index_sha256":"b"}')
    elif mutation=='nonfinite':
        (root/'summary.json').write_text('{"number":NaN}')
        reseal(root)
    else:
        p=root/'INDEX.json';d=read(p);d['files']['../outside']={'bytes':0,'sha256':'a'*64};write(p,d)
        write(root/'COMMITTED.json',{'index_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
    with pytest.raises(ValueError):verify_release(root)


def test_external_digest_pin_detects_resealing(tmp_path):
    root=launch(tmp_path)
    expected=hashlib.sha256((root/'COMMITTED.json').read_bytes()).hexdigest()
    assert verify_release(root,expected_sha256=expected)['episodes_replayed']==2
    with pytest.raises(ValueError):verify_release(root,expected_sha256='0'*64)


def test_yaml_timing_tasks_are_frozen_and_replayed(tmp_path):
    manifest=freeze_task_contract(tmp_path/'manifest',seed=19)
    root=run_release(manifest_dir=manifest,backend='task-contract',out_dir=tmp_path/'out')
    result=verify_release(root)
    assert result['episodes_replayed']==3
    assert read(root/'summary.json')['splits']['closed']['successful']==3
    assert read(root/'preflight.json')['capabilities']['calibrated_chemistry']=='UNEVALUATED'


def test_yaml_task_cannot_invent_a_duration_or_split(tmp_path):
    from chemrm.papera.manifest import load_task_manifest
    manifest=freeze_task_contract(tmp_path/'manifest',seed=19)
    original=load_task_manifest(manifest).tasks[0]
    task=replace(original.task,metadata={**original.task.metadata,'instruction':{'wait_D_s':1}})
    altered=write_task_manifest((replace(original,task=task),),tmp_path/'altered',manifest_id='altered')
    with pytest.raises(ValueError):run_release(manifest_dir=altered,backend='task-contract',out_dir=tmp_path/'out')
    assert not (tmp_path/'out').exists()


def test_thermal_backend_replays_actual_quantity_time_safety_vector(tmp_path):
    task=make_thermal_dose_task(seed=19)
    manifest=write_task_manifest((ManifestTask(task,'synthetic','a'*64),),tmp_path/'manifest',manifest_id='thermal')
    root=run_release(manifest_dir=manifest,backend='thermal-dose',out_dir=tmp_path/'out')
    assert verify_release(root)['episodes_replayed']==1
    row=read(root/'episodes/task-00000/verdict.json')
    assert row['pass_vector']['quantity'] is True and row['pass_vector']['time'] is True


def test_high_rate_control_is_replayed_as_failure_not_discarded(tmp_path):
    task=make_thermal_dose_task(seed=19)
    manifest=write_task_manifest((ManifestTask(task,'synthetic','a'*64),),tmp_path/'manifest',manifest_id='thermal')
    root=run_release(manifest_dir=manifest,backend='thermal-dose',policy='high-rate',out_dir=tmp_path/'out')
    result=verify_release(root)
    assert result['episodes_replayed']==1
    assert result['summary']['splits']['closed']['successful']==0
    assert read(root/'episodes/task-00000/verdict.json')['pass_vector']['safety'] is False


def test_integer_verdict_is_rejected_even_if_equivalent_to_boolean(tmp_path):
    root=launch(tmp_path)
    p=root/'summary.json';d=read(p);d['admission']['scientific_admission']=0
    write(p,d);reseal(root)
    with pytest.raises(ValueError):verify_release(root)


def test_whole_release_action_budget_refused_before_output(tmp_path):
    with pytest.raises(ValueError,match='total action budget'):
        run_release(manifest_dir=graph_manifest(tmp_path,12),backend='graph-contract',
                    max_steps=100000,out_dir=tmp_path/'out')
    assert not (tmp_path/'out').exists()
