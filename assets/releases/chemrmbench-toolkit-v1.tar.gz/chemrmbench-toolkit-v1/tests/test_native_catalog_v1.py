import hashlib
import json
from pathlib import Path
import pytest
from chemrm.papera.native_catalog_v1 import audit_native_catalog


def fixture(tmp_path,mutation=None):
    data=dict(full_benchmark_pass=False,formal_M1_admission=False,training_admission=False,
              stage_coverage=[dict(cold_restart_verified=False)],public_asset_sha256={})
    assets={
        'video.mp4':b'fixture bytes; decode is not requested',
        'poster.jpg':b'fixture poster',
        'frames.json':[dict(index=0,native_elapsed_s=0.0,video_pts_s=0.0,source_command_cursor=20,
                            task_time_s=10.0,image_sha256='a'*64)],
        'states.json':dict(schema='chemrm-public-physical-stage-projection-v1',hidden_solver_state_restored=False,
                           stages=[dict(stage_id='release',archive_state_sha256='b'*64,source_command_cursor=30,
                                        physical_restart_admitted=False,registered_entities=1,
                                        bodies=[dict(id='bottle',root_state=[0.0]*13)],articulations=[])]),
        'receipt.json':dict(status='DEVELOPMENT_FIXTURE')}
    run=dict(id='fixture',video='video.mp4',poster='poster.jpg',frame_index='frames.json',stage_states='states.json',
             receipt='receipt.json',video_frames=1,video_fps=12,video_duration_s=1/12,task_time_offset_s=10.0,
             stages=[dict(id='release',archive_state_sha256='b'*64,source_end_cursor=30,registered_entities=1)])
    if mutation=='clock':assets['frames.json'][0]['task_time_s']=0.0
    if mutation=='registry':assets['states.json']['stages'][0]['registered_entities']=2
    if mutation=='restart':assets['states.json']['stages'][0]['physical_restart_admitted']=True
    if mutation=='archive':run['stages'][0]['archive_state_sha256']='c'*64
    for name,value in assets.items():
        blob=value if isinstance(value,bytes) else json.dumps(value).encode()
        (tmp_path/name).write_bytes(blob);data['public_asset_sha256'][name]=hashlib.sha256(blob).hexdigest()
    run['video_sha256']=data['public_asset_sha256']['video.mp4']
    data['runs']=[run]
    if mutation=='video':run['video_sha256']='f'*64
    if mutation=='duplicate':data['runs'].append(run)
    if mutation=='promotion':data['full_benchmark_pass']=True
    if mutation=='path':run['receipt']='../secret'
    (tmp_path/'data').mkdir()
    blob=json.dumps(data).encode();(tmp_path/'data/benchmark-system.json').write_bytes(blob)
    return hashlib.sha256(blob).hexdigest()


def test_native_associations_are_checked_without_promoting_scope(tmp_path):
    result=audit_native_catalog(tmp_path,expected_manifest_sha256=fixture(tmp_path))
    assert result['assets_verified']==5 and result['stage_projections']==1
    assert result['full_video_decode'] is False and result['ordinary_restart_boundaries']==0
    assert result['full_benchmark_pass'] is False


@pytest.mark.parametrize('mutation',['clock','registry','restart','archive','video','duplicate','promotion','path'])
def test_rehashed_false_associations_still_fail(tmp_path,mutation):
    expected=fixture(tmp_path,mutation)
    with pytest.raises(ValueError):audit_native_catalog(tmp_path,expected_manifest_sha256=expected)


def test_native_manifest_requires_external_identity(tmp_path):
    fixture(tmp_path)
    with pytest.raises(ValueError):audit_native_catalog(tmp_path,expected_manifest_sha256='0'*64)
