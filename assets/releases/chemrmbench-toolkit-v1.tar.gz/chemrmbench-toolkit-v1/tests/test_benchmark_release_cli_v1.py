import json
from chemrm.papera.run_benchmark_release import main


def test_documented_commands_distinguish_episode_failure_from_verification(tmp_path,capsys):
    tasks=tmp_path/'tasks';release=tmp_path/'release'
    assert main(['freeze-tasks','--out',str(tasks),'--seed','19'])==0
    assert json.loads(capsys.readouterr().out)['status']=='FROZEN_TASK_CONTRACT'
    assert main(['run','--manifest',str(tasks),'--backend','task-contract','--policy','abstain',
                 '--max-steps','3','--out',str(release)])==0
    result=json.loads(capsys.readouterr().out)
    assert result['summary']['splits']['closed']['successful']==0
    assert main(['verify',str(release),'--expected-sha256',result['release_sha256']])==0
    capsys.readouterr()
    (release/'summary.json').write_text('{}')
    assert main(['verify',str(release)])==2
    assert json.loads(capsys.readouterr().out)['status']=='REFUSED_RELEASE'
