# ADR: executable benchmark releases

Status: accepted for contract development; no new native experiment authorized by a release flag.

## Context and decision

SafeLab contributes environment assets, irreversible physical consequences and syntax,
geometry, causality and simulation checks. ChemRMBench adds event-memory interventions,
operation-time measurement and stage-preserving continuation. These components already
exist separately; another one-off experiment script would not make them a reusable benchmark.

Two candidates were considered:

| Candidate | Benefit | Cost / failure mode |
| --- | --- | --- |
| Extend the versioned V100 native collector | Immediate reuse of its GPU capsule | Couples releases to one private fixed-input diagnostic; cannot certify a memory benchmark |
| Compose existing frozen task manifests, world/policy protocols and independent verifiers | Reuses task semantics and preserves old evidence; offline replay needs no simulator | Requires a strict batch artifact format and explicit backend capability limits |

Choose composition. JSON/JSONL remain the canonical public task and trace boundaries.
Existing world, frozen policy and read-only verifier protocols remain unchanged. A small
allowlisted factory supports graph-contract, YAML task-contract and synthetic thermal-dose
backends; unsupported backends fail before output creation. No dynamic imports or caller-set
calibration/admission booleans are accepted.

## Release boundary

1. Read the exact frozen manifest bytes and preflight every task/backend and budget.
2. Copy those bytes into a new output directory. Never regenerate tasks during execution.
3. Run frozen reference or declared abstention controls through the existing runner.
4. Preserve each ordinary evidence bundle plus terminal execution state.
5. An offline reader reconstructs traces, replays the original verifier and recomputes the
   split summary. A failed episode may be correctly verified; it stays in the denominator.
6. Seal the full file inventory, source identity and a final commit marker. A caller may pin
   the marker digest externally; local hashes alone are not publisher authentication.

The reader accepts bounded regular files only, refuses ambiguous JSON and path escapes,
and never invokes a policy, world, archived code, model or simulator. Source identity
must match the installed reader implementation before interpretation.

Native scene/video/stage evidence is separately indexed from existing original receipts.
Declared stage metadata alone cannot grant restart admission. Videos must bind actual bytes,
frame maps and source receipts; derived comparison videos remain distinct from native runs.

## Admission and compatibility

All current execution backends are development contracts or uncalibrated diagnostics.
`scientific_admission`, `training_admission`, `formal_M1_admission` and
`full_benchmark_pass` remain false regardless of reference success. SafeLab geometry,
native dynamics, pixel leakage/detectability, calibrated chemistry and independent task
sampling each require their own evidence. V100 remains one private diagnostic; ordinary
cold coverage stays 1/8. No historical file, gate or verdict is rewritten.

This adds a new release API/CLI; it does not change legacy bundle or collector formats.
The persistent SSD worktree replaces the vanished temporary checkout. Commits and NAS
evidence retain the reproducible source; no GPU work is repeated for workspace recovery.
