"""Tabulate Q0a runs (development or diagnostic) from their summary.json files.

Example: python3 -m chemrm.paperb.summarize pilot/paperB/q0a/dev_seed0_n1024_e60 pilot/paperB/q0a_diag/*
"""
import json
from pathlib import Path
import sys

import numpy as np


def run_table(run_dir):
    run = Path(run_dir)
    manifest = json.loads((run / 'manifest.json').read_text())
    summary = json.loads((run / 'summary.json').read_text())
    training = json.loads((run / 'training.json').read_text())
    label = (f"n={manifest['args']['n_train']} e={manifest['args']['epochs']} oracle={manifest.get('oracle_training', False)} "
             f"w={manifest.get('act_weight', 10):g} band={manifest.get('band_s', 0.75)}")
    rows = []
    for cell in manifest.get('cells', list(training)):
        fixed = [r for r in summary if r['cadence'] == 'none' and r['cell'] == cell]
        tight = [r for r in fixed if 'tight' in r['stratum']]
        relaxed = [r for r in fixed if 'relaxed' in r['stratum']]
        by_eta = {eta: np.mean([r['goal'] for r in tight if r['stratum'].endswith(eta)]) for eta in ('0.30', '0.15', '0.08')}
        rate_err = [r for r in summary if r['cadence'] == 'rate_error' and r['cell'] == cell and 'tight' in r['stratum']]
        rows.append({'run': run.name, 'cell': cell, 'setting': label, 'loss': training[cell]['loss'][-1],
                     'relaxed_sr': np.mean([r['goal'] for r in relaxed]), 'tight_sr': np.mean([r['goal'] for r in tight]),
                     **{f'tight_{k}': v for k, v in by_eta.items()},
                     'tight_never_acted': np.mean([r['never_acted'] for r in tight]),
                     'tight_median_p_target': np.median([r['median_p_target_in_window'] for r in tight])
                     if tight and tight[0].get('median_p_target_in_window') is not None else float('nan'),
                     'tight_sr_rate_error': np.mean([r['goal'] for r in rate_err])})
    return rows


def main(argv):
    rows = [r for d in argv for r in run_table(d)]
    head = ['run', 'cell', 'setting', 'final loss', 'relaxed SR', 'tight SR', '?=0.30', '?=0.15', '?=0.08',
            'tight never acted', 'tight median max P(target) in window', 'tight SR under rate_error']
    print('| ' + ' | '.join(head) + ' |')
    print('|' + '---|' * len(head))
    for r in rows:
        vals = [r['run'], r['cell'], r['setting'], f"{r['loss']:.4f}", f"{r['relaxed_sr']:.3f}", f"{r['tight_sr']:.3f}",
                f"{r['tight_0.30']:.3f}", f"{r['tight_0.15']:.3f}", f"{r['tight_0.08']:.3f}",
                f"{r['tight_never_acted']:.3f}", f"{r['tight_median_p_target']:.3f}", f"{r['tight_sr_rate_error']:.3f}"]
        print('| ' + ' | '.join(vals) + ' |')


if __name__ == '__main__':
    main(sys.argv[1:])
