"""Run the Q0a full-prefix distillation development control (NOT OPD or preregistered).

Example: python3 -m chemrm.paperb.run_q0a --out pilot/paperB/q0a/dev --n-train 256 --epochs 12

Diagnostic flags (results must stay out of Track A/B competition scores):
  --oracle both      positive control: students also read the identity/timing oracle channels
  --act-weight W     loss weight of act ticks in tight episodes (default 10, as in Gate 0)
  --band-s B         teacher label band width in seconds, or 'full' for the whole late half
                     of the referee window (default 0.75)
  --cells RA,RB      train a subset of cells
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import subprocess
import time

import numpy as np
import torch
import torch.nn.functional as F

from chemrm.core_family import T_POUR
from chemrm.gate0.env import (SKILL_TIME, STRATA, build_observations, cell_arrays, draw_episode_batch,
                             first_action, judge, make_tick_times, parse_stratum)
from chemrm.gate0.policies import n_parameters
from chemrm.paperb.q0a import (CELLS, DEFAULT_BAND_S, make_student, student_observations,
                               teacher_sequences)

CADENCES = {'none': 0., 'tick_jitter': .4, 'rate_error': .15}


def dataset(n, seed, cadence, stratum=None, band_s=DEFAULT_BAND_S, oracle=False):
    """Paired episodes, tick times, teacher labels. `oracle=True` switches both oracle
    channels on in the observations (diagnostic positive control); the teacher ignores
    them either way, so labels are identical."""
    eps = draw_episode_batch(n, seed)
    ticks = make_tick_times(n, 400, cadence, CADENCES[cadence], seed + 10_000)
    if stratum is None:
        rng = np.random.default_rng(seed + 20_000)
        names = [STRATA[i] for i in rng.integers(len(STRATA), size=n)]
        factors = [parse_stratum(s) for s in names]
        tr, ti, eta = (np.array([f[j] if f[j] is not None else 0 for f in factors]) for j in range(3))
        tr, ti = tr.astype(bool), ti.astype(bool)
    else:
        tr, ti, eta, _, _ = cell_arrays(n, stratum, 'none')
    on = np.full(n, bool(oracle))
    x = build_observations(eps, tr, ti, on, on, True, ticks)
    labels = teacher_sequences(x, eta, band_s)
    return eps, ticks, ti, eta, x, labels


def admissible_window(eps, ticks, tight, eta):
    """(N, T) mask of ticks at which acting on the target flask would satisfy the referee."""
    landing = ticks + SKILL_TIME[eps.flask][:, None]
    target = (eps.t_a + eps.d)[:, None]
    in_tight = np.abs(landing - target) <= (eta * eps.d)[:, None]
    in_relaxed = landing >= (eps.t_a + T_POUR)[:, None]
    return np.where(tight[:, None], in_tight, in_relaxed)


def score(eps, ticks, tight, eta, actions, probs=None):
    """Referee rows; with `probs` (N, T, A) adds sub-threshold readiness read-outs."""
    step, flask = first_action(actions)
    outcome = judge(eps, tight, eta, step, flask, ticks)
    if probs is not None:
        window = admissible_window(eps, ticks, tight, eta)
        p_target = probs[np.arange(len(eps))[:, None], np.arange(probs.shape[1])[None, :], 1 + eps.flask[:, None]]
        p_target_in_window = np.where(window, p_target, 0.).max(axis=1)
        p_act_peak = (1. - probs[..., 0]).max(axis=1)
    rows = []
    for i in range(len(eps)):
        added = bool(outcome['added'][i])
        error = float(outcome['t_b'][i] - eps.t_a[i] - eps.d[i]) if added and tight[i] else None
        row = {k: bool(outcome[k][i]) for k in ('goal', 'protocol', 'time', 'safety', 'added')} | {
            'episode_index': i, 'act_step': int(step[i]), 'act_flask': int(flask[i]),
            't_a': float(eps.t_a[i]), 'd': float(eps.d[i]), 'target_flask': int(eps.flask[i]),
            't_b': float(outcome['t_b'][i]) if added else None, 'error_s': error}
        if probs is not None:
            row |= {'p_target_in_window': float(p_target_in_window[i]), 'p_act_peak': float(p_act_peak[i])}
        rows.append(row)
    return rows


def train_cell(cell, data, seed, epochs, batch, act_weight=10., oracle=False, clock_encoding='raw'):
    _, _, tight, _, x, labels = data
    torch.manual_seed(seed)
    model = make_student(cell)
    features = torch.from_numpy(student_observations(x, cell, oracle, clock_encoding))
    target = torch.from_numpy(labels)
    weights = torch.from_numpy(np.where((labels > 0) & tight[:, None], act_weight, 1.).astype('float32'))
    opt = torch.optim.Adam(model.parameters(), lr=.001)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs, eta_min=.00005)
    generator = torch.Generator().manual_seed(seed)
    history = []
    started = time.monotonic()
    for _ in range(epochs):
        order = torch.randperm(len(x), generator=generator)
        total = 0.
        for offset in range(0, len(x), batch):
            idx = order[offset:offset + batch]
            logits = model(features[idx])
            loss_tick = F.cross_entropy(logits.flatten(0, 1), target[idx].flatten(), reduction='none')
            w = weights[idx].flatten()
            loss = (loss_tick * w).sum() / w.sum()
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5)
            opt.step()
            total += loss.item() * len(idx)
        sched.step()
        history.append(total / len(x))
    return model.eval(), {'loss': history, 'wall_s': time.monotonic() - started,
                          'parameters': n_parameters(model), 'gradient_steps': epochs * int(np.ceil(len(x) / batch))}


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out', required=True)
    p.add_argument('--n-train', type=int, default=256)
    p.add_argument('--n-eval', type=int, default=32, help='Episodes per stratum per cadence')
    p.add_argument('--epochs', type=int, default=12)
    p.add_argument('--batch', type=int, default=32)
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--threads', type=int, default=2)
    p.add_argument('--train-cadence', choices=CADENCES, default='none')
    p.add_argument('--cells', default=','.join(CELLS), help='Comma-separated subset of WA,WB,RA,RB')
    p.add_argument('--oracle', choices=('none', 'both'), default='none',
                   help="'both' feeds identity+timing oracle channels to students (diagnostic positive control)")
    p.add_argument('--act-weight', type=float, default=10.)
    p.add_argument('--band-s', default=str(DEFAULT_BAND_S), help="teacher label band in seconds, or 'full'")
    p.add_argument('--clock-encoding', choices=('raw', 'bounded'), default='raw',
                   help='representation for the single Track B clock scalar')
    a = p.parse_args(argv)
    if min(a.n_train, a.n_eval, a.epochs, a.batch, a.threads) < 1 or a.seed < 0:
        p.error('Budgets must be positive and seed nonnegative')
    cells = [c.strip() for c in a.cells.split(',') if c.strip()]
    if not cells or any(c not in CELLS for c in cells) or len(set(cells)) != len(cells):
        p.error(f'--cells must be a distinct subset of {",".join(CELLS)}')
    band_s = math.inf if a.band_s == 'full' else float(a.band_s)
    if not band_s > 0 or a.act_weight <= 0:
        p.error('--band-s and --act-weight must be positive')
    oracle = a.oracle == 'both'
    diagnostic = oracle or a.act_weight != 10. or band_s != DEFAULT_BAND_S
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=False)  # never overwrite a previous result
    torch.set_num_threads(a.threads)
    torch.use_deterministic_algorithms(True)
    # Disjoint parity namespaces for training/evaluation, shared across student cells.
    train_seed, eval_seed = 2 * a.seed, 2 * a.seed + 1
    tracked = subprocess.check_output(['git', 'status', '--porcelain'], text=True)
    sources = list(Path('chemrm/paperb').glob('*.py')) + [Path('chemrm/gate0/env.py'), Path('chemrm/gate0/policies.py')]
    manifest = {'status': 'development_only_not_preregistered', 'method': 'full_prefix_observation_teacher_distillation',
                'args': vars(a), 'cells': cells, 'train_seed': train_seed, 'eval_seed': eval_seed,
                'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
                'git_status': tracked, 'torch': str(torch.__version__), 'numpy': np.__version__,
                'source_sha256': {str(f): hashlib.sha256(f.read_bytes()).hexdigest() for f in sources},
                'oracle_training': oracle, 'diagnostic': diagnostic, 'act_weight': a.act_weight,
                'band_s': 'full' if band_s == math.inf else band_s,
                'clock_encoding': a.clock_encoding,
                'teacher': 'causal_observation_record_active',
                'teacher_queries': a.n_train * 400, 'training_cadence': a.train_cadence,
                'evaluation': 'same_distribution_and_fixed_to_perturbed_when_train_none',
                'caveat': 'Single seed, small budget, full exogenous prefixes; no recovery or OPD claim.'
                          + (' DIAGNOSTIC RUN: not a Track A/B competition score.' if diagnostic else '')}
    (out / 'manifest.json').write_text(json.dumps(manifest, indent=2))
    data = dataset(a.n_train, train_seed, a.train_cadence, band_s=band_s, oracle=oracle)
    if oracle and not (data[4][..., 12:21] != 0).any():
        raise RuntimeError('oracle positive control requested but oracle channels are all zero')
    models, training = {}, {}
    for cell in cells:
        models[cell], training[cell] = train_cell(cell, data, a.seed, a.epochs, a.batch,
                                                  a.act_weight, oracle, a.clock_encoding)
        torch.save(models[cell].state_dict(), out / f'{cell}.pt')
        print(cell, 'loss', round(training[cell]['loss'][-1], 4), flush=True)
    (out / 'training.json').write_text(json.dumps(training, indent=2))
    summary = []
    with (out / 'episodes.jsonl').open('w') as stream:
        for cadence in CADENCES:
            for stratum in STRATA:
                eps, ticks, ti, eta, x, labels = dataset(a.n_eval, eval_seed, cadence, stratum, band_s, oracle)
                actions, probs = {'teacher': labels}, {'teacher': None}
                with torch.no_grad():
                    for cell, model in models.items():
                        parts = []
                        for offset in range(0, len(x), a.batch):
                            z = torch.from_numpy(student_observations(x[offset:offset + a.batch], cell, oracle,
                                                                       a.clock_encoding))
                            parts.append(torch.softmax(model(z), -1).numpy())
                        probs[cell] = np.concatenate(parts)
                        actions[cell] = probs[cell].argmax(-1)
                teacher_sr = None
                for cell, act in actions.items():
                    rows = score(eps, ticks, ti, eta, act, probs[cell])
                    sr = {k: float(np.mean([r[k] for r in rows])) for k in ('goal', 'protocol', 'time', 'safety')}
                    if cell == 'teacher':
                        teacher_sr = sr['goal']
                    errors = [r['error_s'] for r in rows if r['error_s'] is not None]
                    item = {'cadence': cadence, 'stratum': stratum, 'cell': cell, 'n': len(rows), **sr,
                            'retention': sr['goal'] / teacher_sr if teacher_sr else None,
                            'never_acted': float(np.mean([not r['added'] for r in rows])),
                            'median_error_s': float(np.median(errors)) if errors else None,
                            'median_p_target_in_window': float(np.median([r['p_target_in_window'] for r in rows]))
                            if cell != 'teacher' else None,
                            'median_p_act_peak': float(np.median([r['p_act_peak'] for r in rows]))
                            if cell != 'teacher' else None}
                    summary.append(item)
                    for row in rows:
                        stream.write(json.dumps({'cadence': cadence, 'stratum': stratum, 'cell': cell,
                                                 'eval_seed': eval_seed, **row}, allow_nan=False) + '\n')
    (out / 'summary.json').write_text(json.dumps(summary, indent=2, allow_nan=False))
    title = '# Q0a development control' + (' — DIAGNOSTIC (not a competition score)' if diagnostic else '')
    lines = [title, '', 'Not preregistered; one seed, limited training. Full-prefix distillation, not OPD. Fixed-to-perturbed evaluation is distribution shift when training cadence is none.',
             '', f"Oracle channels to students: {oracle}. Act-tick weight: {a.act_weight:g}. Teacher label band: {manifest['band_s']} s. Clock encoding: {a.clock_encoding}.", '',
             '| Cadence | Cell | Mean goal SR across 8 strata |', '|---|---|---|']
    for cadence in CADENCES:
        for cell in ['teacher', *cells]:
            rate = np.mean([r['goal'] for r in summary if r['cadence'] == cadence and r['cell'] == cell])
            lines.append(f'| {cadence} | {cell} | {rate:.4f} |')
    lines += ['', 'Tight strata under fixed cadence (6 strata pooled): never-acted rate and median peak probability of the target action inside the referee window.', '',
              '| Cell | Goal SR | Never acted | Median max P(target act) in window | Median peak P(any act) |', '|---|---|---|---|---|']
    for cell in cells:
        tight_rows = [r for r in summary if r['cadence'] == 'none' and r['cell'] == cell and 'tight' in r['stratum']]
        lines.append(f"| {cell} | {np.mean([r['goal'] for r in tight_rows]):.4f} | {np.mean([r['never_acted'] for r in tight_rows]):.4f} | "
                     f"{np.median([r['median_p_target_in_window'] for r in tight_rows]):.3f} | {np.median([r['median_p_act_peak'] for r in tight_rows]):.3f} |")
    lines += ['', 'All tasks retained. See summary.json for strata, numerator/denominator, timing errors and no-action rates. No inferential threshold or mechanism conclusion is applied.']
    (out / 'RESULTS.md').write_text('\n'.join(lines) + '\n')
    print('\n'.join(lines), flush=True)


if __name__ == '__main__':
    main()
