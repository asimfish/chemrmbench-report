"""Re-evaluate saved Q0a checkpoints under fixed cadence and write readiness read-outs.

Used for runs recorded before `p_target_in_window` existed. Writes `<run>/readout.json`;
never modifies the original summary or episode files.

Example: python3 -m chemrm.paperb.readout pilot/paperB/q0a/dev_seed0_n1024_e60
"""
import json
import math
from pathlib import Path
import sys

import numpy as np
import torch

from chemrm.gate0.env import STRATA
from chemrm.paperb.q0a import make_student, student_observations
from chemrm.paperb.run_q0a import dataset, score


def readout(run_dir, cadence='none'):
    run = Path(run_dir)
    manifest = json.loads((run / 'manifest.json').read_text())
    band = manifest.get('band_s', 0.75)
    band_s = math.inf if band == 'full' else float(band)
    oracle = bool(manifest.get('oracle_training', False))
    clock_encoding = manifest.get('clock_encoding', 'raw')
    n_eval, eval_seed = manifest['args']['n_eval'], manifest['eval_seed']
    result = {'run': run.name, 'cadence': cadence, 'eval_seed': eval_seed, 'cells': {}}
    for ckpt in sorted(run.glob('*.pt')):
        cell = ckpt.stem
        model = make_student(cell)
        model.load_state_dict(torch.load(ckpt, map_location='cpu', weights_only=True))
        model.eval()
        per_stratum = {}
        for stratum in STRATA:
            eps, ticks, ti, eta, x, _ = dataset(n_eval, eval_seed, cadence, stratum, band_s, oracle)
            with torch.no_grad():
                probs = torch.softmax(model(torch.from_numpy(student_observations(x, cell, oracle, clock_encoding))), -1).numpy()
            rows = score(eps, ticks, ti, eta, probs.argmax(-1), probs)
            per_stratum[stratum] = {
                'goal': float(np.mean([r['goal'] for r in rows])),
                'never_acted': float(np.mean([not r['added'] for r in rows])),
                'median_p_target_in_window': float(np.median([r['p_target_in_window'] for r in rows])),
                'median_p_act_peak': float(np.median([r['p_act_peak'] for r in rows]))}
        tight = [v for k, v in per_stratum.items() if 'tight' in k]
        result['cells'][cell] = {'per_stratum': per_stratum,
                                 'tight_pooled': {k: float(np.median([v[k] for v in tight]) if k.startswith('median') else np.mean([v[k] for v in tight]))
                                                  for k in ('goal', 'never_acted', 'median_p_target_in_window', 'median_p_act_peak')}}
    (run / 'readout.json').write_text(json.dumps(result, indent=2))
    return result


def main(argv):
    for d in argv:
        r = readout(d)
        for cell, v in r['cells'].items():
            t = v['tight_pooled']
            print(f"{r['run']} {cell}: tight goal {t['goal']:.3f} never_acted {t['never_acted']:.3f} "
                  f"median max P(target) in window {t['median_p_target_in_window']:.3f} peak P(act) {t['median_p_act_peak']:.3f}")


if __name__ == '__main__':
    torch.set_num_threads(1)
    main(sys.argv[1:])
