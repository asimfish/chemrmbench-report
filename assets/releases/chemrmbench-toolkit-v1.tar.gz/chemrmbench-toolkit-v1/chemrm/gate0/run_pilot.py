"""Run the Gate 0 pilot end to end: train 3 conditions x 3 seeds, evaluate every checkpoint
under the four masks on identical episodes, apply the preregistered decision rule, and
write the results bundle (records, decisions, summary tables, figures, RESULTS.md).

    python3 -m chemrm.gate0.run_pilot --out pilot/gate0/results

Preregistration (pilot/gate0/PREREG.md, committed before any result):
  K1 is decided on the `reactive` condition (the learned analogue of the abstract model's
  stateless rule); the same three tests are reported for `memory` and `clock` descriptively.
  K2 compares memory vs reactive Protocol-SR on M1_relaxed; K3 compares Track A Timed-SR on
  M0_tight_0.15 with half of the Track B clock condition's.
"""
from __future__ import annotations

import os as _os
for _v in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
    _os.environ.setdefault(_v, "1")          # one BLAS thread per worker; the workers parallelise across processes

import argparse
import json
import math
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from typing import Dict, List

import numpy as np

from analysis.estimands import analyse_records
from chemrm.gate0.env import (HARDEST, MASKS, STRATA, draw_episode_batch, run_expert_cell)
from chemrm.gate0.evaluate import EVAL_SEED, estimand_records, eval_seed_for, evaluate_checkpoint
from chemrm.gate0.policies import CONDITIONS
from chemrm.gate0.train import train

PRIMARY_CONDITION = "reactive"
SEEDS_DEFAULT = (0, 1, 2)
FIELDS = ("goal", "protocol", "time", "safety")


# ------------------------------------------------------------------ helpers
def wilson(k: int, n: int, z: float = 1.96):
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n
    den = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / den
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return (centre - half, centre + half)


def rate(records: List[Dict], field: str, **where) -> Dict:
    sel = [r for r in records if all(r[k] == v for k, v in where.items())]
    n = len(sel)
    k = sum(int(r[field]) for r in sel)
    lo, hi = wilson(k, n)
    return {"n": n, "k": k, "rate": (k / n) if n else float("nan"), "wilson95": [lo, hi]}


def _train_job(args):
    condition, seed, out, n_train, epochs = args
    return train(condition, seed, out, n_train=n_train, epochs=epochs, threads=1, log_every=0)


# ------------------------------------------------------------------ stages
def stage_train(out: str, seeds, n_train: int, epochs: int, workers: int) -> Dict[str, str]:
    os.makedirs(os.path.join(out, "ckpt"), exist_ok=True)
    jobs, paths = [], {}
    for cond in CONDITIONS:
        for s in seeds:
            p = os.path.join(out, "ckpt", f"{cond}_s{s}.pt")
            paths[f"{cond}_s{s}"] = p
            if not os.path.exists(p):
                jobs.append((cond, s, p, n_train, epochs))
    if jobs:
        t0 = time.time()
        print(f"training {len(jobs)} runs with {workers} workers ...", flush=True)
        with ProcessPoolExecutor(max_workers=workers) as ex:
            for meta in ex.map(_train_job, jobs):
                print(f"  done {meta['condition']} s{meta['seed']}: final loss {meta['epoch_loss'][-1]:.4f}, "
                      f"{meta['n_parameters']} params, {meta['wall_s']}s", flush=True)
        print(f"training finished in {time.time() - t0:.0f}s", flush=True)
    return paths


def stage_evaluate(out: str, ckpts: Dict[str, str], n_eval: int) -> List[Dict]:
    path = os.path.join(out, "records_all.jsonl")
    records: List[Dict] = []
    for name, ck in sorted(ckpts.items()):
        recs = evaluate_checkpoint(ck, n_eval=n_eval)              # per-seed draw EVAL_SEED + seed
        records.extend(recs)
        print(f"  evaluated {name}: {len(recs)} records", flush=True)
    with open(path, "w", encoding="utf-8") as fh:
        for r in records:
            fh.write(json.dumps(r) + "\n")
    return records


def stage_analyse(out: str, records: List[Dict], n_eval: int) -> Dict:
    seeds = sorted({r["seed"] for r in records})
    expert = {}
    for s in STRATA:
        vals = [run_expert_cell(draw_episode_batch(n_eval, eval_seed_for(seed)), s)["goal"].mean() for seed in seeds]
        expert[s] = float(np.mean(vals))

    decisions = {}
    for cond in CONDITIONS:
        sub = [r for r in records if r["condition"] == cond]
        est = estimand_records(sub)
        with open(os.path.join(out, f"estimands_{cond}.jsonl"), "w", encoding="utf-8") as fh:
            for r in est:
                fh.write(json.dumps(r) + "\n")
        decisions[cond] = analyse_records(est)

    table = {}                                   # condition -> stratum -> mask -> field -> rate
    for cond in CONDITIONS:
        table[cond] = {}
        for s in STRATA:
            table[cond][s] = {}
            for m in MASKS:
                table[cond][s][m] = {f: rate(records, f, condition=cond, stratum=s, mask=m)["rate"]
                                     for f in FIELDS}
    per_seed = {}
    for cond in CONDITIONS:
        per_seed[cond] = {}
        for s in STRATA:
            per_seed[cond][s] = {seed: rate(records, "goal", condition=cond, stratum=s, mask="none", seed=seed)["rate"]
                                 for seed in sorted({r["seed"] for r in records})}

    # K2: identity internalisation (Track A memory adapter vs reactive on M1_relaxed, Protocol-SR)
    k2_mem = rate(records, "protocol", condition="memory", stratum="M1_relaxed", mask="none")
    k2_rea = rate(records, "protocol", condition="reactive", stratum="M1_relaxed", mask="none")
    k2 = {"memory_protocol_sr": k2_mem, "reactive_protocol_sr": k2_rea,
          "identity_internalised": bool(k2_mem["rate"] > k2_rea["wilson95"][1]),
          "rule": "memory Protocol-SR on M1_relaxed (mask none) above the reactive Wilson-95 upper bound"}
    # K3: time internalisation (Track A adapters vs half of Track B clock on M0_tight_0.15, Timed-SR)
    k3_a = {c: rate(records, "time", condition=c, stratum="M0_tight_0.15", mask="none") for c in ("reactive", "memory")}
    k3_b = rate(records, "time", condition="clock", stratum="M0_tight_0.15", mask="none")
    best_a = max(k3_a.values(), key=lambda d: d["rate"])
    k3 = {"track_a_timed_sr": k3_a, "track_b_clock_timed_sr": k3_b,
          "time_internalised": bool(best_a["rate"] > 0.5 * k3_b["rate"]),
          "rule": "best Track A Timed-SR on M0_tight_0.15 (mask none) above half of the Track B clock condition"}

    speed = {}
    for cond in CONDITIONS:
        vals = [r["s_norm"] for r in records if r["condition"] == cond and r["mask"] == "none"
                and r["goal"] == 1 and r["s_norm"] is not None]
        speed[cond] = {"n_goal_episodes": len(vals), "mean_s_norm": float(np.mean(vals)) if vals else None}

    numbers = {
        "eval_seed": EVAL_SEED, "eval_seed_rule": "EVAL_SEED + training seed", "n_eval_per_stratum_per_seed": n_eval,
        "seeds": sorted({r["seed"] for r in records}), "primary_condition": PRIMARY_CONDITION,
        "expert_goal_rate": expert, "decisions": decisions, "k1_primary": decisions[PRIMARY_CONDITION],
        "k2": k2, "k3": k3, "table_pooled": table, "goal_per_seed_mask_none": per_seed, "speed": speed,
    }
    with open(os.path.join(out, "numbers.json"), "w", encoding="utf-8") as fh:
        json.dump(numbers, fh, indent=2)
    return numbers


# ------------------------------------------------------------------ figures and report
def stage_figures(out: str, numbers: Dict) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                         "figure.dpi": 200, "savefig.bbox": "tight"})
    conds = list(CONDITIONS)
    tab = numbers["table_pooled"]

    fig, ax = plt.subplots(figsize=(4.4, 3.0))
    mat = np.array([[tab[c][s]["none"]["goal"] for c in conds] for s in STRATA])
    im = ax.imshow(mat, vmin=0, vmax=1, cmap="viridis", aspect=0.6)
    ax.set_xticks(range(len(conds))); ax.set_xticklabels([f"{c}\nTrack {CONDITIONS[c]['track']}" for c in conds], fontsize=7)
    ax.set_yticks(range(len(STRATA))); ax.set_yticklabels(STRATA)
    for i in range(len(STRATA)):
        for j in range(len(conds)):
            ax.text(j, i, f"{mat[i, j]:.2f}", ha="center", va="center",
                    color="white" if mat[i, j] < 0.5 else "black", fontsize=7)
    ax.set_title("goal success, mask none (3 seeds x 100 episodes)", fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.046)
    fig.savefig(os.path.join(out, "fig_strata.pdf")); fig.savefig(os.path.join(out, "fig_strata.png")); plt.close(fig)

    fig, ax = plt.subplots(figsize=(4.2, 2.4))
    w = 0.2
    for k, m in enumerate(MASKS):
        vals = [tab[c][HARDEST][m]["goal"] for c in conds]
        ax.bar(np.arange(len(conds)) + (k - 1.5) * w, vals, width=w, label=m)
    ax.set_xticks(range(len(conds))); ax.set_xticklabels([f"{c} (Track {CONDITIONS[c]['track']})" for c in conds])
    ax.set_ylim(0, 1.28); ax.set_yticks([0, 0.2, 0.4, 0.6, 0.8, 1.0]); ax.set_ylabel("goal success")
    ax.set_title(f"oracle factorial on {HARDEST}", fontsize=8)
    ax.legend(fontsize=6.5, frameon=False, ncol=4, loc="upper center", title="oracle mask", title_fontsize=6.5)
    fig.savefig(os.path.join(out, "fig_oracle.pdf")); fig.savefig(os.path.join(out, "fig_oracle.png")); plt.close(fig)

    fig, ax = plt.subplots(figsize=(3.6, 2.4))
    tiers = ["relaxed", "tight_0.30", "tight_0.15", "tight_0.08"]
    for c in conds:
        ax.plot(range(4), [tab[c][f"M0_{t}"]["none"]["time"] for t in tiers], marker="o",
                label=f"{c} (Track {CONDITIONS[c]['track']})")
    ax.set_xticks(range(4)); ax.set_xticklabels(tiers, fontsize=7)
    ax.set_ylim(-0.02, 1.05); ax.set_ylabel("Timed-SR on M0")
    ax.legend(fontsize=6.5, frameon=False)
    fig.savefig(os.path.join(out, "fig_timing.pdf")); fig.savefig(os.path.join(out, "fig_timing.png")); plt.close(fig)


def stage_report(out: str, numbers: Dict) -> None:
    conds = list(CONDITIONS)
    tab = numbers["table_pooled"]
    L = []
    L.append("# Gate 0 pilot results (auto-generated by chemrm.gate0.run_pilot)\n")
    L.append(f"Evaluation draws {numbers['eval_seed']} + training seed, n = {numbers['n_eval_per_stratum_per_seed']} paired "
             f"episodes per stratum per training seed, seeds {numbers['seeds']}; ideal-paused; execution "
             f"substitution ON; deterministic (argmax) decisions.\n")
    L.append("## K1 decision (primary condition: %s)\n" % numbers["primary_condition"])
    for cond in conds:
        d = numbers["decisions"][cond]
        tag = "PRIMARY" if cond == numbers["primary_condition"] else "descriptive"
        L.append(f"### {cond} ({tag}): {d['decision'] if cond == numbers['primary_condition'] else d['decision'] + '  (descriptive row: not a K1 decision; see INTERPRETATION.md)'}\n")
        L.append("| test | estimate | threshold | p (one-sided) | 5th pct | Holm alpha | rejected | status |")
        L.append("|---|---|---|---|---|---|---|---|")
        for t in d["tests"]:
            L.append(f"| {t['name']} | {t['estimate']:.3f} | {t['threshold']:.2f} | {t['p_value']:.4f} | "
                     f"{t['ci_lower_90']:.3f} | {t['holm_alpha'] if t['holm_alpha'] is None else round(t['holm_alpha'], 4)} | "
                     f"{t['rejected']} | {t['status']} |")
        L.append("")
    L.append("## K2 identity internalisation\n")
    k2 = numbers["k2"]
    L.append(f"memory adapter Protocol-SR on M1_relaxed = {k2['memory_protocol_sr']['rate']:.3f} "
             f"(Wilson 95% {k2['memory_protocol_sr']['wilson95'][0]:.3f}-{k2['memory_protocol_sr']['wilson95'][1]:.3f}); "
             f"reactive = {k2['reactive_protocol_sr']['rate']:.3f} "
             f"(upper {k2['reactive_protocol_sr']['wilson95'][1]:.3f}). "
             f"identity_internalised = **{k2['identity_internalised']}**\n")
    L.append("## K3 time internalisation\n")
    k3 = numbers["k3"]
    L.append(f"Track A Timed-SR on M0_tight_0.15: reactive {k3['track_a_timed_sr']['reactive']['rate']:.3f}, "
             f"memory {k3['track_a_timed_sr']['memory']['rate']:.3f}; Track B clock {k3['track_b_clock_timed_sr']['rate']:.3f}. "
             f"time_internalised (best A > B/2) = **{k3['time_internalised']}**\n")
    L.append("## Expert acceptance\n")
    L.append("| stratum | expert goal rate |\n|---|---|")
    for s in STRATA:
        L.append(f"| {s} | {numbers['expert_goal_rate'][s]:.3f} |")
    L.append("")
    L.append("## Pooled goal success by stratum (mask none)\n")
    L.append("| stratum | " + " | ".join(f"{c} (Track {CONDITIONS[c]['track']})" for c in conds) + " |")
    L.append("|---|" + "---|" * len(conds))
    for s in STRATA:
        L.append(f"| {s} | " + " | ".join(f"{tab[c][s]['none']['goal']:.2f}" for c in conds) + " |")
    L.append("")
    L.append("## Per-seed goal success (mask none)\n")
    L.append("| stratum | " + " | ".join(f"{c} s{seed}" for c in conds for seed in numbers["seeds"]) + " |")
    L.append("|---|" + "---|" * (len(conds) * len(numbers["seeds"])))
    for s in STRATA:
        L.append(f"| {s} | " + " | ".join(f"{numbers['goal_per_seed_mask_none'][c][s][str(seed)] if str(seed) in numbers['goal_per_seed_mask_none'][c][s] else numbers['goal_per_seed_mask_none'][c][s][seed]:.2f}"
                                         for c in conds for seed in numbers["seeds"]) + " |")
    L.append("")
    L.append(f"## Oracle factorial on {HARDEST} (goal, pooled)\n")
    L.append("| condition | none | identity | timing | both | I_rec |")
    L.append("|---|---|---|---|---|---|")
    for c in conds:
        g = {m: tab[c][HARDEST][m]["goal"] for m in MASKS}
        irec = (g["both"] - g["identity"]) - (g["timing"] - g["none"])
        L.append(f"| {c} | {g['none']:.2f} | {g['identity']:.2f} | {g['timing']:.2f} | {g['both']:.2f} | {irec:.2f} |")
    L.append("")
    L.append("## Pass-vector components on M0 strata (mask none, pooled)\n")
    L.append("| stratum | condition | protocol | time | safety | goal |")
    L.append("|---|---|---|---|---|---|")
    for s in STRATA:
        for c in conds:
            r = tab[c][s]["none"]
            L.append(f"| {s} | {c} | {r['protocol']:.2f} | {r['time']:.2f} | {r['safety']:.2f} | {r['goal']:.2f} |")
    L.append("")
    L.append("## Efficiency (descriptive, goal episodes only, mask none)\n")
    for c in conds:
        sp = numbers["speed"][c]
        L.append(f"- {c}: n = {sp['n_goal_episodes']}, mean normalised speed s = "
                 f"{'n/a' if sp['mean_s_norm'] is None else round(sp['mean_s_norm'], 3)}")
    L.append("")
    L.append("Figures: fig_strata, fig_oracle, fig_timing (.pdf/.png). Raw records: records_all.jsonl; "
             "estimand inputs: estimands_<condition>.jsonl; all numbers: numbers.json.")
    with open(os.path.join(out, "RESULTS.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")


# ------------------------------------------------------------------ main
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--out", default="pilot/gate0/results")
    ap.add_argument("--seeds", type=int, nargs="+", default=list(SEEDS_DEFAULT))
    ap.add_argument("--n-train", type=int, default=8000)
    ap.add_argument("--epochs", type=int, default=60)
    ap.add_argument("--n-eval", type=int, default=100)
    ap.add_argument("--workers", type=int, default=9)
    ap.add_argument("--skip-train", action="store_true", help="reuse checkpoints in --out/ckpt")
    a = ap.parse_args(argv)
    os.makedirs(a.out, exist_ok=True)
    ckpts = stage_train(a.out, a.seeds, a.n_train, a.epochs, a.workers)
    print("evaluating ...", flush=True)
    records = stage_evaluate(a.out, ckpts, a.n_eval)
    numbers = stage_analyse(a.out, records, a.n_eval)
    stage_figures(a.out, numbers)
    stage_report(a.out, numbers)
    d = numbers["k1_primary"]
    print(json.dumps({"K1": d["decision"], "tests": [(t["name"], round(t["estimate"], 3), round(t["p_value"], 4), t["rejected"]) for t in d["tests"]],
                      "K2": numbers["k2"]["identity_internalised"], "K3": numbers["k3"]["time_internalised"]}, indent=1))
    return 0 if d["all_three_rejected"] else 1


if __name__ == "__main__":
    sys.exit(main())
