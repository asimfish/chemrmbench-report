"""The three first-layer conditions of the Gate 0 pilot, budget-matched within 5%.

    reactive  k = 1 frame window: a per-tick MLP, no state (Track A)
    memory    in-backbone recurrent adapter: a GRU over the observation history (Track A)
    clock     the same recurrent adapter plus the bare timestamp channel (Track B)

All three read the same 22-dim observation with both oracle channels present (masked at
random during training, see train.py).  A stateless policy cannot use the timestamp alone:
knowing t without remembering t_A does not give elapsed time, so the clock token is defined
on top of the recurrent adapter, as in proposal 6 (clock adapter, Track B only).

Parameter counts: MLP 22-128-128-6 = 20,230; GRU(22, 72) + head = 21,174 (+4.7%).
"""
from __future__ import annotations

from typing import Dict

import torch
import torch.nn as nn

from chemrm.gate0.env import N_ACTIONS, OBS_DIM

CONDITIONS: Dict[str, Dict] = {
    "reactive": {"arch": "mlp", "clock": False, "track": "A"},
    "memory":   {"arch": "gru", "clock": False, "track": "A"},
    "clock":    {"arch": "gru", "clock": True,  "track": "B"},
}
MLP_HIDDEN = 128
GRU_HIDDEN = 72


class ReactivePolicy(nn.Module):
    """k = 1 frame window: logits depend on the current observation only."""

    def __init__(self, hidden: int = MLP_HIDDEN):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(OBS_DIM, hidden), nn.ReLU(),
                                 nn.Linear(hidden, hidden), nn.ReLU(),
                                 nn.Linear(hidden, N_ACTIONS))

    def forward(self, obs: torch.Tensor) -> torch.Tensor:       # (B, T, OBS_DIM) -> (B, T, A)
        return self.net(obs)


class RecurrentPolicy(nn.Module):
    """Recurrent memory adapter: a GRU integrates the observation history."""

    def __init__(self, hidden: int = GRU_HIDDEN):
        super().__init__()
        self.gru = nn.GRU(OBS_DIM, hidden, batch_first=True)
        self.head = nn.Linear(hidden, N_ACTIONS)

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        h, _ = self.gru(obs)
        return self.head(h)


def make_policy(condition: str) -> nn.Module:
    arch = CONDITIONS[condition]["arch"]
    return ReactivePolicy() if arch == "mlp" else RecurrentPolicy()


def n_parameters(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters())
