"""Exploratory noise-sensitivity add-on to the Gate 0 pilot (NOT preregistered; proposal 5.4 (iii)).

Question: does the recurrent adapters' ceiling survive timing noise, and do the v0.6.1 timing
diagnostics then separate a policy that counts ticks from one that reads a clock?

Two clock perturbations (chemrm.gate0.env.make_tick_times), applied identically in training and
evaluation; the referee, the timing oracle and the Track B timestamp always use true time:
    tick_jitter 0.4   dt_k = DT (1 + U(-0.4, 0.4)) per tick  -> a tick counter drifts like a
                      random walk, sigma_e ~ sqrt(n)  (Weber slope ~ 0.5)
    rate_error 0.15   dt = DT (1 + U(-0.15, 0.15)) per episode -> a tick counter is off by a
                      fixed fraction, sigma_e ~ D  (Weber slope ~ 1, scalar timing)
Conditions: memory (GRU, Track A) and clock (same GRU + timestamp, Track B); the stateless
reactive policy cannot time without an oracle regardless of noise and is not retrained.
Budget identical to the pilot (8000 episodes, 60 epochs, three seeds); horizon 400 ticks so the
latest admissible B time stays inside the episode under a slow clock.

    python3 -m chemrm.gate0.addon_noise --out pilot/gate0/addon_noise --workers 6
"""
from __future__ import annotations

import os as _os
for _v in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS"):
    _os.environ.setdefault(_v, "1")          # one BLAS thread per worker; the workers parallelise across processes

import argparse
import json
import math
import os
import sys
import time
from concurrent.futures import ProcessPoolExecutor
from typing import Dict, List

import numpy as np

from chemrm.gate0.evaluate import evaluate_checkpoint
from chemrm.gate0.run_pilot import rate
from chemrm.gate0.train import train
from chemrm.timing_metrics import acuity_eta50, calibration, failure_vector, signed_error, summarise_errors, track_contrast, weber_slope

SETTINGS = {
    "tick_jitter_0.4": {"kind": "tick_jitter", "level": 0.4, "n_steps": 400},
    "rate_error_0.15": {"kind": "rate_error", "level": 0.15, "n_steps": 400},
}
CONDS = ("memory", "clock")
TIERS = {"tight_0.30": 0.30, "tight_0.15": 0.15, "tight_0.08": 0.08}


def _job(args):
    cond, seed, out, perturb, n_train, epochs = args
    return train(cond, seed, out, n_train=n_train, epochs=epochs, threads=1, log_every=0, perturb=perturb)


def stage_train(out: str, seeds, n_train, epochs, workers) -> Dict[str, Dict[str, str]]:
    jobs, paths = [], {}
    for name, pert in SETTINGS.items():
        paths[name] = {}
        os.makedirs(os.path.join(out, name, "ckpt"), exist_ok=True)
        for cond in CONDS:
            for s in seeds:
                p = os.path.join(out, name, "ckpt", f"{cond}_s{s}.pt")
                paths[name][f"{cond}_s{s}"] = p
                if not os.path.exists(p):
                    jobs.append((cond, s, p, pert, n_train, epochs))
    if jobs:
        t0 = time.time()
        print(f"training {len(jobs)} runs with {workers} workers ...", flush=True)
        with ProcessPoolExecutor(max_workers=workers) as ex:
            for meta in ex.map(_job, jobs):
                print(f"  done {meta['perturb']['kind']} {meta['condition']} s{meta['seed']}: loss {meta['epoch_loss'][-1]:.4f}, {meta['wall_s']}s", flush=True)
        print(f"training finished in {time.time() - t0:.0f}s", flush=True)
    return paths


def timing_cells(records: List[Dict], cond: str, tier: str, mask: str = "none", m_level: str = "M0"):
    rc = [r for r in records if r["condition"] == cond and r["mask"] == mask and r["stratum"] == f"{m_level}_{tier}"]
    t_b = np.array([r["t_b"] if r["added"] else float("nan") for r in rc], dtype=float)
    t_star = np.array([r["t_a"] + r["d"] for r in rc], dtype=float)
    d = np.array([r["d"] for r in rc], dtype=float)
    return rc, signed_error(t_b, t_star), d, t_b - np.array([r["t_a"] for r in rc])


def fmt(x, nd=2):
    return "n/a" if x is None or (isinstance(x, float) and math.isnan(x)) else f"{x:.{nd}f}"


def analyse(out: str, name: str, records: List[Dict], baseline: List[Dict]) -> Dict:
    res = {"setting": name, "perturb": SETTINGS[name], "timed_sr": {}, "goal_sr": {}, "timing": {}, "acuity": {}, "contrast": {}}
    L = [f"# Noise add-on: {name} ({SETTINGS[name]['kind']} level {SETTINGS[name]['level']}, horizon {SETTINGS[name]['n_steps']} ticks)\n",
         "Exploratory, not preregistered. Same budget and seeds as the pilot; the reactive condition is not retrained (it cannot time without an oracle). "
         "Baseline columns are the preregistered pilot (uniform clock).\n",
         "## Timed-SR on M0 strata, mask none (pooled over three seeds)\n",
         "| tier | memory (A) baseline | memory (A) perturbed | clock (B) baseline | clock (B) perturbed | clock benefit perturbed (B - A) |",
         "|---|---|---|---|---|---|"]
    for tier in ("relaxed",) + tuple(TIERS):
        row = {}
        for cond in CONDS:
            row[f"{cond}_base"] = rate(baseline, "time", condition=cond, stratum=f"M0_{tier}", mask="none")["rate"]
            row[f"{cond}_pert"] = rate(records, "time", condition=cond, stratum=f"M0_{tier}", mask="none")["rate"]
        row["clock_benefit"] = track_contrast(row["memory_pert"], row["clock_pert"])["clock_benefit"]
        res["timed_sr"][tier] = row
        L.append(f"| {tier} | {fmt(row['memory_base'])} | {fmt(row['memory_pert'])} | {fmt(row['clock_base'])} | {fmt(row['clock_pert'])} | {fmt(row['clock_benefit'])} |")
    L.append("")
    L.append("## Goal success on all eight strata, mask none (perturbed)\n")
    L.append("| stratum | memory (A) | clock (B) |\n|---|---|---|")
    for m in ("M0", "M1"):
        for tier in ("relaxed",) + tuple(TIERS):
            s = f"{m}_{tier}"
            g = {c: rate(records, "goal", condition=c, stratum=s, mask="none")["rate"] for c in CONDS}
            res["goal_sr"][s] = g
            L.append(f"| {s} | {fmt(g['memory'])} | {fmt(g['clock'])} |")
    L.append("")
    L.append("## Timing diagnostics on M0_tight_0.15, mask none (perturbed)\n")
    L.append("| condition | acted / n | bias (s) | precision (s) | early share | p95 abs (s) | Weber slope | sigma_e by D bin | calibration slope | in / early / late / never |")
    L.append("|---|---|---|---|---|---|---|---|---|---|")
    for cond in CONDS:
        rc, e, d, produced = timing_cells(records, cond, "tight_0.15")
        s = summarise_errors(e, d); w = weber_slope(e, d); c = calibration(produced, d); fv = failure_vector(e, 0.15 * d)
        res["timing"][cond] = {"summary": s.__dict__, "weber": w, "calibration": c, "failure_vector": fv}
        bins = ", ".join(f"D~{b['D_mean']:.0f}: {b['sigma_e']:.2f}" for b in w.get("bins", []))
        L.append(f"| {cond} | {s.n_acted} / {s.n_total} | {fmt(s.bias_s)} | {fmt(s.precision_s)} | {fmt(s.early_share)} | {fmt(s.p95_abs_s)} | "
                 f"{fmt(w['slope'])} | {bins or 'n/a'} | {fmt(c.get('slope'))} | {fmt(fv['in_window'])} / {fmt(fv['early'])} / {fmt(fv['late'])} / {fmt(fv['never_acted'])} |")
    L.append("")
    L.append("## Timing acuity eta50 on M0 strata, mask none (perturbed)\n")
    L.append("| condition | SR 0.30 | SR 0.15 | SR 0.08 | eta50 | absolute acuity at D = 60 s |\n|---|---|---|---|---|---|")
    for cond in CONDS:
        sr = {eta: rate(records, "time", condition=cond, stratum=f"M0_{tier}", mask="none")["rate"] for tier, eta in TIERS.items()}
        ac = acuity_eta50(sr); res["acuity"][cond] = ac
        e50 = ac["eta50"]
        L.append(f"| {cond} | {fmt(sr[0.30])} | {fmt(sr[0.15])} | {fmt(sr[0.08])} | {('%.3f' % e50) if not math.isnan(e50) else ac['censored']} | "
                 f"{('%.1f s' % (60 * e50)) if not math.isnan(e50) else 'censored'} |")
    L.append("")
    L.append("## Oracle recovery on M1_tight_0.08 (perturbed)\n")
    L.append("| condition | none | identity | timing | both |\n|---|---|---|---|---|")
    for cond in CONDS:
        g = {m: rate(records, "goal", condition=cond, stratum="M1_tight_0.08", mask=m)["rate"] for m in ("none", "identity", "timing", "both")}
        res.setdefault("oracle", {})[cond] = g
        L.append(f"| {cond} | {fmt(g['none'])} | {fmt(g['identity'])} | {fmt(g['timing'])} | {fmt(g['both'])} |")
    L.append("")
    with open(os.path.join(out, name, "RESULTS.md"), "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")
    with open(os.path.join(out, name, "numbers.json"), "w", encoding="utf-8") as fh:
        json.dump(res, fh, indent=1, default=float)
    print("\n".join(L))
    return res


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--out", default="pilot/gate0/addon_noise")
    ap.add_argument("--baseline-records", default="pilot/gate0/results/records_all.jsonl")
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2])
    ap.add_argument("--n-train", type=int, default=8000)
    ap.add_argument("--epochs", type=int, default=60)
    ap.add_argument("--n-eval", type=int, default=100)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--settings", nargs="+", default=list(SETTINGS))
    a = ap.parse_args(argv)
    for k in list(SETTINGS):
        if k not in a.settings:
            SETTINGS.pop(k)
    os.makedirs(a.out, exist_ok=True)
    paths = stage_train(a.out, a.seeds, a.n_train, a.epochs, a.workers)
    baseline = [json.loads(l) for l in open(a.baseline_records, encoding="utf-8") if l.strip()]
    summary = {}
    for name in SETTINGS:
        records: List[Dict] = []
        for key, ck in sorted(paths[name].items()):
            records.extend(evaluate_checkpoint(ck, n_eval=a.n_eval))
        with open(os.path.join(a.out, name, "records.jsonl"), "w", encoding="utf-8") as fh:
            for r in records:
                fh.write(json.dumps(r) + "\n")
        summary[name] = analyse(a.out, name, records, baseline)
    with open(os.path.join(a.out, "summary.json"), "w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=1, default=float)
    return 0


if __name__ == "__main__":
    sys.exit(main())
