"""Apply the T-axis diagnostic metrics (chemrm.timing_metrics) to the Gate 0 records.

    python3 -m chemrm.gate0.timing_report --records pilot/gate0/results/records_all.jsonl \
        --out pilot/gate0/results/timing_metrics

For every (condition, mask) on the tight strata: signed timing error e = t_B - (t_A + D) with bias,
precision and early share; Weber slope over the instructed-duration range; calibration slope of the
produced wait against the instructed D; timing acuity eta50 across the three tiers; the failure
vector of the eta = 0.15 tier; and the track contrasts (clock benefit, tool benefit) on Timed-SR.
The core family has no event or deadline constraints, so reaction latency, deadline margin and
inter-operation gaps are not computed here (they apply to C5, C8 and multi-step protocols).
"""
from __future__ import annotations

import argparse
import json
import math
import os
from collections import defaultdict
from typing import Dict, List

import numpy as np

from chemrm.core_family import T_POUR
from chemrm.timing_metrics import (acuity_eta50, calibration, failure_vector, signed_error, summarise_errors,
                                   track_contrast, weber_slope)

TIGHT = {"tight_0.30": 0.30, "tight_0.15": 0.15, "tight_0.08": 0.08}
CONDS = ("reactive", "memory", "clock")
MASKS = ("none", "identity", "timing", "both")


def load(path: str) -> List[Dict]:
    with open(path, encoding="utf-8") as fh:
        return [json.loads(l) for l in fh if l.strip()]


def cell(records: List[Dict], cond: str, mask: str, m_level: str, tier: str) -> List[Dict]:
    s = f"{m_level}_{tier}"
    return [r for r in records if r["condition"] == cond and r["mask"] == mask and r["stratum"] == s]


def errors(recs: List[Dict]):
    t_b = np.array([r["t_b"] if r["added"] else float("nan") for r in recs], dtype=float)
    t_star = np.array([r["t_a"] + r["d"] for r in recs], dtype=float)
    d = np.array([r["d"] for r in recs], dtype=float)
    return signed_error(t_b, t_star), d, t_b - np.array([r["t_a"] for r in recs])


def fmt(x, nd=2):
    if x is None or (isinstance(x, float) and math.isnan(x)):
        return "n/a"
    return f"{x:.{nd}f}"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--records", default="pilot/gate0/results/records_all.jsonl")
    ap.add_argument("--out", default="pilot/gate0/results/timing_metrics")
    ap.add_argument("--m-level", default="M0", help="stratum family used for the timing diagnostics (identity visible)")
    a = ap.parse_args(argv)
    recs = load(a.records)
    out: Dict = {"m_level": a.m_level, "cells": {}}
    L = ["# Gate 0 timing-precision diagnostics (chemrm.timing_metrics)\n",
         f"Strata {a.m_level}_tight_* (identity cue persistent, so every number below is about timing). "
         "e = t_B - (t_A + D) in seconds, negative = early; robust dispersion = 1.4826 x MAD; Weber slope = d log sigma_e / d log D "
         "(1 scalar timing, 0 constant absolute error); acuity eta50 = tolerance at which Timed-SR crosses 0.5, interpolated in log eta.\n"]
    L.append("## Timing error on the eta = 0.15 tier, all conditions and masks\n")
    L.append("| condition | mask | acted / n | bias (s) | precision (s) | bias (rel) | precision (rel) | early share | p95 abs err (s) | in window | early | late | never |")
    L.append("|---|---|---|---|---|---|---|---|---|---|---|---|---|")
    for cond in CONDS:
        for mask in MASKS:
            rc = cell(recs, cond, mask, a.m_level, "tight_0.15")
            e, d, _ = errors(rc)
            s = summarise_errors(e, d)
            fv = failure_vector(e, 0.15 * d)
            out["cells"][f"{cond}|{mask}|tight_0.15"] = {"summary": s.__dict__, "failure_vector": fv}
            L.append(f"| {cond} | {mask} | {s.n_acted} / {s.n_total} | {fmt(s.bias_s)} | {fmt(s.precision_s)} | {fmt(s.bias_rel, 3)} | {fmt(s.precision_rel, 3)} | "
                     f"{fmt(s.early_share)} | {fmt(s.p95_abs_s)} | {fmt(fv['in_window'])} | {fmt(fv['early'])} | {fmt(fv['late'])} | {fmt(fv['never_acted'])} |")
    L.append("")
    L.append("## Mechanism diagnostics on the eta = 0.15 tier (mask none unless stated)\n")
    L.append("| condition | mask | Weber slope | sigma_e by D bin (s) | calibration slope | central tendency |")
    L.append("|---|---|---|---|---|---|")
    for cond in CONDS:
        for mask in (("none", "timing") if cond == "reactive" else ("none",)):
            rc = cell(recs, cond, mask, a.m_level, "tight_0.15")
            e, d, produced = errors(rc)
            w = weber_slope(e, d)
            c = calibration(produced, d)
            out["cells"][f"{cond}|{mask}|tight_0.15"].update({"weber": w, "calibration": c})
            bins = ", ".join(f"D~{b['D_mean']:.0f}: {b['sigma_e']:.2f}" for b in w.get("bins", []))
            L.append(f"| {cond} | {mask} | {fmt(w['slope'])} ({w.get('note','')}) | {bins or 'n/a'} | {fmt(c.get('slope'))} | {fmt(c.get('central_tendency'))} |")
    L.append("")
    L.append("## Timing acuity eta50 (Timed-SR across tiers 0.30 / 0.15 / 0.08)\n")
    L.append("| condition | mask | SR 0.30 | SR 0.15 | SR 0.08 | eta50 | absolute acuity at D = 60 s |")
    L.append("|---|---|---|---|---|---|---|")
    acu = {}
    for cond in CONDS:
        for mask in MASKS:
            sr = {}
            for tier, eta in TIGHT.items():
                rc = cell(recs, cond, mask, a.m_level, tier)
                sr[eta] = float(np.mean([r["time"] for r in rc])) if rc else float("nan")
            ac = acuity_eta50(sr)
            acu[f"{cond}|{mask}"] = ac
            e50 = ac["eta50"]
            L.append(f"| {cond} | {mask} | {fmt(sr[0.30])} | {fmt(sr[0.15])} | {fmt(sr[0.08])} | "
                     f"{('%.3f' % e50) if not math.isnan(e50) else ac['censored']} | {('%.1f s' % (60 * e50)) if not math.isnan(e50) else ('<' + '%.1f s' % (60 * 0.08) if ac['censored'] and ac['censored'].startswith('<') else '>' + '%.1f s' % (60 * 0.30))} |")
    out["acuity"] = acu
    L.append("")
    L.append("## Track contrasts on Timed-SR (mask none)\n")
    L.append("| tier | Track A reactive | Track A memory | Track B clock | clock benefit (B - best A) |")
    L.append("|---|---|---|---|---|")
    contrasts = {}
    for tier in TIGHT:
        srs = {c: float(np.mean([r["time"] for r in cell(recs, c, "none", a.m_level, tier)])) for c in CONDS}
        tc = track_contrast(max(srs["reactive"], srs["memory"]), srs["clock"])
        contrasts[tier] = {**srs, **tc}
        L.append(f"| {tier} | {fmt(srs['reactive'])} | {fmt(srs['memory'])} | {fmt(srs['clock'])} | {fmt(tc['clock_benefit'])} |")
    out["track_contrasts"] = contrasts
    L.append("")
    L.append("Reading: in this deterministic 2-D pilot every recurrent policy times perfectly, so precision is degenerate and eta50 is censored below the tightest tier; "
             "the reactive policy with the timing oracle shows the instrument's resolution (its residual error is the 0.5 s control tick plus the +-1 s expert band). "
             "The metrics are defined for the simulator phase, where noise, pixels and latency will spread the error distributions.")
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    with open(a.out + ".md", "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")
    with open(a.out + ".json", "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, default=float)
    print("\n".join(L))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
