"""Low-fidelity 2-D environment for the Gate 0 pilot (core paired family, proposal 3.2).

Scene. Five identical flasks in a row on the bench, x in {-0.4, -0.2, 0, 0.2, 0.4} m,
y = 0; the robot's home pose is (0, -0.3) m. An assistant arm pours reagent A into one
random flask at t_A ~ U[5, 40] s and occupies it for T_POUR = 3 s. The instruction asks
for reagent B in THAT flask: relaxed -> any time after the pour ends; tight -> inside
t_A + D +/- eta*D with D ~ U[30, 90] s stated in the instruction.

Factors (eight strata).  M0 persistent cue: A carries a dye that stays visible on the
flask.  M1 transient cue: A is colourless; the only cue is the assistant over the flask
during the pour.  T: relaxed | tight_0.30 | tight_0.15 | tight_0.08.

Oracle masks.  identity -> one-hot of the flask that received A (zeros before A).
timing -> elapsed time since the pour started (zeros before A, plus an "A happened" flag).
Each channel carries a "known" flag so the policy can tell a masked oracle from an
uninformative one.  Track B adds a bare simulated timestamp channel; Track A leaves it 0.

Execution substitution is ON: the policy emits one discrete decision per control tick
(wait, or act on flask i); a scripted skill then moves from home to the flask at V_MAX and
pours for T_POUR_B, so B lands at t_B = t_decision + skill_time(i).  The scene is exogenous
until that decision, which is what makes privileged per-step expert labels exact and lets a
batch of episodes be rolled out in one forward pass (ideal-paused mode: the world does not
advance during inference).

Referee (fail closed, event-log semantics).  Pass vector per episode:
    valid    = 1 (no instrumentation to invalidate in this pilot)
    protocol = B added, into the right flask, after the assistant left (t_B >= t_A + T_POUR)
    time     = relaxed: B added; tight: |t_B - (t_A + D)| <= eta*D
    goal     = protocol and time            (the conjunctive success of the abstract model)
    safety   = no surrogate smoke event: smoke fires when B goes into a flask without A,
               collides with the assistant's pour, or (tight) lands before the window
    quantity = 1 (no dosing sub-goal in the core family)
Efficiency is recorded as t_B and the normalised speed s = t_min / t_B with t_min the
earliest referee-admissible B time.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

import numpy as np

from chemrm.core_family import T_POUR

N_FLASKS = 5
DT = 0.5                                   # control tick T_ctrl (s)
HORIZON = 160.0                            # s; latest admissible B is 40 + 90 * 1.30 = 157 s
N_STEPS = int(round(HORIZON / DT))         # 320 decision ticks, t_k = k * DT
FLASK_X = np.array([-0.4, -0.2, 0.0, 0.2, 0.4])
FLASK_Y = 0.0
HOME = (0.0, -0.3)
V_MAX = 0.2                                # m/s end-effector speed of the scripted skill
T_POUR_B = 1.0                             # s the scripted skill spends pouring B
LABEL_HALF_WIDTH = 1.0                     # s; expert acts so that |t_B - (t_A + D)| <= 1 s
T_A_RANGE = (5.0, 40.0)
D_RANGE = (30.0, 90.0)

ETAS: Dict[str, Optional[float]] = {"relaxed": None, "tight_0.30": 0.30,
                                    "tight_0.15": 0.15, "tight_0.08": 0.08}
STRATA: List[str] = [f"M{m}_{t}" for m in (0, 1) for t in ETAS]     # 8 strata
MASKS = ("none", "identity", "timing", "both")
HARDEST = "M1_tight_0.08"

# ------------------------------------------------------------------ observation layout
# index ranges of the 22-dim observation vector
OBS_DYE = slice(0, 5)            # persistent dye on flask j (M0 only, after A)
OBS_POURED = slice(5, 10)        # assistant currently pouring into flask j (both M levels)
OBS_D = 10                       # instructed wait D / TIME_SCALE (0 when relaxed: no D is stated)
OBS_TIGHT = 11                   # instruction says "exactly D after A"
OBS_ID_KNOWN = 12                # identity oracle switched on
OBS_ID = slice(13, 18)           # identity oracle one-hot (zeros before A)
OBS_TM_KNOWN = 18                # timing oracle switched on
OBS_TM_HAPPENED = 19             # timing oracle: A has happened
OBS_TM_ELAPSED = 20              # timing oracle: elapsed since the pour started / TIME_SCALE
OBS_CLOCK = 21                   # Track B bare timestamp t / TIME_SCALE (0 on Track A)
OBS_DIM = 22
N_ACTIONS = 1 + N_FLASKS         # 0 = wait, 1 + j = act on flask j
TIME_SCALE = 10.0                # all time-valued channels are given in units of 10 s, so the
                                 # +-1 s expert band is +-0.1 in feature units (learnable boundary)

assert LABEL_HALF_WIDTH < 0.08 * D_RANGE[0], "expert label width must sit inside every tier"
assert 0.08 * D_RANGE[0] >= 2 * DT, "time feasibility gate: eps >= 2 T_ctrl at the hardest tier"


def skill_time(flask: int) -> float:
    """Deterministic duration of the scripted move-and-pour skill for flask `flask`."""
    dist = math.hypot(FLASK_X[flask] - HOME[0], FLASK_Y - HOME[1])
    return dist / V_MAX + T_POUR_B


SKILL_TIME = np.array([skill_time(j) for j in range(N_FLASKS)])     # 3.5, 2.8, 2.5, 2.8, 3.5


def parse_stratum(name: str):
    """'M1_tight_0.15' -> (transient=True, tight=True, eta=0.15)."""
    m, t = name.split("_", 1)
    eta = ETAS[t]
    return m == "M1", eta is not None, eta


# ------------------------------------------------------------------ episodes
@dataclass(frozen=True)
class EpisodeBatch:
    flask: np.ndarray      # (N,) int
    t_a: np.ndarray        # (N,) float
    d: np.ndarray          # (N,) float

    def __len__(self) -> int:
        return int(self.flask.shape[0])


def draw_episode_batch(n: int, seed: int) -> EpisodeBatch:
    """Paired episode parameters: the same seed gives the same batch in every cell."""
    rng = np.random.default_rng(seed)
    return EpisodeBatch(flask=rng.integers(0, N_FLASKS, size=n),
                        t_a=rng.uniform(*T_A_RANGE, size=n),
                        d=rng.uniform(*D_RANGE, size=n))


# ------------------------------------------------------------------ tick timing perturbations
PERTURBATIONS = ("none", "tick_jitter", "rate_error")


def make_tick_times(n: int, n_steps: int = N_STEPS, kind: str = "none", level: float = 0.0,
                    seed: int = 0) -> np.ndarray:
    """Simulated time of every decision tick, shape (N, n_steps); t_0 = 0.

    none         uniform grid t_k = k * DT (the preregistered Gate 0 pilot)
    tick_jitter  dt_k = DT * (1 + u_k), u_k ~ U(-level, level) drawn per tick: a policy that
                 counts ticks accumulates a random-walk error, sigma_e ~ sqrt(n)
    rate_error   dt = DT * (1 + u), u ~ U(-level, level) drawn once per episode: a tick counter
                 is off by a fixed fraction of the interval, sigma_e ~ D (scalar timing)
    The referee, the timing oracle and the Track B clock always use these true times, so only
    a policy that measures time by counting ticks is affected.  Draws are seeded, so the same
    (n, seed) gives identical tick times in every cell: pairing is preserved.
    """
    if kind == "none" or level <= 0:
        return np.tile((np.arange(n_steps) * DT)[None, :], (n, 1))
    rng = np.random.default_rng(seed)
    if kind == "tick_jitter":
        dt = DT * (1.0 + rng.uniform(-level, level, size=(n, n_steps)))
    elif kind == "rate_error":
        dt = DT * (1.0 + rng.uniform(-level, level, size=(n, 1))) * np.ones((n, n_steps))
    else:
        raise ValueError(kind)
    t = np.cumsum(dt, axis=1) - dt[:, :1]                           # first tick at t = 0
    return t


def _times(eps: EpisodeBatch, tick_times: Optional[np.ndarray]) -> np.ndarray:
    if tick_times is None:
        return np.tile((np.arange(N_STEPS) * DT)[None, :], (len(eps), 1))
    if tick_times.shape[0] != len(eps):
        raise ValueError("tick_times must have one row per episode")
    return tick_times


# ------------------------------------------------------------------ observations and labels
def build_observations(eps: EpisodeBatch, transient: np.ndarray, tight: np.ndarray,
                       id_on: np.ndarray, tm_on: np.ndarray, clock_on: bool,
                       tick_times: Optional[np.ndarray] = None) -> np.ndarray:
    """Exogenous observation sequences, shape (N, T, OBS_DIM), float32.

    `transient`, `tight`, `id_on`, `tm_on` are boolean arrays of shape (N,).  Only the
    declared channels differ between strata and masks; everything else is identical for
    the same episode parameters (this is what the pairing gate in tests checks).
    `tick_times` (N, T) gives the simulated time of every tick; None is the uniform grid.
    """
    n = len(eps)
    t = _times(eps, tick_times)                                    # (N, T)
    n_steps = t.shape[1]
    t_a = eps.t_a[:, None]
    happened = t >= t_a                                            # (N, T)
    busy = (t >= t_a) & (t < t_a + T_POUR)
    onehot = np.eye(N_FLASKS, dtype=np.float32)[eps.flask]         # (N, 5)
    obs = np.zeros((n, n_steps, OBS_DIM), dtype=np.float32)
    persistent = ~transient
    obs[:, :, OBS_DYE] = (happened & persistent[:, None])[:, :, None] * onehot[:, None, :]
    obs[:, :, OBS_POURED] = busy[:, :, None] * onehot[:, None, :]
    obs[:, :, OBS_D] = np.where(tight, eps.d / TIME_SCALE, 0.0)[:, None]
    obs[:, :, OBS_TIGHT] = tight[:, None].astype(np.float32)
    obs[:, :, OBS_ID_KNOWN] = id_on[:, None].astype(np.float32)
    obs[:, :, OBS_ID] = (happened & id_on[:, None])[:, :, None] * onehot[:, None, :]
    obs[:, :, OBS_TM_KNOWN] = tm_on[:, None].astype(np.float32)
    obs[:, :, OBS_TM_HAPPENED] = (happened & tm_on[:, None]).astype(np.float32)
    obs[:, :, OBS_TM_ELAPSED] = np.where(happened & tm_on[:, None], (t - t_a) / TIME_SCALE, 0.0)
    if clock_on:
        obs[:, :, OBS_CLOCK] = (t / TIME_SCALE).astype(np.float32)
    return obs


def expert_labels(eps: EpisodeBatch, tight: np.ndarray, tick_times: Optional[np.ndarray] = None) -> np.ndarray:
    """Privileged per-tick expert decision, shape (N, T), int64 in [0, N_ACTIONS).

    The expert knows both latent facts and never reaches into the assistant's pour (the
    `busy` rule of chemrm.core_family.decide).  Relaxed: act on the flask from the first
    tick at which the assistant has left (t >= t_A + T_POUR); the skill then lands well
    clear of the pour.  Tight: act on the ticks whose landing time is within
    LABEL_HALF_WIDTH of t_A + D (inside every tier's window; these ticks are always after
    the pour because D >= 30 s).  Ticks outside those sets are labelled wait.  Because the
    scene is exogenous until the first act, the label at every tick is exactly what the
    expert would do there.
    """
    t = _times(eps, tick_times)
    landing = t + SKILL_TIME[eps.flask][:, None]                   # (N, T) t_B if acting now
    relaxed_ok = t >= (eps.t_a + T_POUR)[:, None]
    tight_ok = np.abs(landing - (eps.t_a + eps.d)[:, None]) <= LABEL_HALF_WIDTH
    act = np.where(tight[:, None], tight_ok, relaxed_ok)
    return np.where(act, 1 + eps.flask[:, None], 0).astype(np.int64)


def first_action(actions: np.ndarray):
    """From per-tick decisions (N, T) return (act_step, act_flask); -1 where never acted."""
    acted = actions > 0
    any_act = acted.any(axis=1)
    step = np.where(any_act, acted.argmax(axis=1), -1)
    flask = np.where(any_act, actions[np.arange(actions.shape[0]), np.maximum(step, 0)] - 1, -1)
    return step, flask


# ------------------------------------------------------------------ referee
def judge(eps: EpisodeBatch, tight: np.ndarray, eta: np.ndarray, act_step: np.ndarray,
          act_flask: np.ndarray, tick_times: Optional[np.ndarray] = None) -> Dict[str, np.ndarray]:
    """Fail-closed referee on the event facts (t_A, flask, D, t_B, chosen flask).

    `eta` holds the tolerance per episode (ignored where `tight` is False).  Returns the
    pass-vector fields plus t_b, t_min and the normalised speed s (nan where no B).  The
    decision tick is converted to simulated time through `tick_times` (true time, never the
    tick count), so a policy that counts ticks under a jittered clock is judged on the clock.
    """
    added = act_step >= 0
    t = _times(eps, tick_times)
    n_steps = t.shape[1]
    idx = np.clip(np.maximum(act_step, 0), 0, n_steps - 1)
    rows = np.arange(len(eps))
    # ticks beyond the recorded horizon (only reachable by hand-built inputs) extrapolate at the nominal DT
    t_dec = t[rows, idx] + np.maximum(act_step - (n_steps - 1), 0) * DT
    t_b = np.where(added, t_dec + SKILL_TIME[np.maximum(act_flask, 0)], np.nan)
    right_flask = added & (act_flask == eps.flask)
    after_pour = added & (t_b >= eps.t_a + T_POUR)
    target = eps.t_a + eps.d
    eps_abs = np.where(tight, eta * eps.d, np.inf)
    in_window = added & (np.abs(np.nan_to_num(t_b, nan=-1e9) - target) <= eps_abs)
    protocol = right_flask & after_pour
    time_ok = np.where(tight, in_window, added)
    goal = protocol & time_ok
    early = added & tight & (np.nan_to_num(t_b, nan=1e9) < target - eps_abs)
    smoke = added & (~right_flask | ~after_pour | early)
    t_min = np.where(tight, target - eps_abs, eps.t_a + T_POUR)
    s_norm = np.where(added, t_min / np.where(added, t_b, 1.0), np.nan)
    return {
        "valid": np.ones_like(added), "goal": goal, "protocol": protocol, "time": time_ok,
        "safety": ~smoke, "quantity": np.ones_like(added), "added": added,
        "t_b": t_b, "t_min": t_min, "s_norm": s_norm,
    }


# ------------------------------------------------------------------ cells
def cell_arrays(n: int, stratum: str, mask: str):
    """Per-episode factor arrays for one (stratum, mask) cell."""
    transient, tight, eta = parse_stratum(stratum)
    return (np.full(n, transient), np.full(n, tight), np.full(n, eta if eta is not None else 0.0),
            np.full(n, mask in ("identity", "both")), np.full(n, mask in ("timing", "both")))


def run_expert_cell(eps: EpisodeBatch, stratum: str, tick_times: Optional[np.ndarray] = None) -> Dict[str, np.ndarray]:
    """Expert acceptance check for one stratum (proposal: >= 95% ChemSSR inside the ranges)."""
    transient, tight, eta, _, _ = cell_arrays(len(eps), stratum, "none")
    step, flask = first_action(expert_labels(eps, tight, tick_times))
    return judge(eps, tight, eta, step, flask, tick_times)
