"""Run the frame-level gates (proposal 3.5, gates 8 and 9) on the Gate 0 environment.

Gate 8 (temporal aliasing) is applied to Track A, mask `none`, post-cue frames of every
stratum: elapsed time since the pour must not be predictable from a single frame.  Three
positive controls show that the same statistic does detect a clock when one is present:
the Track B timestamp channel, the timing oracle, and a synthetic "spreading dye" feature
exp(-elapsed / 30 s) appended to the Track A frame.

Gate 9 (cue detectability) is applied to every stratum on all frames: a stateless probe must
detect the assistant's pour while it happens and name the receiving flask.  The negative
control blinds the `poured` channel, which is what a pixel policy would face if the pour
were occluded by the assistant's arm.

    python3 -m chemrm.gate0.leak_audit --out pilot/gate0/results
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Dict, List

for _var in ("OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
    os.environ.setdefault(_var, "1")            # must precede the numpy import to take effect

import numpy as np

from chemrm.core_family import T_POUR
from chemrm.gates import GateResult, cue_detectability_gate, temporal_aliasing_gate
from chemrm.gate0.env import (DT, HARDEST, OBS_POURED, STRATA, build_observations, cell_arrays,
                              draw_episode_batch)

AUDIT_SEED = 20260906
N_EPISODES = 200
R2_MAX = 0.05
ACC_MIN = 0.95


def _frames(stratum: str, mask: str, clock_on: bool, n: int, seed: int):
    eps = draw_episode_batch(n, seed)
    transient, tight, _eta, id_on, tm_on = cell_arrays(n, stratum, mask)
    obs = build_observations(eps, transient, tight, id_on, tm_on, clock_on)   # (N, T, F)
    n_steps = obs.shape[1]
    t = np.arange(n_steps) * DT
    elapsed = t[None, :] - eps.t_a[:, None]                                   # (N, T)
    busy = (elapsed >= 0) & (elapsed < T_POUR)
    flask = np.repeat(eps.flask[:, None], n_steps, axis=1)
    return obs, elapsed, busy, flask


def temporal_audit(stratum: str, mask: str, clock_on: bool, n: int = N_EPISODES,
                   seed: int = AUDIT_SEED, synthetic_dye: bool = False) -> GateResult:
    obs, elapsed, _busy, _flask = _frames(stratum, mask, clock_on, n, seed)
    post = elapsed >= T_POUR                                                  # cue window over
    frames = obs[post]
    e = elapsed[post]
    if synthetic_dye:
        frames = np.concatenate([frames, np.exp(-e / 30.0)[:, None]], axis=1)
    return temporal_aliasing_gate(frames, e, r2_max=R2_MAX, seed=seed)


def cue_audit(stratum: str, n: int = N_EPISODES, seed: int = AUDIT_SEED,
              blind_poured: bool = False) -> GateResult:
    obs, _elapsed, busy, flask = _frames(stratum, "none", False, n, seed)
    frames = obs.reshape(-1, obs.shape[-1]).copy()
    if blind_poured:
        frames[:, OBS_POURED] = 0.0
    return cue_detectability_gate(frames, busy.reshape(-1), flask.reshape(-1), acc_min=ACC_MIN, seed=seed)


def run(out_dir: Path, n: int = N_EPISODES, seed: int = AUDIT_SEED) -> Dict:
    rows: List[Dict] = []
    for s in STRATA:
        rows.append({"gate": 8, "role": "gate", "stratum": s, "condition": "Track A, mask none",
                     **temporal_audit(s, "none", False, n, seed).to_dict()})
    rows.append({"gate": 8, "role": "positive control", "stratum": HARDEST, "condition": "Track B clock channel",
                 **temporal_audit(HARDEST, "none", True, n, seed).to_dict()})
    rows.append({"gate": 8, "role": "positive control", "stratum": HARDEST, "condition": "timing oracle",
                 **temporal_audit(HARDEST, "timing", False, n, seed).to_dict()})
    rows.append({"gate": 8, "role": "positive control", "stratum": HARDEST,
                 "condition": "Track A + synthetic spreading dye exp(-elapsed/30 s)",
                 **temporal_audit(HARDEST, "none", False, n, seed, synthetic_dye=True).to_dict()})
    for s in STRATA:
        rows.append({"gate": 9, "role": "gate", "stratum": s, "condition": "Track A, mask none",
                     **cue_audit(s, n, seed).to_dict()})
    rows.append({"gate": 9, "role": "negative control", "stratum": HARDEST, "condition": "poured channel blinded",
                 **cue_audit(HARDEST, n, seed, blind_poured=True).to_dict()})
    summary = {"seed": seed, "n_episodes": n, "r2_max": R2_MAX, "acc_min": ACC_MIN, "rows": rows,
               "all_gates_pass": all(r["passed"] for r in rows if r["role"] == "gate"),
               "controls_behave": all((r["passed"] is False) for r in rows if r["role"] == "positive control")
               and all((r["passed"] is False) for r in rows if r["role"] == "negative control")}
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "leak_audit.json").write_text(json.dumps(summary, indent=1))
    (out_dir / "leak_audit.md").write_text(render(summary))
    return summary


def render(summary: Dict) -> str:
    lines = ["# Frame-level gates on the Gate 0 environment (gates 8 and 9)", "",
             f"Seed {summary['seed']}, {summary['n_episodes']} episodes per cell, 5-fold probes. "
             f"Gate 8 passes when out-of-fold R^2 <= {summary['r2_max']}; gate 9 passes when presence "
             f"balanced accuracy and identity accuracy are both >= {summary['acc_min']}.", "",
             "| Gate | Role | Stratum | Condition | Statistic | Threshold | Frames | Pass |",
             "|---|---|---|---|---|---|---|---|"]
    for r in summary["rows"]:
        stat = f"R^2 = {r['statistic']:.3f}" if r["gate"] == 8 else (
            f"presence {r['detail']['presence_balanced_acc']:.3f}, identity {r['detail'].get('identity_acc', float('nan')):.3f}")
        thr = f"<= {r['threshold']}" if r["gate"] == 8 else f">= {r['threshold']}"
        lines.append(f"| {r['gate']} | {r['role']} | {r['stratum']} | {r['condition']} | {stat} | {thr} | {r['n']} | "
                     f"{'yes' if r['passed'] else 'no'} |")
    lines += ["", f"All gates pass: {summary['all_gates_pass']}.  Controls behave (positive controls fail the gate, "
              f"negative control fails the gate): {summary['controls_behave']}.", ""]
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="pilot/gate0/results")
    ap.add_argument("--n", type=int, default=N_EPISODES)
    ap.add_argument("--seed", type=int, default=AUDIT_SEED)
    a = ap.parse_args()
    s = run(Path(a.out), a.n, a.seed)
    print(render(s))


if __name__ == "__main__":
    main()
