"""Behaviour cloning for one (condition, training seed) run of the Gate 0 pilot.

Data.  Episodes are drawn from the training seed; each episode is assigned a stratum
(uniform over the eight) and an oracle mask (uniform over the four: the fixed oracle-mask
schema of proposal 5.1, H3).  Because the scene is exogenous until the first act, the
expert label is defined at every tick and the whole trajectory is a supervised sequence.
Cross-entropy over all ticks, with one re-weighting: the act ticks of TIGHT episodes carry
weight ACT_WEIGHT_TIGHT (they are about 1% of a tight episode, four ticks around
t_A + D - skill_time, and plain CE does not push their probability past the argmax
threshold within the budget).  The weight is deliberately NOT applied to relaxed episodes:
their act ticks are abundant, and a global act weight would tip the ambiguous "empty
scene" observation (identical before the pour in every stratum and after the pour in M1)
towards acting, which would destroy the M0_relaxed ceiling of the stateless condition for a
training artefact rather than a design reason.  Where the observation determines the
expert's decision the network can reach it; where it does not (a masked fact) it learns the
weighted conditional frequency, the honest behaviour of a policy lacking that fact.

Optimiser and budget are identical across conditions: Adam 1e-3 with cosine annealing to
LR_MIN over the fixed number of epochs, batch 64, gradient clipping at 5.  Training episodes
never overlap the evaluation draws (different seed streams).
"""
from __future__ import annotations

import argparse
import json
import os
import time
from typing import Dict, Tuple

import numpy as np
import torch
import torch.nn.functional as F
from typing import Optional

from chemrm.gate0.env import (MASKS, N_STEPS, STRATA, EpisodeBatch, build_observations, cell_arrays,
                              draw_episode_batch, expert_labels, make_tick_times, parse_stratum)
from chemrm.gate0.policies import CONDITIONS, make_policy, n_parameters

TRAIN_SEED_BASE = 1_000_000      # training draws live far from the evaluation seed stream
ACT_WEIGHT_TIGHT = 10.0          # loss weight of act ticks in tight episodes (see module docstring)
LR_MIN = 5e-5                    # cosine-annealing floor
NO_PERTURB = {"kind": "none", "level": 0.0, "n_steps": N_STEPS}


def make_dataset(n: int, seed: int, clock: bool, perturb: Optional[Dict] = None) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict]:
    """Observations (N, T, 22), labels (N, T), tick weights (N, T), per-episode cell assignment.

    `perturb` = {"kind": none|tick_jitter|rate_error, "level": float, "n_steps": int} applies a
    clock perturbation to the training episodes (the exploratory noise add-on); the expert
    labels and every time-valued channel use the true tick times.
    """
    perturb = perturb or NO_PERTURB
    eps = draw_episode_batch(n, TRAIN_SEED_BASE + seed)
    rng = np.random.default_rng(TRAIN_SEED_BASE + 7 * seed + 1)
    strat_idx = rng.integers(0, len(STRATA), size=n)
    mask_idx = rng.integers(0, len(MASKS), size=n)
    transient = np.array([parse_stratum(STRATA[i])[0] for i in strat_idx])
    tight = np.array([parse_stratum(STRATA[i])[1] for i in strat_idx])
    id_on = np.isin(mask_idx, [1, 3])
    tm_on = np.isin(mask_idx, [2, 3])
    ticks = make_tick_times(n, perturb["n_steps"], perturb["kind"], perturb["level"], seed=TRAIN_SEED_BASE + 13 * seed + 5)
    obs = build_observations(eps, transient, tight, id_on, tm_on, clock, tick_times=ticks)
    labels = expert_labels(eps, tight, tick_times=ticks)
    weights = np.where((labels > 0) & tight[:, None], ACT_WEIGHT_TIGHT, 1.0).astype(np.float32)
    return obs, labels, weights, {"strata": strat_idx, "masks": mask_idx}


def train(condition: str, seed: int, out_path: str, n_train: int = 8000, epochs: int = 60,
          batch: int = 64, lr: float = 1e-3, threads: int = 2, log_every: int = 200,
          perturb: Optional[Dict] = None) -> Dict:
    torch.set_num_threads(threads)
    torch.manual_seed(seed)
    np.random.seed(seed)
    spec = CONDITIONS[condition]
    perturb = perturb or NO_PERTURB
    obs, labels, weights, _ = make_dataset(n_train, seed, spec["clock"], perturb)
    obs_t = torch.from_numpy(obs)
    lab_t = torch.from_numpy(labels)
    w_t = torch.from_numpy(weights)
    model = make_policy(condition)
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs, eta_min=LR_MIN)
    n = obs_t.shape[0]
    step = 0
    history = []
    t0 = time.time()
    g = torch.Generator().manual_seed(seed)
    for epoch in range(epochs):
        perm = torch.randperm(n, generator=g)
        running = 0.0
        for i in range(0, n, batch):
            idx = perm[i:i + batch]
            logits = model(obs_t[idx])
            per_tick = F.cross_entropy(logits.reshape(-1, logits.shape[-1]), lab_t[idx].reshape(-1),
                                       reduction="none")
            w = w_t[idx].reshape(-1)
            loss = (per_tick * w).sum() / w.sum()
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            running += float(loss) * idx.shape[0]
            step += 1
            if log_every and step % log_every == 0:
                print(f"[{condition} s{seed}] epoch {epoch} step {step} loss {float(loss):.4f} "
                      f"({time.time() - t0:.0f}s)", flush=True)
        history.append(running / n)
        sched.step()
    meta = {
        "condition": condition, "seed": seed, "n_train": n_train, "epochs": epochs,
        "batch": batch, "lr": lr, "lr_min": LR_MIN, "act_weight_tight": ACT_WEIGHT_TIGHT,
        "perturb": perturb, "n_parameters": n_parameters(model),
        "epoch_loss": history, "wall_s": round(time.time() - t0, 1),
        "torch": torch.__version__,
    }
    os.makedirs(os.path.dirname(out_path) or ".", exist_ok=True)
    torch.save({"state_dict": model.state_dict(), "meta": meta}, out_path)
    with open(out_path + ".json", "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=2)
    return meta


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("condition", choices=sorted(CONDITIONS))
    ap.add_argument("seed", type=int)
    ap.add_argument("--out", required=True)
    ap.add_argument("--n-train", type=int, default=8000)
    ap.add_argument("--epochs", type=int, default=60)
    ap.add_argument("--threads", type=int, default=2)
    a = ap.parse_args()
    meta = train(a.condition, a.seed, a.out, n_train=a.n_train, epochs=a.epochs, threads=a.threads)
    print(json.dumps({k: v for k, v in meta.items() if k != "epoch_loss"}, indent=1))


if __name__ == "__main__":
    main()
