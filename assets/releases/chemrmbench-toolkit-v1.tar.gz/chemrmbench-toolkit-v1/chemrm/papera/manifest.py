"""Frozen public task manifests for Paper A split evaluation.

The manifest builder accepts only declared task registrations and public YAML sources. It has no
result, verifier, policy, or hidden-task input, so split assignment is frozen before evaluation.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from chemrm.papera.spec import load_benchmark_task
from chemrm.task_program import NOVELTY_AXES, SPLITS, TaskProgram


SCHEMA_VERSION = "paper-a-task-manifest-0.1"
GENERATOR_ID = "paper-a-public-task-manifest"
GENERATOR_VERSION = "1"
REQUIRED_FILES = ("manifest.json", "tasks.jsonl")


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _canonical_hash(value: Mapping[str, Any]) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    return hashlib.sha256(encoded).hexdigest()


@dataclass(frozen=True)
class TaskRegistration:
    """A pre-registered public source and split label.

    ``novelty_axes`` is a declaration of what is held out; it is not inferred from evaluation
    outcomes. The registration file must be frozen before running a policy.
    """

    task_id: str
    source: str | Path
    split: str = "closed"
    seed: int = 0
    novelty_axes: frozenset[str] = frozenset()

    def __post_init__(self) -> None:
        if not self.task_id.strip():
            raise ValueError("task_id must be non-empty")
        if self.split not in SPLITS:
            raise ValueError(f"unknown split {self.split!r}; expected one of {sorted(SPLITS)}")
        if int(self.seed) < 0:
            raise ValueError("task seed must be non-negative")
        axes = frozenset(self.novelty_axes)
        bad = axes - NOVELTY_AXES
        if bad:
            raise ValueError(f"unknown novelty axes: {sorted(bad)}")
        if self.split == "closed" and axes:
            raise ValueError("closed registrations cannot declare novelty axes")
        if self.split != "closed" and not axes:
            raise ValueError(f"{self.split} registrations need at least one novelty axis")
        object.__setattr__(self, "seed", int(self.seed))
        object.__setattr__(self, "novelty_axes", axes)


@dataclass(frozen=True)
class ManifestTask:
    task: TaskProgram
    source_name: str
    source_sha256: str

    def to_dict(self) -> dict[str, Any]:
        task_dict = self.task.to_dict()
        return {
            "task": task_dict,
            "task_sha256": _canonical_hash(task_dict),
            "source_name": self.source_name,
            "source_sha256": self.source_sha256,
        }


def load_registered_tasks(registrations: Iterable[TaskRegistration], *, base_dir: str | Path = ".") -> tuple[ManifestTask, ...]:
    """Load and freeze public task programs from a declaration-only registry."""
    root = Path(base_dir)
    loaded: list[ManifestTask] = []
    seen: set[str] = set()
    for registration in registrations:
        if registration.task_id in seen:
            raise ValueError(f"duplicate registered task id: {registration.task_id}")
        seen.add(registration.task_id)
        source = Path(registration.source)
        if not source.is_absolute():
            source = root / source
        if not source.is_file() or source.is_symlink():
            raise ValueError(f"task source must be a regular file: {source}")
        benchmark = load_benchmark_task(source, split=registration.split, seed=registration.seed)
        if benchmark.program.task_id != registration.task_id:
            raise ValueError(
                f"registration id {registration.task_id!r} does not match source task "
                f"{benchmark.program.task_id!r}"
            )
        task = replace(benchmark.program, novelty_axes=registration.novelty_axes)
        loaded.append(ManifestTask(task, benchmark.source_name, _sha256(source)))
    if not loaded:
        raise ValueError("at least one task registration is required")
    return tuple(sorted(loaded, key=lambda item: item.task.task_id))


@dataclass(frozen=True)
class FrozenTaskManifest:
    manifest_id: str
    manifest_sha256: str
    task_index_sha256: str
    tasks: tuple[ManifestTask, ...]
    provenance: Mapping[str, Any]
    semantic_grammar: Any = None


def _sha256_text(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def _pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError(f"duplicate JSON key {key!r}")
        result[key] = value
    return result


def _constant(value):
    raise ValueError(f"non-finite JSON constant {value}")


def _json(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _parse_snapshot(manifest_bytes: bytes, index_bytes: bytes) -> FrozenTaskManifest:
    try:
        manifest = json.loads(manifest_bytes.decode("utf-8"), object_pairs_hook=_pairs, parse_constant=_constant)
        lines = index_bytes.decode("utf-8").splitlines()
        if not 1 <= len(lines) <= 10000:
            raise ValueError("manifest index must have 1..10000 tasks")
        rows = [json.loads(line, object_pairs_hook=_pairs, parse_constant=_constant) for line in lines]
        required = {"schema_version", "generator_id", "generator_version", "manifest_id", "public_only",
                    "task_count", "split_counts", "task_index", "task_index_sha256"}
        if not isinstance(manifest, Mapping) or not required <= set(manifest) or set(manifest) - required - {"provenance"}:
            raise ValueError("invalid manifest object or fields")
        if (manifest["schema_version"] != SCHEMA_VERSION or manifest["generator_id"] != GENERATOR_ID
                or manifest["generator_version"] != GENERATOR_VERSION or manifest["public_only"] is not True):
            raise ValueError("manifest schema/generator/public_only mismatch")
        if not isinstance(manifest["manifest_id"], str) or not manifest["manifest_id"].strip():
            raise ValueError("manifest_id must be a non-empty string")
        index_hash = hashlib.sha256(index_bytes).hexdigest()
        if manifest["task_index"] != "tasks.jsonl" or manifest["task_index_sha256"] != index_hash:
            raise ValueError("tasks.jsonl hash mismatch")
        if type(manifest["task_count"]) is not int or manifest["task_count"] != len(rows):
            raise ValueError("task_count mismatch")
        provenance = manifest.get("provenance", {})
        if not isinstance(provenance, Mapping):
            raise ValueError("provenance must be an object")
        grammar = None
        if provenance.get("kind") in {"public_grammar", "public_semantic_grammar"}:
            if (not _sha256_text(provenance.get("grammar_sha256"))
                    or not isinstance(provenance.get("grammar_id"), str) or not provenance["grammar_id"].strip()):
                raise ValueError("public grammar provenance is incomplete")
        if provenance.get("kind") == "public_semantic_grammar":
            from chemrm.papera.semantics import SemanticGrammar
            grammar = SemanticGrammar.from_dict(provenance["grammar"])
            if (grammar.grammar_id != provenance["grammar_id"] or grammar.sha256 != provenance["grammar_sha256"]
                    or _canonical_hash(provenance["grammar"]) != grammar.sha256):
                raise ValueError("embedded semantic grammar identity/hash mismatch")
        entries, ids, signatures = [], [], set()
        counts = {split: 0 for split in sorted(SPLITS)}
        for number, row in enumerate(rows, 1):
            try:
                if not isinstance(row, Mapping) or set(row) != {"task", "task_sha256", "source_name", "source_sha256"}:
                    raise ValueError("invalid task row object or fields")
                if (not isinstance(row["task"], Mapping) or not _sha256_text(row["source_sha256"])
                        or not isinstance(row["source_name"], str) or not row["source_name"].strip()):
                    raise ValueError("invalid task/source provenance")
                task = TaskProgram.from_dict(row["task"])
                if _json(row["task"]) != task.canonical_json() or task.seed < 0:
                    raise ValueError("task must use canonical non-negative integer fields")
                if any(type(value) is not int or value < 0 for value in task.counts.values()):
                    raise ValueError("object counts must be non-negative integers")
                if row["task_sha256"] != _canonical_hash(row["task"]):
                    raise ValueError("task hash mismatch")
                if (task.split == "closed" and task.novelty_axes) or (task.split != "closed" and not task.novelty_axes):
                    raise ValueError("closed has no axes; held-out tasks require axes")
                if grammar is not None or task.public_spec_version == "paper-a-public-grammar-2":
                    from chemrm.papera.semantics import semantic_signature, validate_semantic_task
                    if grammar is None:
                        raise ValueError("semantic tasks require an embedded grammar")
                    if row["source_name"] != "grammar:" + grammar.grammar_id or row["source_sha256"] != grammar.sha256:
                        raise ValueError("semantic task/source grammar binding mismatch")
                    validate_semantic_task(task, grammar)
                    signature = semantic_signature(task)
                    if signature in signatures:
                        raise ValueError("duplicate semantic task under different labels")
                    signatures.add(signature)
                entries.append(ManifestTask(task, row["source_name"], row["source_sha256"]))
                ids.append(task.task_id)
                counts[task.split] += 1
            except (KeyError, TypeError, ValueError, AttributeError, OverflowError, RecursionError) as exc:
                raise ValueError(f"row {number}: invalid task: {exc}") from exc
        if len(set(ids)) != len(ids) or ids != sorted(ids):
            raise ValueError("task IDs must be unique and index sorted by task_id")
        if manifest["split_counts"] != counts or any(type(v) is not int for v in manifest["split_counts"].values()):
            raise ValueError("split_counts mismatch")
        return FrozenTaskManifest(manifest["manifest_id"], hashlib.sha256(manifest_bytes).hexdigest(), index_hash,
                                  tuple(entries), dict(provenance), grammar)
    except (KeyError, TypeError, AttributeError, UnicodeError, OverflowError, RecursionError) as exc:
        raise ValueError(f"invalid manifest JSON/schema: {type(exc).__name__}") from exc


def load_task_manifest(manifest_dir: str | Path) -> FrozenTaskManifest:
    """Validate and return the same byte snapshot used for hashes; never regenerate tasks."""
    root = Path(manifest_dir)
    if not root.is_dir() or root.is_symlink():
        raise ValueError(f"manifest directory must be a regular directory: {root}")
    loaded = {}
    for name, limit in (("manifest.json", 2 * 1024 * 1024), ("tasks.jsonl", 16 * 1024 * 1024)):
        path = root / name
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"manifest requires a regular file: {name}")
        if path.stat().st_size > limit:
            raise ValueError(f"{name} exceeds declared size limit")
        with path.open("rb") as handle:
            raw = handle.read(limit + 1)
        if len(raw) > limit:
            raise ValueError(f"{name} exceeds declared size limit")
        loaded[name] = raw
    return _parse_snapshot(loaded["manifest.json"], loaded["tasks.jsonl"])


def write_task_manifest(tasks: Sequence[ManifestTask], out_dir: str | Path, *, manifest_id: str,
                        provenance: Mapping[str, Any] | None = None) -> Path:
    """Freeze validated public tasks into a new directory; never overwrite a prior release."""
    if not isinstance(manifest_id, str) or not manifest_id.strip():
        raise ValueError("manifest_id must be non-empty")
    ordered = tuple(sorted(tasks, key=lambda item: item.task.task_id))
    if not ordered:
        raise ValueError("at least one task is required")
    index_bytes = "".join(_json(item.to_dict()) + "\n" for item in ordered).encode("utf-8")
    manifest = {"schema_version": SCHEMA_VERSION, "generator_id": GENERATOR_ID,
                "generator_version": GENERATOR_VERSION, "manifest_id": manifest_id, "public_only": True,
                "task_count": len(ordered), "task_index": "tasks.jsonl",
                "task_index_sha256": hashlib.sha256(index_bytes).hexdigest(),
                "split_counts": {split: sum(item.task.split == split for item in ordered) for split in sorted(SPLITS)}}
    if provenance is not None:
        manifest["provenance"] = dict(provenance)
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n").encode("utf-8")
    if len(index_bytes) > 16 * 1024 * 1024 or len(manifest_bytes) > 2 * 1024 * 1024:
        raise ValueError("manifest exceeds declared size limit")
    _parse_snapshot(manifest_bytes, index_bytes)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=False)
    (out / "tasks.jsonl").write_bytes(index_bytes)
    (out / "manifest.json").write_bytes(manifest_bytes)
    return out


def verify_task_manifest(manifest_dir: str | Path) -> tuple[bool, tuple[str, ...]]:
    """Fail closed for malformed files; v1 labels remain declaration-only legacy fixtures."""
    try:
        load_task_manifest(manifest_dir)
    except (ValueError, OSError) as exc:
        return False, (str(exc),)
    return True, ()
