"""Frozen CPU benchmark releases and independent, world-free verdict replay.

Supported backends have fixed development scopes. Success never promotes them
to calibrated physics, a formal memory sample or a full benchmark release.
"""
from collections import Counter
import importlib.metadata
import json
import math
from pathlib import Path
import platform
import re

from chemrm.events import Event
from chemrm.papera.contract import ActionRecord, ObservationRecord, Trace, verify_bundle
from chemrm.papera.frozen_execution import ExecutionCase, build_manifest_cases
from chemrm.papera.generated_world import GeneratedGoalPolicy, generated_verifier
from chemrm.papera.manifest import ManifestTask, load_task_manifest, write_task_manifest
from chemrm.papera.runner import run_episode, ReadOnlyConstraintVerifier
from chemrm.papera.semantics import TASK_VERSION
from chemrm.papera.task_worlds import load_f0_task, make_task_case
from chemrm.papera.thermal_dose import ThermalDosePolicy, ThermalDoseVerifier, thermal_dose_spec
from chemrm.papera import release_io_v1 as io

SCHEMA = 'chemrmbench-release-v1'
SPLITS = ('closed','compositional-held-out','open')
ADMISSION = dict(scientific_admission=False,training_admission=False,
                 formal_M1_admission=False,full_benchmark_pass=False)
BACKENDS = {'graph-contract':'symbolic-goal-graph-contract',
            'task-contract':'symbolic-event-duration-memory-contract',
            'thermal-dose':'synthetic-uncalibrated-process-diagnostic'}


class AbstainPolicy:
    policy_id='chemrm-abstention-control-v1'
    policy_hash='sha256:'+io.sha(b'chemrm-abstention-control-v1')
    def reset(self, task, seed):pass
    def act(self, observation):return {'kind':'wait'}


def _capabilities(backend):
    return dict(syntax='PASS_FROZEN_MANIFEST',causality='PASS_DECLARED_TASK_SEMANTICS',
                geometry='UNEVALUATED',native_dynamics='UNEVALUATED',
                calibrated_chemistry='UNEVALUATED',pixel_memory_leakage='UNEVALUATED',
                task_space_scope='PUBLIC_GRAPH_FIXTURE_ONLY' if backend=='graph-contract' else 'CLOSED_DIAGNOSTIC_ONLY',
                evidence_scope=BACKENDS[backend])


def _task_contract(task):
    if task.split!='closed' or task.novelty_axes:
        raise ValueError('YAML task-contract accepts closed diagnostics only')
    original=load_f0_task(task.task_id, task.seed)
    if not io.same(original.program.to_dict(),task.to_dict()):
        raise ValueError('task differs from seeded YAML task contract')
    return original


def _cases(snapshot, backend):
    if backend!='task-contract':return build_manifest_cases(snapshot,backend)
    cases=[]
    for entry in snapshot.tasks:
        _task_contract(entry.task)
        source=Path(__file__).resolve().parents[1]/'tasks'/entry.source_name
        if source.parent!=Path(__file__).resolve().parents[1]/'tasks' or not source.is_file() or io.sha(source.read_bytes())!=entry.source_sha256:
            raise ValueError('YAML task source binding differs')
        case=make_task_case(entry.task.task_id, entry.task.seed)
        cases.append(ExecutionCase(entry.task,case.world,case.policy,case.verifier()))
    return tuple(cases)


def _verifier(task, snapshot, backend):
    if backend=='graph-contract':
        if task.public_spec_version not in ('paper-a-public-grammar-1',TASK_VERSION):
            raise ValueError('graph verifier requires registered graph task semantics')
        return generated_verifier(task,semantic_grammar=snapshot.semantic_grammar)
    if backend=='thermal-dose':
        thermal_dose_spec(task);return ThermalDoseVerifier(task)
    spec=_task_contract(task)
    return ReadOnlyConstraintVerifier(spec.constraints,task.goals)


def _policy_identity(task, backend, mode):
    if mode=='abstain':return AbstainPolicy.policy_id,AbstainPolicy.policy_hash
    if backend=='graph-contract':return GeneratedGoalPolicy.policy_id,GeneratedGoalPolicy.policy_hash
    if backend=='thermal-dose':
        pid=ThermalDosePolicy.policy_id
        config=json.dumps(dict(policy_id=pid,rate_ml_s=10.0 if mode=='high-rate' else 0.2,dose_fraction=1.0),sort_keys=True,separators=(',',':'))
        return pid,'sha256:'+io.sha(config.encode())
    from chemrm.papera.task_worlds import C5EndpointPolicy,C6StirringPolicy,C13MemoryTimePolicy
    cls={'C5':C5EndpointPolicy,'C6':C6StirringPolicy,'C13':C13MemoryTimePolicy}[task.task_id]
    return cls.policy_id,cls.policy_hash


def source_identity():
    package=Path(__file__).resolve().parents[1]
    files={}
    for p in sorted(package.rglob('*')):
        if p.is_file() and p.suffix in ('.py','.yaml') and '__pycache__' not in p.parts:
            files[p.relative_to(package.parent).as_posix()]=io.sha(p.read_bytes())
    return dict(schema='chemrm-release-source-v1',files=files,
                python=platform.python_version(),
                dependencies={name:importlib.metadata.version(name) for name in ('numpy','PyYAML')})


def freeze_task_contract(out_dir, seed=19):
    if type(seed) is not int or seed<0:raise ValueError('nonnegative typed seed required')
    package=Path(__file__).resolve().parents[1]
    filenames={'C5':'c05_endpoint_stop.yaml','C6':'c06_timed_stirring.yaml','C13':'c13_memory_time_hero.yaml'}
    entries=tuple(ManifestTask(load_f0_task(name,seed).program,filename,
                               io.sha((package/'tasks'/filename).read_bytes()))
                  for name,filename in filenames.items())
    return write_task_manifest(entries,out_dir,manifest_id=f'chemrm-task-contract-seed{seed}')


def _configuration(release_id,backend,policy,max_steps):
    if type(release_id) is not str or not re.fullmatch('[a-z][a-z0-9_-]{0,79}',release_id):
        raise ValueError('bounded canonical release identifier required')
    if backend not in BACKENDS or policy not in ('reference','abstain','high-rate'):
        raise ValueError('registered backend and policy required')
    if policy=='high-rate' and backend!='thermal-dose':
        raise ValueError('high-rate control is registered only for thermal-dose')
    if type(max_steps) is not int or not 1<=max_steps<=100000:
        raise ValueError('max_steps must be an integer in 1..100000')
    return dict(schema=SCHEMA,release_id=release_id,backend=backend,policy=policy,max_steps=max_steps)


def _summary(config, rows):
    splits={s:dict(episodes=0,valid=0,successful=0) for s in SPLITS}
    failures=Counter()
    for row in rows:
        item=splits[row['split']];pv=row['verdict']['pass_vector']
        item['episodes']+=1;item['valid']+=int(pv['valid']);item['successful']+=int(pv['chem_ssr'])
        failures.update(set(f['kind'] for f in row['verdict']['failure_vector']))
    return dict(schema=SCHEMA,release_id=config['release_id'],splits=splits,
                failure_episode_counts=dict(sorted(failures.items())),admission=ADMISSION.copy(),
                native_workers=0,model_calls=0,training_jobs=0,
                statistical_scope='Descriptive contract instances; not independent native samples or causal effects')


def _replay(root, task, snapshot, config):
    check=verify_bundle(root)
    if not check.ok:raise ValueError('episode bundle invalid: '+';'.join(check.errors))
    meta=io.read(root,'manifest.json');terminal=io.read(root,'execution.json')
    if not io.same(io.read(root,'task.json'),task.to_dict()):raise ValueError('frozen episode task differs')
    verifier=_verifier(task,snapshot,config['backend'])
    pid,phash=_policy_identity(task,config['backend'],config['policy'])
    if (meta['task_id'],meta['seed'],meta['split'],meta['policy_id'],meta['policy_hash'],meta['verifier_id'])!=(
        task.task_id,task.seed,task.split,pid,phash,verifier.verifier_id):
        raise ValueError('episode identity differs from frozen task/backend/policy')
    if type(meta['seed']) is not int or type(meta['completed']) is not bool:
        raise ValueError('typed episode seed and termination required')
    if (set(terminal)!={'end_time_s','completed','stop_reason','error'} or
        type(terminal['completed']) is not bool or type(terminal['stop_reason']) is not str or
        (terminal['error'] is not None and type(terminal['error']) is not str) or
        any(terminal[k]!=meta[k] for k in ('completed','stop_reason','error')) or
        type(terminal['end_time_s']) not in (int,float) or not math.isfinite(terminal['end_time_s']) or terminal['end_time_s']<0):
        raise ValueError('terminal execution state differs')
    def rows(name):
        return [io.parse(line) for line in io.read_bytes(root,name).splitlines()]
    obs=rows('observations.jsonl');actions=rows('actions.jsonl');events=rows('events.jsonl')
    if len(actions)>config['max_steps'] or len(obs)!=len(actions):raise ValueError('episode action budget differs')
    previous=0
    for index,(o,a) in enumerate(zip(obs,actions)):
        if (set(o)!={'step','t','observation'} or set(a)!={'step','t','action'} or
            type(o['step']) is not int or type(a['step']) is not int or o['step']!=a['step'] or o['step']!=index or
            type(o['t']) not in (float,int) or type(a['t']) not in (float,int) or
            o['t']!=a['t'] or not previous<=o['t']<=terminal['end_time_s'] or
            type(o['observation']) is not dict or type(a['action']) is not dict):
            raise ValueError('paired observation/action sequence differs')
        previous=o['t']
    for event in events:
        if (set(event)!={'kind','t','payload'} or type(event['kind']) is not str or
            type(event['payload']) is not dict or type(event['t']) not in (int,float) or
            not 0<=event['t']<=terminal['end_time_s']):raise ValueError('event stream differs')
    trace=Trace(task,task.seed,pid,phash,verifier.verifier_id,
                tuple(ObservationRecord(o['step'],o['t'],o['observation']) for o in obs),
                tuple(ActionRecord(a['step'],a['t'],a['action']) for a in actions),
                tuple(Event(e['kind'],e['t'],e['payload']) for e in events),
                terminal['end_time_s'],meta['completed'],meta['stop_reason'],meta['error'])
    result=verifier.verify(task,trace).to_dict()
    if not io.same(io.read(root,'verdict.json'),result):raise ValueError('stored verdict differs from independent replay')
    return result


def run_release(*,manifest_dir,backend,out_dir,release_id='papera-contract-v1',policy='reference',max_steps=1000):
    config=_configuration(release_id,backend,policy,max_steps)
    manifest_root=io.directory(manifest_dir)
    raw={name:io.read_bytes(manifest_root,name) for name in ('manifest.json','tasks.jsonl')}
    snapshot=load_task_manifest(manifest_root)
    if len(snapshot.tasks)*max_steps>1000000:
        raise ValueError('release total action budget exceeds1000000')
    if io.sha(raw['manifest.json'])!=snapshot.manifest_sha256 or io.sha(raw['tasks.jsonl'])!=snapshot.task_index_sha256:
        raise ValueError('manifest changed during preflight')
    cases=_cases(snapshot,backend)  # all rows before output or an episode
    if len(cases)!=len(snapshot.tasks):raise ValueError('backend task cardinality differs')
    for case in cases:
        if (case.policy.policy_id,case.policy.policy_hash)!=_policy_identity(case.task,backend,'reference'):
            raise ValueError('unexpected frozen reference identity')
    source=source_identity()
    root=Path(out_dir).absolute()
    if root.resolve()!=root:raise ValueError('non-symlink output path required')
    root.mkdir(parents=True,exist_ok=False)
    (root/'tasks').mkdir()
    for name,data in raw.items():(root/'tasks'/name).write_bytes(data)
    io.write(root/'config.json',config);io.write(root/'source.json',source)
    io.write(root/'preflight.json',dict(schema=SCHEMA,manifest_sha256=snapshot.manifest_sha256,
                                      task_index_sha256=snapshot.task_index_sha256,task_count=len(cases),
                                      capabilities=_capabilities(backend),admission=ADMISSION.copy()))
    rows=[]
    for index,case in enumerate(cases):
        bundle=f'episodes/task-{index:05d}'
        actor=(AbstainPolicy() if policy=='abstain' else
               ThermalDosePolicy(rate_ml_s=10.0) if policy=='high-rate' else case.policy)
        result=run_episode(case.task,case.world,actor,case.verifier,seed=case.task.seed,
                           max_steps=max_steps,out_dir=str(root/bundle))
        t=result.trace
        io.write(root/bundle/'execution.json',dict(end_time_s=t.end_time,completed=t.completed,
                                                  stop_reason=t.stop_reason,error=t.error))
        verdict=_replay(root/bundle,case.task,snapshot,config)
        rows.append(dict(index=index,task_id=case.task.task_id,split=case.task.split,
                         task_sha256=io.sha(case.task.canonical_json().encode()),bundle=bundle,verdict=verdict))
    io.write(root/'episodes.json',dict(schema=SCHEMA,episodes=rows))
    io.write(root/'summary.json',_summary(config,rows))
    if source_identity()!=source:raise ValueError('source changed during release; incomplete output retained')
    io.seal(root)
    verify_release(root)
    return root


def verify_release(release_dir,expected_sha256=None):
    """Regrade every episode; do not construct a world, policy or process model."""
    try:
        root=io.directory(release_dir);index=io.verify_index(root,expected_sha256)
        config=io.read(root,'config.json')
        if not io.same(config,_configuration(config['release_id'],config['backend'],config['policy'],config['max_steps'])):
            raise ValueError('configuration fields differ')
        if not io.same(io.read(root,'source.json'),source_identity()):raise ValueError('installed source/dependencies differ from release')
        snapshot=load_task_manifest(root/'tasks')
        if len(snapshot.tasks)*config['max_steps']>1000000:
            raise ValueError('release total action budget exceeds1000000')
        expected=dict(schema=SCHEMA,manifest_sha256=snapshot.manifest_sha256,
                      task_index_sha256=snapshot.task_index_sha256,task_count=len(snapshot.tasks),
                      capabilities=_capabilities(config['backend']),admission=ADMISSION.copy())
        if not io.same(io.read(root,'preflight.json'),expected):raise ValueError('preflight differs from frozen manifest')
        expected_files={'config.json','source.json','preflight.json','episodes.json','summary.json',
                        'tasks/manifest.json','tasks/tasks.jsonl'}
        for i in range(len(snapshot.tasks)):
            expected_files.update(f'episodes/task-{i:05d}/'+n for n in (
                'task.json','manifest.json','artifacts.json','observations.jsonl','actions.jsonl','events.jsonl','verdict.json','execution.json'))
        if set(index['files'])!=expected_files:raise ValueError('release file set differs from protocol')
        rows=[]
        for i,entry in enumerate(snapshot.tasks):
            bundle=f'episodes/task-{i:05d}'
            verdict=_replay(root/bundle,entry.task,snapshot,config)
            rows.append(dict(index=i,task_id=entry.task.task_id,split=entry.task.split,
                             task_sha256=io.sha(entry.task.canonical_json().encode()),bundle=bundle,verdict=verdict))
        if not io.same(io.read(root,'episodes.json'),dict(schema=SCHEMA,episodes=rows)):raise ValueError('episode index differs from replay')
        summary=_summary(config,rows)
        if not io.same(io.read(root,'summary.json'),summary):raise ValueError('summary differs from replay')
        return dict(status='PASS_RELEASE_INTEGRITY_AND_REPLAY',episodes_replayed=len(rows),
                    release_sha256=io.sha(io.read_bytes(root,'COMMITTED.json')),summary=summary,
                    scope='Correct evidence and regrading, including failures; not scientific admission')
    except (OSError,TypeError,KeyError,AttributeError,RecursionError,UnicodeError,OverflowError) as exc:
        raise ValueError(f'invalid release: {type(exc).__name__}: {exc}') from exc
