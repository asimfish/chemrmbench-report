"""Pre-write authorization for the prospective unloaded-boundary experiment.

These CPU checks cannot establish a physical restart. The native reader must
also check all thirty hold samples, the complete tail, clocks and every stage.
"""
import copy
import math

from .legacy_reconstruction.checkpoint_schema import validate_checkpoint
from .physical_bottle_baseline import bilateral_contact


def validate_plan(p):
    if (p.get('schema') != 'chemrm-v99-unloaded-cold-full-tail' or
            p.get('native_phases') != ['live', 'cold'] or
            p.get('cut_command') != 2400 or p.get('stop_command') != 13427 or
            p.get('hold_ticks') != 30 or p.get('warmup_ticks') != 1200 or
            p.get('dt_s') != 1 / 240 or p.get('maximum_worker_count') != 2 or
            p.get('model_request_limit') != 0 or p.get('training_jobs') != 0):
        raise ValueError('complete prospective V99 experiment plan required')
    expected = [('approach', 0, 2400), ('grasp', 2400, 3840),
                ('lift', 3840, 4560), ('transport', 4560, 6480),
                ('place_release', 6480, 7920), ('regrasp', 7920, 9600),
                ('return', 9600, 12707), ('retreat', 12707, 13427)]
    if [(x['id'], x['start_tick'], x['end_tick']) for x in p['stage_plan']] != expected:
        raise ValueError('original complete stage graph required')
    for name in ('scientific_admission', 'training_admission', 'formal_M1_admission',
                 'full_benchmark_pass', 'hidden_solver_state_restored'):
        if p.get(name) is not False:
            raise ValueError('engineering experiment cannot grant admission')
    return p


def context(p, cursor, goal):
    if type(cursor) is not int or not 0 <= cursor <= p['stop_command']:
        raise ValueError('bounded source command cursor required')
    if (type(goal) is not list or len(goal) != 3 or
            any(type(x) not in (int, float) or not math.isfinite(x) for x in goal)):
        raise ValueError('finite original return goal required')
    return dict(schema='chemrm-bottle-cursor-v1', policy_sha256=p['command_policy_sha256'],
                completed_stages=[s['id'] for s in p['stage_plan'] if s['end_tick'] <= cursor],
                next_stage=next((s['id'] for s in p['stage_plan'] if s['end_tick'] > cursor), 'complete'),
                next_command_index=cursor, original_return_goal=copy.deepcopy(goal),
                context_kind='PINNED_EXPERT_CONTROLLER_ONLY')


def authorize_source(source, p, *, expected_identity, rigid_ids, articulation_joints,
                     kinematic_ids, scene_has_particles):
    validate_plan(p)
    cp = validate_checkpoint(copy.deepcopy(source))
    if scene_has_particles is not False or cp['schema_version'] < 3:
        raise ValueError('complete version3 rigid source required; particles unsupported')
    if cp['identity'] != expected_identity:
        raise ValueError('source executor/scene/runtime identity differs before any write')
    bodies = cp['physics']['bodies']; arts = cp['physics']['articulations']
    ids = [x['id'] for x in bodies + arts]
    if (len(bodies) != 56 or len(arts) != 9 or len(ids) != len(set(ids)) or
            {x['id'] for x in bodies} != set(rigid_ids) or
            {x['id'] for x in arts} != set(articulation_joints) or
            not set(kinematic_ids).issubset(rigid_ids)):
        raise ValueError('exact complete56 rigid/9 articulation registry required')
    for art in arts:
        if art['joint_names'] != list(articulation_joints[art['id']]):
            raise ValueError('source joint registry differs before any write')
    host = cp['host']
    if (cp['boundary_kind'] != 'task_boundary' or cp['carry_mode'] != 'none' or
            cp['resumed_mid_carry'] or host['kin'] or host['pinned'] or
            host.get('kinematic_support') or cp['randomness']['draw_count'] != 0):
        raise ValueError('source must be an unloaded unpinned task boundary')
    goal = host['contract'].get('original_return_goal')
    expected_graph = context(p, p['cut_command'], goal)
    if cp['task']['graph_position'] != expected_graph or host['tick'] != p['cut_command']:
        raise ValueError('source controller graph or host cursor differs before any write')
    bottle = next((x for x in bodies if x['id'] == p['object']), None)
    robot = next((x for x in arts if x['id'] == 'fr3_A'), None)
    if bottle is None or robot is None or len(robot['joint_position']) != 9:
        raise ValueError('expected bottle and robot records required')
    recent = host['contact_frames']
    if (len(recent) != 6 or any(bilateral_contact({'contacts': c}, bottle['prim_path'], robot['prim_path']) for c in recent) or
            max(abs(x - y) for x, y in zip(bottle['root_state'][:3], goal)) > .001 or
            any(q < .03 for q in robot['joint_position'][-2:])):
        raise ValueError('observed source is not an open-gripper pre-grasp boundary')
    calls = []
    for row in bodies:
        calls.append((row['id'], 'write_root_pose_to_sim'))
        if row['id'] not in kinematic_ids:
            calls.append((row['id'], 'write_root_velocity_to_sim'))
    for row in arts:
        calls.extend((row['id'], method) for method in (
            'write_root_pose_to_sim', 'write_root_velocity_to_sim', 'write_joint_state_to_sim',
            'set_joint_position_target', 'set_joint_velocity_target', 'set_joint_effort_target'))
        for key, method in [('stiffness', 'write_joint_stiffness_to_sim'),
                            ('damping', 'write_joint_damping_to_sim'),
                            ('effort_limit', 'write_joint_effort_limit_to_sim')]:
            if key in row['runtime_properties']:
                calls.append((row['id'], method))
    return cp, dict(status='AUTHORIZED_UNLOADED_SOURCE_BEFORE_STATE_WRITE',
                    source_cursor=p['cut_command'], registered_entities=65,
                    all_six_recent_frames_without_bilateral_custody=True,
                    planned_calls=calls, physical_restart_admitted=False,
                    scientific_admission=False, training_admission=False)


def authorize_and_apply(source, p, apply, **kwargs):
    """The injected writer is unreachable if any source authorization fails."""
    cp, authorization = authorize_source(source, p, **kwargs)
    return authorization, apply(cp, authorization['planned_calls'])
