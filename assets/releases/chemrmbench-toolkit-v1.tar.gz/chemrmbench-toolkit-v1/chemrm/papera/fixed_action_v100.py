"""V100 keeps V99 restoration limits and adds a private fixed-action control."""
import copy
from pathlib import Path

from . import cold_boundary_v99 as boundary
from .action_trace_v100 import CHANNELS


def validate_prelaunch(pre, launch_text):
    capsule=pre.get('driver_capsule')
    if (type(capsule) is not str or not Path(capsule).is_absolute() or
            any(c in capsule for c in ('\n','\r','\x00')) or
            launch_text.splitlines().count('capsule='+capsule)!=1):
        raise ValueError('declared driver capsule must match the actual launcher')
    for key,value in [('native_watchdog_s',600),('cancel_grace_s',15),('minimum_free_gpu_mib',23552),
                      ('maximum_native_workers',2),('maximum_model_calls',0),('maximum_training_jobs',0)]:
        if type(pre.get(key)) is not int or pre[key]!=value:
            raise ValueError('complete prospective launch budget required: '+key)
    if (type(pre.get('selected_gpu_uuid')) is not str or not pre['selected_gpu_uuid'].startswith('GPU-') or
            pre.get('maximum_allocated_gpu_hours')!=2*615/3600):
        raise ValueError('declared compute identity and allocation bound required')
    return pre


def validate_plan(p):
    if p.get('schema') != 'chemrm-v100-fixed-all-action-cold-full-tail':
        raise ValueError('explicit V100 fixed-action plan required')
    if p.get('cold_coverage_policy') != 'DIAGNOSTIC_ONLY_NO_HEADLINE_BOUNDARY_ADDITION':
        raise ValueError('private counterfactual cannot increase autonomous cold coverage')
    action = p.get('action_trace')
    if action != dict(schema='chemrm-v100-private-complete-action-trace-v1',
                      channels=list(CHANNELS), implicit_only=True,
                      record_simulator_inputs=True, all_setters_audited=True,
                      include_hold_steps=True, private_validator_only=True,
                      agent_visible=False):
        raise ValueError('all-channel private simulator-input contract required')
    if (p.get('native_watchdog_s') != 600 or p.get('native_cancel_grace_s') != 15 or
            p.get('minimum_free_gpu_mib') != 23552 or p.get('max_worker_seconds') != 600 or
            p.get('maximum_allocated_gpu_hours') != 2 * 615 / 3600):
        raise ValueError('prospective two-worker resource cap required')
    old = copy.deepcopy(p);old['schema'] = 'chemrm-v99-unloaded-cold-full-tail'
    boundary.validate_plan(old)
    return p


def context(p, cursor, goal):
    return boundary.context(p, cursor, goal)


def authorize_source(source, p, **kwargs):
    validate_plan(p)
    old = copy.deepcopy(p);old['schema'] = 'chemrm-v99-unloaded-cold-full-tail'
    return boundary.authorize_source(source, old, **kwargs)


def authorize_and_apply(source, p, apply, **kwargs):
    cp, authorization = authorize_source(source, p, **kwargs)
    return authorization, apply(cp, authorization['planned_calls'])
