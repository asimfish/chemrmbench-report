"""Frozen official CLIP vision features, bound to native images; no text/metadata input."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import numpy as np
from PIL import Image
from chemrm.papera.isaac_bridge_verify import sha256
from chemrm.papera.native_leakage import dump

MEAN = [.48145466, .4578275, .40821073]
STD = [.26862954, .26130258, .27577711]
PREPROCESS = dict(input='native RGB uint8 320x320', resize=224, interpolation='Pillow BICUBIC',
                  center_crop=224, rescale=1/255., mean=MEAN, std=STD, text_input=False)


def preprocess(rgb):
    if rgb.dtype != np.uint8 or rgb.shape != (320, 320, 3):
        raise ValueError('native RGB required')
    a = np.asarray(Image.fromarray(rgb).resize((224, 224), Image.Resampling.BICUBIC), dtype=np.float32)/255.
    return ((a-np.array(MEAN, dtype=np.float32))/np.array(STD, dtype=np.float32)).transpose(2, 0, 1)


def verify_encoder(manifest):
    import importlib.metadata as md
    import transformers.models.clip.modeling_clip as implementation
    r = json.loads(manifest.read_text())
    if r['tensor_equality'] != 'ALL_BIT_EXACT' or r['preprocess'] != PREPROCESS:
        raise ValueError('unverified encoder')
    for path, digest in [('safetensors_path', 'safetensors_sha256'), ('config_path', 'config_sha256')]:
        if sha256(Path(r[path])) != r[digest]:
            raise ValueError('encoder artifact changed')
    if ({k:md.version(k) for k in r['runtime']} != r['runtime'] or
            sha256(Path(implementation.__file__)) != r['official_library_source_sha256']):
        raise ValueError('encoder implementation/runtime changed')
    return r


def extract(collection, encoder, out, gpu=1):
    import torch
    from safetensors.torch import load_file
    from transformers import CLIPVisionConfig, CLIPVisionModel
    enc = verify_encoder(encoder)
    cfg = json.loads(Path(enc['config_path']).read_text())['vision_config']
    model = CLIPVisionModel(CLIPVisionConfig(**cfg))
    state = load_file(enc['safetensors_path'], device='cpu')
    # Official CLIPVisionModel has vision_model.* keys, identical to the full model's vision subset.
    state = {k: v for k, v in state.items() if k.startswith('vision_model.')}
    # Old official weights persist an index buffer which current Transformers
    # registers as non-persistent. Check it exactly; learned keys stay strict.
    position_ids = state.pop('vision_model.embeddings.position_ids')
    if not torch.equal(position_ids, model.vision_model.embeddings.position_ids):
        raise ValueError('legacy position index buffer differs from official architecture')
    model.load_state_dict(state, strict=True)
    device = 'cpu' if gpu < 0 else f'cuda:{gpu}'
    if device != enc['inference_device']:
        raise ValueError('inference device differs from frozen encoder protocol')
    model.eval().requires_grad_(False).to(device)
    torch.use_deterministic_algorithms(True)
    torch.backends.cuda.matmul.allow_tf32 = False
    out.mkdir(parents=True, exist_ok=False)
    native = json.loads((collection/'manifest.json').read_text())
    if native['status'] != 'COMPLETE' or (collection/'error.json').exists():
        raise ValueError('native collection incomplete')
    entries = []
    for case in native['cases']:
        folder = collection/case['case_id']
        audit = json.loads((folder/'audit.json').read_text())
        if sha256(folder/'audit.json') != case['audit_sha256']:
            raise ValueError('native audit changed')
        samples = audit['observations'] + ([] if audit['paused_control'] is None else audit['paused_control']['samples'])
        for sample in samples:
            path = folder/sample['file']
            if path.name != sample['file'] or sha256(path) != sample['sha256']:
                raise ValueError('native frame changed')
            x = torch.from_numpy(preprocess(np.asarray(Image.open(path)))[None].copy()).to(device)
            with torch.inference_mode():
                y = model(pixel_values=x)
            pooled = y.pooler_output[0].cpu().numpy()
            patches = y.last_hidden_state[0, 1:].reshape(-1).cpu().numpy()
            name = f"{case['case_id']}__{path.stem}.npz"
            np.savez_compressed(out/name, clip_pool=pooled, clip_patches=patches)
            entries.append(dict(case_id=case['case_id'], image=sample['file'], image_sha256=sample['sha256'],
                                feature=name, feature_sha256=sha256(out/name)))
        if len(entries) % 100 < 10:
            print(f'FEATURES_DONE {len(entries)}', flush=True)
    dump(out/'manifest.json', dict(status='COMPLETE', encoder_sha256=sha256(encoder),
         native_manifest_sha256=sha256(collection/'manifest.json'), entries=entries,
         completed_at_utc=datetime.now(timezone.utc).isoformat(), preprocess=PREPROCESS,
         dimensions={'clip_pool':768, 'clip_patches':37632}, inference_device=device, precision='float32 inference; float64 ridge'))
    print(f'FEATURES_COMPLETE {len(entries)}', flush=True)


def feature_index(cache, collection, encoder):
    m = json.loads((cache/'manifest.json').read_text())
    enc = json.loads(encoder.read_text())
    if (m['status'] != 'COMPLETE' or m['inference_device'] != enc['inference_device'] or m['dimensions'] != {'clip_pool':768, 'clip_patches':37632} or m['encoder_sha256'] != sha256(encoder) or
            m['native_manifest_sha256'] != sha256(collection/'manifest.json') or m['preprocess'] != PREPROCESS):
        raise ValueError('feature cache binding differs')
    result = {}
    for e in m['entries']:
        if e['feature'] != f"{e['case_id']}__{Path(e['image']).stem}.npz" or Path(e['image']).name != e['image']:
            raise ValueError('unexpected feature path')
        key = (e['case_id'], e['image'])
        if key in result or sha256(collection/e['case_id']/e['image']) != e['image_sha256'] or sha256(cache/e['feature']) != e['feature_sha256']:
            raise ValueError('duplicate or changed feature/image')
        with np.load(cache/e['feature'], allow_pickle=False) as z:
            if set(z.files) != {'clip_pool', 'clip_patches'} or any(z[k].shape != (d,) or z[k].dtype != np.float32 or not np.isfinite(z[k]).all() for k,d in m['dimensions'].items()):
                raise ValueError('invalid CLIP feature')
        result[key] = cache/e['feature']
    native = json.loads((collection/'manifest.json').read_text())
    expected = set()
    for item in native['cases']:
        a = json.loads((collection/item['case_id']/'audit.json').read_text())
        expected.update((item['case_id'], x['file']) for x in a['observations'])
        if a['paused_control']:
            expected.update((item['case_id'], x['file']) for x in a['paused_control']['samples'])
    if set(result) != expected:
        raise ValueError('incomplete feature coverage')
    return result


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--collection', type=Path, required=True)
    p.add_argument('--encoder', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--gpu', type=int, default=1)
    a = p.parse_args()
    extract(a.collection, a.encoder, a.out, a.gpu)
