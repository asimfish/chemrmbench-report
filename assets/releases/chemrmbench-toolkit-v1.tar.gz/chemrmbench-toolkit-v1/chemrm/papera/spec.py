"""Adapter from the repository YAML task schema to the Paper A public task program."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from chemrm.task_program import GoalStep, TaskProgram
from chemrm.task_schema import TaskSpec, load_task_spec


@dataclass(frozen=True)
class BenchmarkTask:
    """A public task program plus its read-only temporal constraints."""

    program: TaskProgram
    constraints: tuple[Any, ...]
    source_name: str


def _goal_steps(spec: TaskSpec) -> tuple[GoalStep, ...]:
    steps: list[GoalStep] = []
    for index, item in enumerate(spec.goal):
        if not isinstance(item, dict):
            raise ValueError(f"goal {index} must be a mapping")
        action = item.get("kind", item.get("action"))
        if not action:
            raise ValueError(f"goal {index} has no kind/action")
        goal_id = str(item.get("id", f"goal_{index}"))
        requires = tuple(item.get("requires", (steps[-1].id,) if steps else ()))
        params = {k: v for k, v in item.items() if k not in {"id", "kind", "action", "requires"}}
        steps.append(GoalStep(goal_id, str(action), requires, params))
    return tuple(steps)


def load_benchmark_task(path: str | Path, *, split: str = "closed", seed: int = 0) -> BenchmarkTask:
    """Load a YAML task while preserving the public/hidden boundary.

    The YAML file contributes the public task description and constraint declarations only.  A
    world may later sample hidden episode parameters from its own seed; those values are not copied
    into this task program.
    """
    source = Path(path)
    spec = load_task_spec(source)
    raw = spec.raw
    objects_raw = raw.get("objects", ())
    objects = tuple(dict(x) if isinstance(x, dict) else {"id": str(x)} for x in objects_raw)
    counts = raw.get("counts", {})
    if not isinstance(counts, dict):
        raise ValueError("task counts must be a mapping when provided")
    environment = {
        "kind": raw.get("environment", "chemrm.task_schema"),
        "randomization": raw.get("randomization", {}),
    }
    program = TaskProgram(
        task_id=spec.task_id,
        split=split,
        environment=environment,
        objects=objects,
        counts=counts,
        goals=_goal_steps(spec),
        seed=int(seed),
        public_spec_version="task-schema-1",
        metadata={
            "title": spec.title,
            "mts": {"M": spec.m_level, "T": list(spec.t_levels), "S": spec.s_level},
            "memory_types": list(spec.memory_types),
            "memory_budget_k": int(spec.memory_budget_k),
            "source_task_id": spec.task_id,
        },
    )
    return BenchmarkTask(program, tuple(spec.temporal_constraints), source.name)
