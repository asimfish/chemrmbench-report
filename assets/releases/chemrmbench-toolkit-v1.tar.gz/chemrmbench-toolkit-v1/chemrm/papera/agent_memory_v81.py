"""Public semantic agent memory; separate from the native physics checkpoint."""
import json
import math
from pathlib import Path
import re

from .astra_boundary_v70 import public_observation
from .collection_engine_v70 import encoded, identity, publish
from .legacy_reconstruction.checkpoint_schema import load_checkpoint
from .staged_collection import digest

DELAYS={'green':10.,'amber':16.}
SKILL='A1_regrasp_return'
EVENT_DELAYS={'early':10.,'late':16.}
EVENT_INSTRUCTION=(
    'Observe the bottle being held above the laboratory worktop in a past cue image. '
    'Remember whether that physical operation is visible and the supplied public observation timestamp with its clock id. '
    'This timestamp is the image observation time, not the hidden physical lift onset. '
    'If the observed cue time is below 30 seconds, its time bucket is early and the requested regrasp deadline '
    'is 10 seconds after resumption; at 30 seconds or later the bucket is late and the deadline is 16 seconds. '
    'At resumption the bottle is resting on the scale, the old cue image is unavailable, and a new public clock is zero. '
    'Do not subtract old and new epoch timestamps. Use only A1_regrasp_return; wait or abort if information is insufficient. '
    'This is an engineering memory readout on preserved observations, not chemical success.')
INSTRUCTION=(
    'A floating square status beacon directly above the weighing scale on the right of the robot '
    'briefly shows green or amber. Other colored bottle caps are not the beacon. '
    'Remember the beacon color and the public observation timestamp with its clock id. '
    'Green means the target bilateral bottle regrasp must occur 10 seconds after the next resumption; '
    'amber means 16 seconds. Use only the registered A1_regrasp_return skill. '
    'At resumption the beacon is absent and the public child clock starts at zero. '
    'Previous clock epochs do not continue into this clock. If information is insufficient, wait or abort. '
    'This is a rigid-bottle engineering task, not chemical success.')


def finite(value,low=0,high=1e6):
    return type(value) in (int,float) and math.isfinite(value) and low<=value<=high


def clock_id(value):
    if not isinstance(value,str) or not re.fullmatch(r'public_v8[12]:(parent|child):[a-f0-9]{16}',value):
        raise ValueError('declared public native epoch required')
    return value


def packet(*,phase,epoch,joints,image_sha256,timestamp_s,task_kind='VISUAL_BEACON'):
    if phase not in ('CUE','RESUME'):raise ValueError('public cue/resume phase required')
    if task_kind not in ('VISUAL_BEACON','LIFT_TIMESTAMP'):raise ValueError('registered public memory task required')
    instruction=INSTRUCTION if task_kind=='VISUAL_BEACON' else EVENT_INSTRUCTION
    observation=public_observation(track='B',instruction={'text':instruction},joints_q=joints,
        images=[{'view':'station','sha256':image_sha256}],current_clock_s=timestamp_s)
    value=dict(schema='chemrm-public-memory-packet-v81',phase=phase,
        public_clock_id=clock_id(epoch),observation=observation)
    if task_kind=='LIFT_TIMESTAMP':
        value.update(schema='chemrm-public-memory-packet-v82',task_kind=task_kind)
    return dict(packet=value,sha256=identity(value))


def validate_packet(value):
    if type(value) is not dict or set(value)!={'packet','sha256'}:
        raise ValueError('public packet envelope only')
    p=value['packet']
    if type(p) is not dict:raise ValueError('typed public packet required')
    task_kind='LIFT_TIMESTAMP' if p.get('schema')=='chemrm-public-memory-packet-v82' else 'VISUAL_BEACON'
    fields={'schema','phase','public_clock_id','observation'}|({'task_kind'} if task_kind=='LIFT_TIMESTAMP' else set())
    if set(p)!=fields or p['schema'] not in ('chemrm-public-memory-packet-v81','chemrm-public-memory-packet-v82') or (task_kind=='LIFT_TIMESTAMP' and p['task_kind']!=task_kind):
        raise ValueError('private fields forbidden in public packet')
    obs=p['observation']
    if type(obs) is not dict or set(obs)!={'actor','sha256','track'} or obs['track']!='B':
        raise ValueError('typed clock-visible public observation required')
    actor=obs['actor']
    instruction=EVENT_INSTRUCTION if task_kind=='LIFT_TIMESTAMP' else INSTRUCTION
    if type(actor) is not dict or set(actor)!={'instruction','joints_q','images','timestamp_s'} or actor['instruction']!={'text':instruction}:
        raise ValueError('fixed public instruction and measured channels only')
    if (not isinstance(actor['images'],list) or len(actor['images'])!=1
            or type(actor['images'][0]) is not dict or set(actor['images'][0])!={'view','sha256'}
            or actor['images'][0]['view']!='station'):
        raise ValueError('one actual station image binding required')
    expected=packet(phase=p['phase'],epoch=p['public_clock_id'],joints=actor['joints_q'],
        image_sha256=actor['images'][0]['sha256'],timestamp_s=actor['timestamp_s'],task_kind=task_kind)
    if expected!=value:raise ValueError('public packet or epoch binding changed')
    return json.loads(encoded(value))


def validate_memory(memory,observation):
    observation=validate_packet(observation)
    if observation['packet']['phase']!='CUE':raise ValueError('memory must come from a cue observation')
    event_task=observation['packet']['schema']=='chemrm-public-memory-packet-v82'
    keys={'observation_sha256','delay_s','cue_observation_s','cue_clock_id'}|({'event','time_bucket'} if event_task else {'cue_color'})
    if type(memory) is not dict or set(memory)!=keys or memory['observation_sha256']!=observation['sha256']:
        raise ValueError('agent memory must bind the exact public packet')
    mapping=EVENT_DELAYS if event_task else DELAYS
    color=memory['time_bucket'] if event_task else memory['cue_color']
    if event_task and memory['event'] not in ('bottle_lift_observed','unknown'):raise ValueError('bounded observed event required')
    if color not in (*mapping,'unknown'):raise ValueError('bounded cue interpretation required')
    if color=='unknown':
        if any(memory[k] is not None for k in ('delay_s','cue_observation_s','cue_clock_id')):
            raise ValueError('unknown cue cannot invent event knowledge')
    else:
        if not finite(memory['delay_s'],0,30) or memory['delay_s']!=mapping[color] or not finite(memory['cue_observation_s']):
            raise ValueError('public color mapping and finite recalled observation time required')
        clock_id(memory['cue_clock_id'])
    # Semantic correctness is scored independently; no truth repair here.
    return json.loads(encoded(memory))


def physics_binding(directory,policy_sha256,cursor):
    directory=Path(directory)
    marker=json.loads((directory/'COMMITTED.json').read_text())
    manifest=json.loads((directory/'manifest.json').read_text())
    if marker!={'manifest_sha256':digest(directory/'manifest.json')} or digest(directory/'checkpoint.npz')!=manifest['checkpoint_sha256']:
        raise ValueError('physical checkpoint commit changed')
    cp=load_checkpoint(directory/'checkpoint.npz')
    graph=cp['task']['graph_position']
    if graph['policy_sha256']!=policy_sha256 or graph['next_command_index']!=cursor:
        raise ValueError('memory attached to a different policy or command cursor')
    return dict(checkpoint_sha256=manifest['checkpoint_sha256'],
        checkpoint_manifest_sha256=digest(directory/'manifest.json'),
        parent_manifest_sha256=manifest['parent_manifest_sha256'],
        command_policy_sha256=policy_sha256,command_cursor=cursor)


def seal_memory(directory,observation,memory,checkpoint_directory,policy_sha256,cursor):
    observation=validate_packet(observation);memory=validate_memory(memory,observation)
    binding=physics_binding(checkpoint_directory,policy_sha256,cursor)
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=False)
    body=dict(schema='chemrm-agent-semantic-memory-v81',source_packet_sha256=observation['sha256'],
        source_public_packet=observation,
        memory=memory,source_public_clock_id=observation['packet']['public_clock_id'],
        memory_kind='ASTRA_AUTHORED_PUBLIC_SEMANTIC_MEMORY',contains_past_images=False,
        hidden_model_state_restored=False,scientific_admission=False)
    publish(directory/'memory.json',encoded(body))
    manifest=dict(schema='chemrm-agent-memory-binding-v81',binding=binding,
        memory_sha256=digest(directory/'memory.json'),scientific_admission=False)
    publish(directory/'manifest.json',encoded(manifest))
    publish(directory/'COMMITTED.json',encoded({'manifest_sha256':digest(directory/'manifest.json')}))
    return manifest


def restore_memory(directory,checkpoint_directory,policy_sha256,cursor):
    directory=Path(directory)
    marker=json.loads((directory/'COMMITTED.json').read_text())
    manifest=json.loads((directory/'manifest.json').read_text())
    if (manifest.get('schema')!='chemrm-agent-memory-binding-v81'
            or marker!={'manifest_sha256':digest(directory/'manifest.json')}
            or manifest['binding']!=physics_binding(checkpoint_directory,policy_sha256,cursor)
            or digest(directory/'memory.json')!=manifest['memory_sha256']):
        raise ValueError('agent memory or physical parent binding changed')
    body=json.loads((directory/'memory.json').read_text())
    required={'schema','source_packet_sha256','source_public_packet','memory','source_public_clock_id',
        'memory_kind','contains_past_images','hidden_model_state_restored','scientific_admission'}
    if set(body)!=required or body['schema']!='chemrm-agent-semantic-memory-v81' or body['contains_past_images'] is not False:
        raise ValueError('semantic memory cannot silently include old pixels')
    source=validate_packet(body['source_public_packet'])
    validate_memory(body['memory'],source)
    if source['sha256']!=body['source_packet_sha256'] or source['packet']['public_clock_id']!=body['source_public_clock_id']:
        raise ValueError('stored public source packet changed')
    return body,manifest


def checked_schedule(proposal,observation,memory_sha256,nominal_contact_latency_s,dt_s):
    observation=validate_packet(observation)
    if observation['packet']['phase']!='RESUME':raise ValueError('only a fresh resume packet can schedule')
    keys={'observation_sha256','memory_sha256','decision','selected_skill',
          'desired_contact_after_resume_s','start_after_resume_s','remembered_cue_s','remembered_cue_clock_id'}
    if type(proposal) is not dict or set(proposal)!=keys or proposal['observation_sha256']!=observation['sha256'] or proposal['memory_sha256']!=memory_sha256:
        raise ValueError('proposal must bind current packet and selected memory condition')
    if proposal['decision'] not in ('schedule','wait','abort'):raise ValueError('unknown decision')
    remembered=proposal['remembered_cue_s']
    if remembered is None:
        if proposal['remembered_cue_clock_id'] is not None:raise ValueError('missing remembered time requires missing epoch')
    else:
        if not finite(remembered):raise ValueError('bounded remembered public time required')
        clock_id(proposal['remembered_cue_clock_id'])
    if proposal['decision']!='schedule':
        if any(proposal[k] is not None for k in ('selected_skill','desired_contact_after_resume_s','start_after_resume_s')):
            raise ValueError('wait/abort cannot dispatch an action')
        return dict(decision=proposal['decision'],dispatch=False)
    target,start=proposal['desired_contact_after_resume_s'],proposal['start_after_resume_s']
    if (proposal['selected_skill']!=SKILL or not finite(target,0,30) or target not in DELAYS.values()
            or not finite(start,0,30) or not finite(nominal_contact_latency_s,0,20)
            or not finite(dt_s,1e-5,.1) or abs(start+nominal_contact_latency_s-target)>dt_s+1e-9):
        raise ValueError('bounded registered skill and public latency estimate required')
    # Cleared context may guess a schedule. The harness does not force its score.
    return dict(decision='schedule',dispatch=True,skill=SKILL,
        start_tick=math.ceil(start/dt_s),requested_start_after_resume_s=start,
        desired_contact_after_resume_s=target,nominal_contact_latency_s=nominal_contact_latency_s,
        rounding='NEXT_NATIVE_COMMAND_BOUNDARY',scientific_admission=False)
