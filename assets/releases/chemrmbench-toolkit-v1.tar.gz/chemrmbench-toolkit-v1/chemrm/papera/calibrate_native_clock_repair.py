"""Seen-scene calibration for a new renderer candidate, never future acceptance."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import sys
import traceback

from chemrm.papera.native_leakage import dump
from chemrm.papera.isaac_bridge_contract import Case
from chemrm.papera.isaac_bridge_verify import sha256


def main():
    parser = argparse.ArgumentParser()
    for field in ('bank', 'asset', 'out'):
        parser.add_argument('--'+field, type=Path, required=True)
    parser.add_argument('--intensity', type=float, default=1000.)
    args = parser.parse_args()
    bank = json.loads(args.bank.read_text())
    seen_scenes = [s['scene_id'] for s in bank['scenes'] if s['split'] == 'train'][:3]
    entries = [r for r in bank['cases'] if r['scene_id'] in seen_scenes]
    args.out.mkdir(parents=True, exist_ok=False)
    sys.argv = [sys.argv[0]]
    from isaacsim import SimulationApp
    app = SimulationApp({'headless': True, 'active_gpu': 0, 'physics_gpu': 0,
                         'multi_gpu': False, 'width': 320, 'height': 320,
                         'renderer': 'RayTracedLighting'})
    try:
        import numpy as np
        from PIL import Image
        from chemrm.papera.native_clock_repair_candidate import FixedLightCandidate
        from chemrm.papera.isaac_bridge_policies import visual_features
        backend = FixedLightCandidate(str(args.asset), args.intensity)
        checks = []
        for row in entries:
            case = Case(**row['case'])
            backend.reset(case)
            folder = args.out/case.case_id
            folder.mkdir()
            frames, observations = {}, []
            for phase, query in [('before', case.onset_s-1.), ('cue', case.onset_s+1.)] + [(f'age_{int(a)}', case.onset_s+a) for a in bank['ages_s']]:
                backend.advance(max(0., query-backend.now))
                snap = backend.capture()
                frames[phase] = snap.rgb.copy()
                Image.fromarray(snap.rgb).save(folder/(phase+'.png'))
                observations.append({'phase': phase, 'time': snap.captured_at,
                     'mean_rgb': snap.rgb.mean((0,1)).tolist(), 'detector': visual_features(snap.rgb)})
            t, joints = backend.now, backend.robot.get_joint_positions().copy()
            baseline = frames['age_65']
            for _ in range(64):
                backend.world.render()
            assert backend.now == t and np.array_equal(joints, backend.robot.get_joint_positions())
            paused = np.asarray(backend.camera.get_rgba())[:,:,:3].copy()
            Image.fromarray(paused).save(folder/'paused_64.png')
            post = [frames[f'age_{int(a)}'] for a in bank['ages_s']]
            cue = next(r['detector'] for r in observations if r['phase'] == 'cue')
            checks.append({'case_id': case.case_id, 'scene_id': row['scene_id'], 'target': case.target,
                 'cue_correct': cue['green_slot'] == case.target, 'cue_detector': cue,
                 'noncue_erased': all(r['detector']['green_slot'] is None for r in observations if r['phase'] != 'cue'),
                 'paused64_max_abs_pixel_difference': int(np.max(np.abs(paused.astype(int)-baseline.astype(int)))),
                 'paused64_mean_abs_pixel_difference': float(np.mean(np.abs(paused.astype(float)-baseline.astype(float)))),
                 'postcue_max_abs_pixel_difference': max(int(np.max(np.abs(x.astype(int)-post[0].astype(int)))) for x in post[1:]),
                 'postcue_mean_rgb_range': np.ptp(np.array([x.mean((0,1)) for x in post]),axis=0).tolist(),
                 'native_reset': backend.events[0], 'observations': observations})
            print(f'REPAIR_DEV_CASE {len(checks)}/{len(entries)} {case.case_id}', flush=True)
        dump(args.out/'receipt.json', {'status': 'COMPLETE_DEVELOPMENT_CANDIDATE',
             'purpose': 'seen-scene sensor visibility / stability calibration; not repaired future gate',
             'intensity': args.intensity, 'cases': checks,
             'candidate_sha256': sha256(Path(__file__).parent/'native_clock_repair_candidate.py'),
             'collector_sha256': sha256(Path(__file__)),
             'sealed_native_sha256': sha256(Path(__file__).parent/'isaac_bridge_native.py')})
        print('REPAIR_DEVELOPMENT_COMPLETE', flush=True)
    except Exception:
        traceback.print_exc()
        dump(args.out/'error.json', {'traceback': traceback.format_exc()})
        sys.stdout.flush()
        sys.stderr.flush()
    finally:
        app.close()


if __name__ == '__main__':
    main()
