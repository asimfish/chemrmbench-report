"""Checkpoint-bound logical task time with a declared pause policy.

This is a storage/arithmetic contract. It cannot attest physical timestamps,
calibrate chemistry, or convert host seconds into simulation seconds.
"""
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
import re

from .staged_collection import digest,write_once
from .temporal_evidence_v74 import Interval,number


def _epoch(value,child_only=False):
    if type(value) is not str or not re.fullmatch(r'native_[a-z0-9]+:(parent|child):[a-f0-9]{16}',value):
        raise ValueError('named native epoch required; host time is not task time')
    if child_only and ':child:' not in value:raise ValueError('fresh child epoch required')
    return value


def _pairs(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise ValueError('duplicate record field')
        result[key]=value
    return result


def _read(path):
    if not path.is_file():raise ValueError('unfinished or missing predecessor record')
    raw=path.read_bytes()
    if len(raw)>262144:raise ValueError('clock record exceeds size limit')
    def reject(value):raise ValueError('nonfinite record value')
    return json.loads(raw,object_pairs_hook=_pairs,parse_constant=reject)


def _event(value):
    if set(value)!={'bounds_s','clock_id','kind','calibrated','endpoint_semantics'} or value['endpoint_semantics']!='CONSERVATIVE_CLOSED_BOUNDS':
        raise ValueError('explicit closed event interval required')
    if type(value['bounds_s']) is not list or len(value['bounds_s'])!=2:raise ValueError('two event bounds required')
    return Interval(*value['bounds_s'],value['clock_id'],value['kind'],value['calibrated'])


@dataclass(frozen=True)
class ClockBinding:
    native_clock_id:str
    clock_id:str
    native_origin_s:float
    task_origin_s:float

    def __post_init__(self):
        _epoch(self.native_clock_id)
        if type(self.clock_id) is not str or not re.fullmatch(r'task_v88:[a-f0-9]{16}',self.clock_id):
            raise ValueError('logical task clock required')
        number(self.native_origin_s,True);number(self.task_origin_s,True)

    def to_task_time(self,native_s):
        value=number(native_s,True)
        if value<self.native_origin_s:raise ValueError('native time predates declared binding')
        return number(self.task_origin_s+(value-self.native_origin_s),True)

    def to_task_interval(self,event):
        if not isinstance(event,Interval) or event.clock_id!=self.native_clock_id:
            raise ValueError('event does not belong to this native epoch')
        return Interval(self.to_task_time(event.lo),self.to_task_time(event.hi),
            self.clock_id,event.kind,False)


class TaskClockLedger:
    LEGACY_POLICY='PAUSED_BETWEEN_OWNED_PROCESSES_NATIVE_ONLY'
    SETUP_PAUSED_POLICY='PAUSED_PRE_RESTORE_SETUP_AND_HOST_DOWNTIME_NATIVE_ONLY'
    HEADER_FIELDS={'schema','task_id','checkpoint_sha256','clock_id','event_a','checkpoint_task_s',
        'requested_gap_s','tolerance_s','attempt_labels','clock_policy','scientific_admission'}

    @staticmethod
    def logical_clock_id(task_id,checkpoint_sha256):
        if type(task_id) is not str or not re.fullmatch(r'[A-Za-z0-9_:-]{1,80}',task_id):raise ValueError('bounded task identifier required')
        if type(checkpoint_sha256) is not str or not re.fullmatch(r'[a-f0-9]{64}',checkpoint_sha256):raise ValueError('physical checkpoint digest required')
        return 'task_v88:'+hashlib.sha256((task_id+':'+checkpoint_sha256).encode()).hexdigest()[:16]

    @classmethod
    def create(cls,directory,*,task_id,checkpoint_sha256,event_a,checkpoint_task_s,
               attempt_labels,requested_gap_s,tolerance_s,clock_policy=LEGACY_POLICY):
        directory=Path(directory);clock=cls.logical_clock_id(task_id,checkpoint_sha256)
        if not isinstance(event_a,Interval) or event_a.clock_id!=clock:raise ValueError('A event must already have an explicit logical binding')
        header=dict(schema='chemrm-task-clock-v88',task_id=task_id,checkpoint_sha256=checkpoint_sha256,
            clock_id=clock,event_a=event_a.to_dict(),checkpoint_task_s=number(checkpoint_task_s,True),
            requested_gap_s=number(requested_gap_s,True),tolerance_s=number(tolerance_s,True),
            attempt_labels=attempt_labels,clock_policy=clock_policy,scientific_admission=False)
        cls._validate_header(header)
        directory.mkdir(parents=True,exist_ok=False);write_once(directory/'HEADER.json',header)
        write_once(directory/'HEADER_COMMITTED.json',dict(header_sha256=digest(directory/'HEADER.json')))
        return cls(directory)

    @classmethod
    def _validate_header(cls,h):
        if set(h)!=cls.HEADER_FIELDS or h['schema']!='chemrm-task-clock-v88':raise ValueError('clock header schema')
        if h['clock_policy'] not in (cls.LEGACY_POLICY,cls.SETUP_PAUSED_POLICY) or h['scientific_admission'] is not False:raise ValueError('clock alignment cannot grant physical admission')
        if h['clock_id']!=cls.logical_clock_id(h['task_id'],h['checkpoint_sha256']):raise ValueError('checkpoint/task clock differs')
        event=_event(h['event_a'])
        if event.clock_id!=h['clock_id'] or event.hi>number(h['checkpoint_task_s'],True):raise ValueError('event must precede checkpoint on task clock')
        if number(h['requested_gap_s'],True)<=0:raise ValueError('positive target gap required')
        number(h['tolerance_s'],True)
        labels=h['attempt_labels']
        if type(labels) is not list or not 1<=len(labels)<=16 or any(type(x) is not str or not re.fullmatch(r'[a-z][a-z0-9_]{0,47}',x) for x in labels) or len(set(labels))!=len(labels):raise ValueError('unique declared attempt plan required')

    def __init__(self,directory):
        self.directory=Path(directory);self._header()

    def _header(self):
        h=_read(self.directory/'HEADER.json');commit=_read(self.directory/'HEADER_COMMITTED.json')
        if commit!={'header_sha256':digest(self.directory/'HEADER.json')}:raise ValueError('header digest changed')
        self._validate_header(h);return h

    @property
    def clock_id(self):return self._header()['clock_id']

    @property
    def event_a(self):return _event(self._header()['event_a'])

    @property
    def requested_gap_s(self):return self._header()['requested_gap_s']

    def _directory(self,index,header):return self.directory/'attempts'/f"{index:02d}-{header['attempt_labels'][index]}"

    def _sealed(self,index,h,kind):
        path=self._directory(index,h)/f'{kind}.json'
        commit=_read(path.with_name(kind+'_COMMITTED.json'))
        if commit!={kind.lower()+'_sha256':digest(path)}:raise ValueError('attempt digest changed')
        return _read(path)

    def _previous(self,index,h):
        task_time=h['checkpoint_task_s'];epochs=[];prior=None
        for i in range(index):
            start=self._sealed(i,h,'START');end=self._sealed(i,h,'END')
            self._check_start(start,i,h,task_time,prior)
            if start['native_clock_id'] in epochs:raise ValueError('reused native epoch')
            if set(end)!={'schema','start_sha256','native_end_s','task_end_s','outcome'} or end['schema']!='chemrm-task-clock-end-v88':raise ValueError('end schema')
            if end['start_sha256']!=digest(self._directory(i,h)/'START.json') or end['outcome'] not in ('REFUSED','FAILED','COMPLETED'):raise ValueError('end/start lineage differs')
            expected=ClockBinding(start['native_clock_id'],h['clock_id'],start['native_start_s'],task_time).to_task_time(end['native_end_s'])
            if number(end['task_end_s'],True)!=expected:raise ValueError('prior attempt time was reset')
            task_time=expected;epochs.append(start['native_clock_id']);prior=digest(self._directory(i,h)/'END.json')
        return task_time,epochs,prior

    def _check_start(self,start,index,h,task_time,prior):
        if set(start)!={'schema','label','header_sha256','prior_end_sha256','native_clock_id','native_start_s','task_origin_s'} or start['schema']!='chemrm-task-clock-start-v88':raise ValueError('start schema')
        if start['label']!=h['attempt_labels'][index] or start['header_sha256']!=digest(self.directory/'HEADER.json') or start['prior_end_sha256']!=prior:raise ValueError('start/checkpoint lineage differs')
        _epoch(start['native_clock_id'],True);number(start['native_start_s'],True)
        if number(start['task_origin_s'],True)!=task_time:raise ValueError('task origin was reset')

    def start_attempt(self,label,*,native_clock_id,native_start_s):
        h=self._header()
        if label not in h['attempt_labels']:raise ValueError('unregistered attempt label')
        index=h['attempt_labels'].index(label);task_time,epochs,prior=self._previous(index,h)
        _epoch(native_clock_id,True)
        if native_clock_id in epochs:raise ValueError('reused native epoch')
        native_start_s=number(native_start_s,True)
        path=self._directory(index,h);path.mkdir(parents=True,exist_ok=True)
        start=dict(schema='chemrm-task-clock-start-v88',label=label,
            header_sha256=digest(self.directory/'HEADER.json'),prior_end_sha256=prior,
            native_clock_id=native_clock_id,native_start_s=native_start_s,task_origin_s=task_time)
        write_once(path/'START.json',start);write_once(path/'START_COMMITTED.json',dict(start_sha256=digest(path/'START.json')))
        return ClockBinding(native_clock_id,h['clock_id'],native_start_s,task_time)

    def finish_attempt(self,label,*,native_end_s,outcome):
        h=self._header()
        if label not in h['attempt_labels'] or outcome not in ('REFUSED','FAILED','COMPLETED'):raise ValueError('declared attempt outcome required')
        index=h['attempt_labels'].index(label);task_time,epochs,prior=self._previous(index,h)
        start=self._sealed(index,h,'START');self._check_start(start,index,h,task_time,prior)
        binding=ClockBinding(start['native_clock_id'],h['clock_id'],start['native_start_s'],task_time)
        end=dict(schema='chemrm-task-clock-end-v88',start_sha256=digest(self._directory(index,h)/'START.json'),
            native_end_s=number(native_end_s,True),task_end_s=binding.to_task_time(native_end_s),outcome=outcome)
        path=self._directory(index,h);write_once(path/'END.json',end)
        write_once(path/'END_COMMITTED.json',dict(end_sha256=digest(path/'END.json')))
        return end

    def assess_attempt_start(self,label,*,native_now_s,latency_bounds_s):
        """Read immutable A/D/tolerance and the active origin, not caller overrides."""
        h=self._header()
        if label not in h['attempt_labels']:raise ValueError('unregistered attempt label')
        index=h['attempt_labels'].index(label);task_time,_,prior=self._previous(index,h)
        start=self._sealed(index,h,'START');self._check_start(start,index,h,task_time,prior)
        if (self._directory(index,h)/'END.json').exists():raise ValueError('completed attempt cannot dispatch')
        binding=ClockBinding(start['native_clock_id'],h['clock_id'],start['native_start_s'],task_time)
        return assess_start_window(_event(h['event_a']),
            now_s=binding.to_task_time(native_now_s),clock_id=h['clock_id'],
            requested_gap_s=h['requested_gap_s'],tolerance_s=h['tolerance_s'],
            latency_bounds_s=latency_bounds_s)


def assess_start_window(event_a,*,now_s,clock_id,requested_gap_s,tolerance_s,latency_bounds_s):
    if not isinstance(event_a,Interval) or event_a.clock_id!=clock_id:raise ValueError('same declared task clock required')
    now=number(now_s,True);gap=number(requested_gap_s,True);tol=number(tolerance_s,True)
    if now<event_a.hi or gap<=0 or type(latency_bounds_s) not in (tuple,list) or len(latency_bounds_s)!=2:raise ValueError('past event and positive gap/skill duration required')
    lo,hi=[number(x,True) for x in latency_bounds_s]
    if lo>hi:raise ValueError('ordered skill duration bounds required')
    start_lo=number(event_a.hi+gap-tol-lo);start_hi=number(event_a.lo+gap+tol-hi)
    status=('INFEASIBLE_EVENT_OR_SKILL_UNCERTAINTY' if start_lo>start_hi else
        'DEADLINE_EXPIRED' if now>start_hi else
        'WAIT_FOR_START_WINDOW' if now<start_lo else 'READY_TO_DISPATCH')
    return dict(status=status,schedule_feasible=status in ('WAIT_FOR_START_WINDOW','READY_TO_DISPATCH'),
        dispatch_allowed=status=='READY_TO_DISPATCH',start_bounds_s=[start_lo,start_hi],
        now_task_s=now,clock_id=clock_id,scientific_admission=False)
