"""Prospective V17 protocol; V16 remains a sealed failed diagnostic."""
from __future__ import annotations

import numpy as np
import json

from chemrm.papera.isaac_bridge_verify import sha256

from chemrm.papera.isaac_bridge_contract import Case
from chemrm.papera.native_leakage import (
    SCHEMA, AGES, ALPHAS, CHANNELS, validate_bank as validate_v16_bank,
)

REVISION = 'papera-fixed-light-v17'
LIGHT_INTENSITY = 50.
PAUSED_RENDERS = 64
SETTINGS = {
    '/rtx/directLighting/sampledLighting/enabled': False,
    '/rtx/directLighting/sampledLighting/autoEnable': False,
    '/rtx-transient/directLighting/sampledLighting/enforced': False,
}


def build_bank():
    geometry = np.random.default_rng(171008)
    timing = np.random.default_rng(271008)
    order = np.random.default_rng(371008)
    scenes, cases = [], []
    for i in range(48):
        split = 'train' if i < 16 else 'dev' if i < 24 else 'future'
        scene_id = f'v17_scene_{i:03d}'
        scene = {'scene_id': scene_id, 'split': split,
                 'scene_x': float(geometry.uniform(.4, .55)),
                 'spacing': float(geometry.uniform(.12, .18)),
                 'camera_height': float(geometry.uniform(1.5, 2.1)),
                 'onset_s': float(timing.integers(300, 2401)) / 60.}
        scenes.append(scene)
        for target in order.permutation(5).tolist():
            case = Case(case_id=f'{scene_id}_t{target}', family='C13',
                        split='future' if split == 'future' else 'dev', seed=171008+i,
                        target=target, onset_s=scene['onset_s'], wait_s=60.,
                        eta=.15, latency_s=0., scene_x=scene['scene_x'],
                        spacing=scene['spacing'], camera_height=scene['camera_height'],
                        equivalence_ml=10.)
            cases.append({'scene_id': scene_id, 'split': split, 'case': case.to_dict()})
    return {'schema': SCHEMA, 'revision': REVISION, 'ages_s': AGES,
            'fixed_query_s': 110., 'scenes': scenes, 'cases': cases,
            'alphas': ALPHAS, 'channels': CHANNELS,
            'renderer': {'settings': SETTINGS, 'distant_light_intensity': LIGHT_INTENSITY},
            'paused_control': {'target': 0, 'extra_render_calls': PAUSED_RENDERS,
                               'guard_mean_absolute_prediction_drift_s_max': 1.}}


def validate_bank(bank):
    validate_v16_bank(bank)
    if bank.get('revision') != REVISION or bank.get('renderer') != {
            'settings': SETTINGS, 'distant_light_intensity': LIGHT_INTENSITY}:
        raise ValueError('wrong V17 renderer protocol')
    if bank.get('paused_control') != {'target': 0, 'extra_render_calls': PAUSED_RENDERS,
            'guard_mean_absolute_prediction_drift_s_max': 1.}:
        raise ValueError('paused control differs from preregistration')
    # IDs alone cannot establish novelty: bind exact generated geometry and timing.
    if bank != build_bank():
        raise ValueError('V17 bank differs from its prospectively frozen generator')


def check_paused_invariants(control):
    samples = control['samples']
    if [r['extra_render_calls'] for r in samples] != [0, PAUSED_RENDERS]:
        raise ValueError('wrong paused render checkpoints')
    if samples[0]['physical_time'] != samples[1]['physical_time']:
        raise ValueError('physics advanced during render-only control')
    if samples[0]['joints'] != samples[1]['joints'] or samples[0]['events_sha256'] != samples[1]['events_sha256']:
        raise ValueError('native joints/events changed during render-only control')
    if not np.isfinite([samples[0]['physical_time'], *samples[0]['joints']]).all():
        raise ValueError('invalid native control state')


def bootstrap_mean(values, draws=2000):
    values = np.asarray(values, dtype=float)
    if values.ndim != 1 or len(values) < 2 or not np.isfinite(values).all():
        raise ValueError('two finite independent scene values required')
    rng = np.random.default_rng(171008)
    means = values[rng.integers(0, len(values), (draws, len(values)))].mean(axis=1)
    return np.quantile(means, [.025, .975]).tolist()


def verify_model_seal(models, freeze_path):
    path = models / 'fit_receipt.json'
    receipt = json.loads(path.read_text())
    if (receipt.get('revision') != REVISION or
            receipt.get('future_observations_read') is not False or
            receipt.get('freeze_sha256') != sha256(freeze_path) or
            receipt.get('status') != 'FROZEN_BEFORE_FUTURE_READ'):
        raise ValueError('invalid prospective model seal')
    tasks = {(g, t, c) for g, t in [('post', 'clock'), ('fixed_time', 'clock'),
             ('post', 'identity'), ('cue', 'identity')] for c in CHANNELS}
    choices = receipt['choices']
    if len(choices) != 12 or {(r['group'], r['target'], r['channel']) for r in choices} != tasks:
        raise ValueError('incomplete frozen model bank')
    for row in choices:
        if row['model'] != f"{row['group']}_{row['target']}_{row['channel']}.npz":
            raise ValueError('unexpected sealed model filename')
        if sha256(models / row['model']) != row['sha256']:
            raise ValueError('model changed after seal')
    if sha256(models / 'declared_age_oracle.npz') != receipt['oracle_sha256']:
        raise ValueError('changed sealed oracle')
    return sha256(path)
