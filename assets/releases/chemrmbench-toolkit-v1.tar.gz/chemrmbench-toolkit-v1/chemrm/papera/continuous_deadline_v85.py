"""Spend observed native readout time; never dispatch a late model proposal."""
import math
import re


class DeadlineExpired(RuntimeError):
    """A valid proposal became too late while the native environment advanced."""


def remaining_wait(schedule, *, native_start_s, native_end_s, native_epoch,
                   expected_epoch, callbacks, dt_s):
    if (not isinstance(schedule,dict) or schedule.get('dispatch') is not True
            or type(schedule.get('start_tick')) is not int or schedule['start_tick']<0):
        raise ValueError('checked dispatch schedule required')
    if (not isinstance(expected_epoch,str) or
            not re.fullmatch(r'native_v81:(parent|child):[a-f0-9]{16}',expected_epoch)
            or native_epoch!=expected_epoch):
        raise ValueError('same observed native epoch required')
    if (type(callbacks) is not int or not 0<=callbacks<=100000
            or any(type(v) not in (int,float) or not math.isfinite(v) for v in
                   (native_start_s,native_end_s,dt_s))
            or native_start_s<0 or native_end_s<native_start_s or not 1e-5<=dt_s<=.1):
        raise ValueError('finite monotonic native clock and callback count required')
    elapsed=native_end_s-native_start_s
    if abs(elapsed-callbacks*dt_s)>max(1e-7,callbacks*1e-7):
        raise ValueError('clock interval and actual integration callbacks disagree')
    left=schedule['start_tick']-callbacks
    if left<0:
        raise DeadlineExpired('model reply arrived after the registered native start boundary; no dispatch')
    return dict(schema='chemrm-continuous-deadline-v85',status='TIMELY_NATIVE_PROPOSAL',
        original_dispatch_tick=schedule['start_tick'],readout_ticks=callbacks,
        native_readout_elapsed_s=elapsed,remaining_wait_ticks=left,
        native_epoch=native_epoch,late_start_allowed=False,scientific_admission=False)
