"""Bounded, unambiguous JSON and immutable local release inventories.

Artifacts must be owned and quiescent while checked. These hashes detect byte
changes; they are not signatures or a concurrent hostile-filesystem sandbox.
"""
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat

MAX_FILE = 16 * 1024 * 1024
MAX_TOTAL = 64 * 1024 * 1024
MAX_FILES = 20000


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def same(left, right):
    """JSON identity keeps booleans distinct from integers and floats."""
    options=dict(sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
    return json.dumps(left,**options)==json.dumps(right,**options)


def digest(value):
    if type(value) is not str or not re.fullmatch('[a-f0-9]{64}', value):
        raise ValueError('SHA-256 digest required')
    return value


def directory(path):
    root = Path(path).absolute()
    if root.resolve() != root or not root.is_dir():
        raise ValueError('owned non-symlink directory required')
    return root


def relative(name):
    if (type(name) is not str or not name or '\\' in name or
        any(part in ('', '.', '..') for part in name.split('/')) or Path(name).is_absolute()):
        raise ValueError('canonical release-relative path required')
    return name


def read_bytes(root, name):
    path = directory(root) / relative(name)
    if path.resolve() != path.absolute():
        raise ValueError('symlink artifact refused')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    with os.fdopen(fd, 'rb') as handle:
        info = os.fstat(handle.fileno())
        if not stat.S_ISREG(info.st_mode) or info.st_size > MAX_FILE:
            raise ValueError('bounded regular artifact required')
        raw = handle.read(MAX_FILE + 1)
    if len(raw) > MAX_FILE:
        raise ValueError('artifact size limit exceeded')
    return raw


def _pairs(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError('duplicate JSON field')
        obj[key] = value
    return obj


def _invalid(value):
    raise ValueError('nonfinite JSON value')


def finite(value, depth=0):
    if depth > 48:
        raise ValueError('JSON nesting limit exceeded')
    if type(value) is float and not math.isfinite(value):
        raise ValueError('nonfinite numeric value')
    if isinstance(value, dict):
        for child in value.values():finite(child, depth+1)
    elif isinstance(value, list):
        for child in value:finite(child, depth+1)


def parse(raw):
    value = json.loads(raw, object_pairs_hook=_pairs, parse_constant=_invalid)
    finite(value)
    return value


def read(root, name):
    return parse(read_bytes(root, name))


def write(path, value):
    path = Path(path)
    raw = (json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)+'\n').encode()
    if len(raw) > MAX_FILE:
        raise ValueError('artifact size limit exceeded')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as handle:
        handle.write(raw); handle.flush(); os.fsync(handle.fileno())


def inventory(root):
    root = directory(root)
    files = {}; total = 0
    for folder, dirs, names in os.walk(root, followlinks=False):
        if any((Path(folder)/name).is_symlink() for name in dirs):
            raise ValueError('symlink directory refused')
        for name in names:
            rel = (Path(folder)/name).relative_to(root).as_posix()
            if rel in ('INDEX.json', 'COMMITTED.json'):continue
            raw = read_bytes(root, rel);total += len(raw)
            if total > MAX_TOTAL or len(files) >= MAX_FILES:
                raise ValueError('release inventory budget exceeded')
            files[rel] = {'sha256':sha(raw), 'bytes':len(raw)}
    return dict(sorted(files.items()))


def seal(root):
    root = directory(root)
    write(root/'INDEX.json', {'schema':'chemrm-release-index-v1','files':inventory(root)})
    write(root/'COMMITTED.json', {'index_sha256':sha(read_bytes(root, 'INDEX.json'))})
    fd=os.open(root, os.O_DIRECTORY)
    try:os.fsync(fd)
    finally:os.close(fd)


def verify_index(root, expected_sha256=None):
    root = directory(root)
    marker_raw = read_bytes(root, 'COMMITTED.json')
    if expected_sha256 is not None and sha(marker_raw) != digest(expected_sha256):
        raise ValueError('external release digest differs')
    marker = parse(marker_raw);index_raw = read_bytes(root, 'INDEX.json')
    if marker != {'index_sha256':sha(index_raw)}:
        raise ValueError('release commit marker differs')
    index = parse(index_raw)
    if type(index) is not dict or set(index) != {'schema','files'} or index['schema']!='chemrm-release-index-v1':
        raise ValueError('release index schema differs')
    if type(index['files']) is not dict or not 1 <= len(index['files']) <= MAX_FILES:
        raise ValueError('bounded artifact index required')
    for name, row in index['files'].items():
        relative(name)
        if type(row) is not dict or set(row) != {'sha256','bytes'} or type(row['bytes']) is not int or not 0 <= row['bytes'] <= MAX_FILE:
            raise ValueError('artifact index entry differs')
        digest(row['sha256'])
    if inventory(root) != index['files']:
        raise ValueError('release byte inventory differs')
    return index
