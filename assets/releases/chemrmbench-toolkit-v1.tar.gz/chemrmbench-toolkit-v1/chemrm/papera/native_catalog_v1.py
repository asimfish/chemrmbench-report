"""Audit existing native videos, frame clocks and stage projections together.

This reader verifies published evidence associations. It neither restores a
simulator nor substitutes projected states for the sealed raw state archive.
"""
import json
import math
from pathlib import Path
import subprocess
from chemrm.papera import release_io_v1 as io


def audit_native_catalog(site, *, expected_manifest_sha256, decode=False):
    root=io.directory(site)
    raw=io.read_bytes(root,'data/benchmark-system.json')
    if io.sha(raw)!=io.digest(expected_manifest_sha256):raise ValueError('native catalog identity differs')
    data=io.parse(raw)
    for field in ('full_benchmark_pass','formal_M1_admission','training_admission'):
        if data.get(field) is not False:raise ValueError('unsupported native admission')
    runs=data['runs'];hashes=data['public_asset_sha256']
    if type(runs) is not list or not 1<=len(runs)<=32:raise ValueError('bounded native catalog required')
    ids=set();checked={};rows=[]
    def asset(name):
        io.relative(name)
        if name not in checked:
            blob=io.read_bytes(root,name)
            if io.sha(blob)!=io.digest(hashes[name]):raise ValueError('native asset digest differs: '+name)
            checked[name]=dict(sha256=io.sha(blob),bytes=len(blob))
        return io.read_bytes(root,name)
    for run in runs:
        rid=run['id']
        if type(rid) is not str or rid in ids:raise ValueError('duplicate native run')
        ids.add(rid)
        for key in ('video','poster','frame_index','stage_states','receipt'):asset(run[key])
        if checked[run['video']]['sha256']!=run['video_sha256']:raise ValueError('cross-run video association')
        frames=io.parse(asset(run['frame_index']));states=io.parse(asset(run['stage_states']))
        receipt=io.parse(asset(run['receipt']))
        fps=run['video_fps'];offset=run.get('task_time_offset_s',0.0)
        if type(fps) not in (int,float) or not math.isfinite(fps) or fps<=0:
            raise ValueError('positive video rate required')
        if (type(run['video_frames']) is not int or len(frames)!=run['video_frames'] or
            not 1<=len(frames)<=20000 or not math.isclose(run['video_duration_s'],len(frames)/fps,abs_tol=1e-8)):
            raise ValueError('native frame count or duration differs')
        prior=-1.;cursor=-1
        for i,frame in enumerate(frames):
            elapsed=frame['native_elapsed_s'];current=frame.get('source_command_cursor',cursor)
            if (type(frame['index']) is not int or frame['index']!=i or
                not math.isclose(frame['video_pts_s'],i/fps,abs_tol=1e-8) or elapsed<prior or
                type(current) is not int or current<cursor or
                not math.isclose(frame.get('task_time_s',elapsed+offset),elapsed+offset,abs_tol=1e-8)):
                raise ValueError('native frame clock/cursor differs')
            io.digest(frame['image_sha256']);prior=elapsed;cursor=current
        if states['schema']!='chemrm-public-physical-stage-projection-v1' or states['hidden_solver_state_restored'] is not False:
            raise ValueError('native state projection scope differs')
        stage_ids=set();archived=0
        public_stages={s['id']:s for s in run['stages']}
        for stage in states['stages']:
            sid=stage['stage_id']
            if sid in stage_ids or sid not in public_stages:raise ValueError('stage association differs')
            stage_ids.add(sid);io.digest(stage['archive_state_sha256'])
            if stage['physical_restart_admitted'] is not False:raise ValueError('projection cannot grant restart admission')
            declaration=public_stages[sid]
            if declaration['archive_state_sha256']!=stage['archive_state_sha256']:
                raise ValueError('stage archive identity differs')
            if declaration['source_end_cursor']!=stage['source_command_cursor']:
                raise ValueError('stage source cursor differs')
            entities=stage['bodies']+stage['articulations']
            if len(entities)!=stage['registered_entities'] or len({e['id'] for e in entities})!=len(entities):
                raise ValueError('stage registry differs')
            if declaration['registered_entities']!=len(entities):raise ValueError('declared registry differs')
            for entity in entities:
                if len(entity['root_state'])!=13:raise ValueError('complete root state required')
            archived+=1
        decoded=False
        if decode:
            path=str(root/run['video'])
            probe=subprocess.run(['ffprobe','-v','error','-select_streams','v:0','-count_frames',
                                  '-show_entries','stream=nb_read_frames','-of','json',path],
                                 capture_output=True,text=True,timeout=60,check=True)
            result=json.loads(probe.stdout)
            if int(result['streams'][0]['nb_read_frames'])!=len(frames):raise ValueError('decoded native frame count differs')
            decoded=True
        rows.append(dict(id=rid,frames=len(frames),stages=archived,decoded=decoded,
                         task_time_offset_s=offset,receipt_status=receipt['status'],
                         video=run['video'],video_sha256=run['video_sha256']))
    coverage=data['stage_coverage']
    result=dict(schema='chemrm-native-evidence-audit-v1',status='PASS_EXISTING_NATIVE_EVIDENCE_ASSOCIATIONS',
                manifest_sha256=expected_manifest_sha256,runs=rows,assets_verified=len(checked),
                full_video_decode=all(r['decoded'] for r in rows),
                stage_projections=sum(r['stages'] for r in rows),
                ordinary_restart_boundaries=sum(s['cold_restart_verified'] is True for s in coverage),
                task_boundaries=len(coverage),scientific_admission=False,training_admission=False,
                full_benchmark_pass=False,new_native_workers=0,
                scope='Original videos/receipts/frame clocks/stage projections only; no new physics or raw-state restoration revalidation')
    return result
