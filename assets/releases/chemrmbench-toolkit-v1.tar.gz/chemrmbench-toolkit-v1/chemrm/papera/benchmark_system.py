"""Source-bound benchmark runner: owned collection and post-GPU video packaging."""
import argparse
import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import time

from .staged_collection import digest, write_once
from .video_evidence import encode_video


def preflight(root):
    p=json.loads((root/'protocol.json').read_text())
    pre=json.loads((root/'PREDECLARED.json').read_text())
    pins=json.loads((root/'source_pins.json').read_text())['files']
    assert digest(root/'protocol.json')==pre['protocol_sha256']
    assert digest(root/'source_pins.json')==pre['source_pins_sha256']
    assert all(digest(root/name)==value for name,value in pins.items())
    if p.get('schema') == 'chemrm-v98-balanced-repeated-pose-controls':
        from .repeated_restore_v98 import validate_plan
        validate_plan(p)
    else:
        assert p['native_phases'] in (['single_pose'], ['live','single_pose'])
    assert p['maximum_worker_count']==len(p['native_phases'])
    assert p['model_request_limit']==p['training_jobs']==0
    from .loaded_boundary_v93 import validated_robot_bounds
    bounds=validated_robot_bounds(json.loads((root/'inputs/original_contract.json').read_text()),p['joint_names'])
    write_once(root/'ROBOT_BOUNDS_PREFLIGHT.json',dict(status='PASS_PER_JOINT_BOUNDS_BEFORE_NATIVE_START',bounds=bounds))
    return p,pre,pins,bounds


def run_worker(root,p,pre,pins,phase):
    env=os.environ|{'LD_LIBRARY_PATH':pre['driver_capsule']}
    samples=[];waiting=time.monotonic()
    while True:
        text=subprocess.check_output(['nvidia-smi','-i',str(p.get('renderer_host_gpu_index',0)),'--query-gpu=uuid,memory.free',
              '--format=csv,noheader,nounits'],env=env,text=True,timeout=8)
        uuid,free=[s.strip() for s in text.split(',')]
        assert uuid==pre['selected_gpu_uuid']
        samples.append(dict(elapsed_s=time.monotonic()-waiting,free_mib=int(free)))
        if int(free)>=pre['minimum_free_gpu_mib']:break
        if time.monotonic()-waiting>=180:
            write_once(root/(phase+'_resource_wait.json'),dict(status='RESOURCE_GATE_BLOCKED',samples=samples))
            raise RuntimeError('unchanged GPU memory gate unavailable')
        time.sleep(10)
    write_once(root/(phase+'_resource_wait.json'),dict(status='RESOURCE_GATE_AVAILABLE',samples=samples))
    limit=pre['native_watchdog_s'];grace=pre['cancel_grace_s']
    command=['timeout','--signal=TERM',f'--kill-after={grace}s',f'{limit}s','bash',str(root/'launch.sh'),phase]
    start=time.monotonic();timed_out=False
    with (root/(phase+'.log')).open('x') as log:
        child=subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        write_once(root/(phase+'_running.json'),dict(pid=child.pid,phase=phase,
              started_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              max_seconds=limit,no_model_training_or_cloud_job=True))
        try:code=child.wait(timeout=limit+grace)
        except subprocess.TimeoutExpired:
            timed_out=True;os.killpg(child.pid,signal.SIGTERM)
            try:code=child.wait(timeout=grace)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);code=child.wait(timeout=grace)
    remaining=[]
    for entry in Path('/proc').iterdir():
        if entry.name.isdigit():
            try:
                if os.getpgid(int(entry.name))==child.pid:remaining.append(int(entry.name))
            except (PermissionError,ProcessLookupError):pass
    if remaining:os.killpg(child.pid,signal.SIGKILL)
    wall=time.monotonic()-start
    record=dict(phase=phase,exit_code=code,timed_out=timed_out or code in (124,137),wall_s=wall,
         upper_bound_allocated_gpu_hours=wall/3600,owned_main_process_exited=True,
         remaining_owned_members_at_exit=remaining,model_calls=0,scientific_admission=False)
    write_once(root/(phase+'_resource.json'),record)
    assert all(digest(root/name)==value for name,value in pins.items())
    print(json.dumps(record),flush=True)
    assert not record['timed_out'] and not remaining and code in (0,1)
    return record


def collect(root):
    p,pre,pins,bounds=preflight(root)
    resources=[]
    for phase in p['native_phases']:
        repeated=p.get('schema')=='chemrm-v98-balanced-repeated-pose-controls'
        previous={str(path.relative_to(root)):digest(path) for done in p['native_phases'][:len(resources)]
                  for path in (root/done).rglob('*') if path.is_file()} if repeated else None
        if repeated:write_once(root/(phase+'_preservation_before.json'),previous)
        if phase=='single_pose' and 'live' in p['native_phases']:
            preserved={str(path.relative_to(root)):digest(path) for path in (root/'live').rglob('*') if path.is_file()}
            write_once(root/'LIVE_PRESERVATION_BEFORE_SINGLE.json',preserved)
        record=run_worker(root,p,pre,pins,phase);resources.append(record)
        if phase=='live' or (repeated and phase==p['reference_phase']):assert record['exit_code']==0
        if repeated:
            assert all(digest(root/path)==sha for path,sha in previous.items())
            write_once(root/(phase+'_preservation_after.json'),previous)
        if phase=='single_pose' and 'live' in p['native_phases']:
            assert all(digest(root/path)==sha for path,sha in preserved.items())
            write_once(root/'LIVE_PRESERVATION_AFTER_SINGLE.json',preserved)
    write_once(root/'RUN_CLOSED.json',dict(status='OWNED_NATIVE_WORKERS_CLOSED_REQUIRES_RAW_REVIEW',
         native_workers=len(resources),resources=resources,
         total_allocated_gpu_hours_upper_bound=sum(r['upper_bound_allocated_gpu_hours'] for r in resources),
         model_calls=0,training_jobs=0,scientific_admission=False,full_benchmark_pass=False))


def main():
    parser=argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--action',choices=('collect','encode'),required=True)
    args=parser.parse_args();root=args.root.resolve()
    if args.action=='collect':collect(root)
    else:
        closed=json.loads((root/'RUN_CLOSED.json').read_text())
        resources=closed.get('resources',[closed.get('resource')])
        assert all(r and not r['remaining_owned_members_at_exit'] for r in resources)
        p=json.loads((root/'protocol.json').read_text())
        for phase in p['native_phases']:
            receipt=encode_video(root/phase/'task/video')
            print(json.dumps(dict(phase=phase,**receipt)),flush=True)


if __name__=='__main__':main()
