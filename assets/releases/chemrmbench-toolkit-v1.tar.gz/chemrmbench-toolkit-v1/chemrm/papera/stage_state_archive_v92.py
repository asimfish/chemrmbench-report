"""Full registered rigid-state archives attached to sealed stage evidence.

Archive commitment is separate from restart admission. Dynamic stages may be
saved without claiming that hidden solver state, particles, agent context or
their operation timers can be restored. This module never drives a simulator.
"""
import copy
import json
from pathlib import Path
import re

from .legacy_reconstruction.checkpoint_schema import validate_checkpoint,save_checkpoint,load_checkpoint
from .staged_collection import digest,verify_prefix,write_once,sync_directory


def _target(episode,stage_id):
    path=episode/'state_archives'/stage_id
    if path.resolve()!=path.absolute():raise ValueError('non-symlink archive directory required')
    return path


def _stage(episode,stage_id):
    if type(stage_id) is not str or not re.fullmatch(r'[a-z][a-z0-9_]{0,59}',stage_id):
        raise ValueError('bounded stage identifier required')
    verify_prefix(episode)
    path=episode/'stages'/stage_id/'manifest.json'
    marker=json.loads((path.parent/'COMMITTED.json').read_text())
    if marker!={'manifest_sha256':digest(path)}:raise ValueError('stage evidence changed')
    record=json.loads(path.read_text())
    if record['stage_id']!=stage_id:raise ValueError('stage identity differs')
    return path,record


def archive_stage_state(episode_directory,stage_id,state,*,expected_entity_ids,
                        expected_identity,scene_has_particles):
    if scene_has_particles is not False:
        raise ValueError('registered rigid snapshot cannot cover particles')
    episode=Path(episode_directory).resolve();parent,record=_stage(episode,stage_id)
    cp=validate_checkpoint(copy.deepcopy(state))
    if cp['identity']!=expected_identity or cp['chain_id']!=record['episode_id']:
        raise ValueError('state source or episode differs')
    graph=cp['task']['graph_position'];cursor=record['boundary_after'].get('command_index')
    if (type(graph) is not dict or type(cursor) is not int or cursor<0 or
        type(graph.get('next_command_index')) is not int or graph['next_command_index']!=cursor):
        raise ValueError('captured state and source-command cursor differ')
    ids=[v['id'] for group in ('bodies','articulations') for v in cp['physics'][group]]
    if (type(expected_entity_ids) not in (list,set,tuple) or not 1<=len(expected_entity_ids)<=512 or
        any(type(v) is not str for v in expected_entity_ids) or
        len(set(expected_entity_ids))!=len(expected_entity_ids) or
        len(ids)!=len(set(ids)) or set(ids)!=set(expected_entity_ids)):
        raise ValueError('complete registered entity set required')
    target=_target(episode,stage_id);target.mkdir(parents=True,exist_ok=False)
    save_checkpoint(target/'state.npz',cp)
    manifest=dict(schema='chemrm-full-registered-rigid-stage-archive-v92',stage_id=stage_id,
        episode_id=record['episode_id'],stage_manifest_sha256=digest(parent),
        state_sha256=digest(target/'state.npz'),source_command_cursor=cursor,
        recorded_host_tick=cp['host']['tick'],stage_end_native_s=record['actual_end_s'],
        registered_entities=len(ids),entity_ids=sorted(ids),
        source_identity=cp['identity'],state_scope='REGISTERED_RIGID_STATE_AND_HOST_RECORDS',
        motion_and_control_targets_preserved=True,physical_restart_admitted=False,
        hidden_solver_state_restored=False,particle_state_archived=False,
        agent_context_and_task_timer_rebound=False,scientific_admission=False,training_admission=False)
    write_once(target/'ARCHIVE.json',manifest)
    # Deliberately different from reconstruction/COMMITTED.json. Ordinary
    # continuation cannot accidentally treat this archive as an admitted CP.
    write_once(target/'ARCHIVE_COMMITTED.json',dict(archive_sha256=digest(target/'ARCHIVE.json')))
    sync_directory(target)
    return manifest


def load_archived_stage(episode_directory,stage_id):
    episode=Path(episode_directory).resolve();parent,record=_stage(episode,stage_id)
    target=_target(episode,stage_id)
    for name in ('ARCHIVE.json','ARCHIVE_COMMITTED.json','state.npz'):
        path=target/name
        if path.resolve()!=path.absolute():raise ValueError('non-symlink archive file required')
    manifest=json.loads((target/'ARCHIVE.json').read_text())
    marker=json.loads((target/'ARCHIVE_COMMITTED.json').read_text())
    if marker!={'archive_sha256':digest(target/'ARCHIVE.json')}:
        raise ValueError('archive commitment changed')
    if (manifest['schema']!='chemrm-full-registered-rigid-stage-archive-v92' or
        manifest['stage_id']!=stage_id or manifest['episode_id']!=record['episode_id'] or
        manifest['stage_manifest_sha256']!=digest(parent) or
        manifest['state_sha256']!=digest(target/'state.npz') or
        manifest['source_command_cursor']!=record['boundary_after'].get('command_index') or
        manifest['physical_restart_admitted'] is not False or
        manifest['agent_context_and_task_timer_rebound'] is not False or
        manifest['hidden_solver_state_restored'] is not False or
        manifest['particle_state_archived'] is not False or
        manifest['scientific_admission'] is not False or manifest['training_admission'] is not False):
        raise ValueError('archive source/admission differs')
    cp=load_checkpoint(target/'state.npz')
    ids=[v['id'] for group in ('bodies','articulations') for v in cp['physics'][group]]
    if (cp['identity']!=manifest['source_identity'] or cp['chain_id']!=record['episode_id'] or
        cp['task']['graph_position']['next_command_index']!=manifest['source_command_cursor'] or
        cp['host']['tick']!=manifest['recorded_host_tick'] or len(ids)!=len(set(ids)) or
        len(ids)!=manifest['registered_entities'] or sorted(ids)!=manifest['entity_ids']):
        raise ValueError('archive state lineage differs')
    return cp,manifest
