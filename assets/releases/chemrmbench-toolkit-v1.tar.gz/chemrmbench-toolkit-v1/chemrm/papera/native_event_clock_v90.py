"""Native integration boundary: immutable timer source and guarded proposals."""
from .task_clock_v88 import TaskClockLedger


class NativeInterruption(RuntimeError):
    """Predeclared reversible failure before the first tail command."""


def authorize_schedule(ledger,label,selected,*,native_now_s,latency_bounds_s):
    if not isinstance(ledger,TaskClockLedger):raise ValueError('committed task ledger required')
    if not selected.get('dispatch_requested'):raise ValueError('agent declined; no scripted substitute')
    header=ledger._header()
    if (selected['remembered_clock_id']!=header['clock_id']
        or selected['remembered_a_bounds_s']!=header['event_a']['bounds_s']
        or selected['requested_gap_s']!=header['requested_gap_s']):
        raise ValueError('proposal substituted the original event or deadline')
    gate=ledger.assess_attempt_start(label,native_now_s=native_now_s,latency_bounds_s=latency_bounds_s)
    low,high=gate['start_bounds_s']
    if not low<=selected['start_task_s']<=high:
        raise ValueError('proposed start cannot satisfy the original interval tolerance')
    return gate
