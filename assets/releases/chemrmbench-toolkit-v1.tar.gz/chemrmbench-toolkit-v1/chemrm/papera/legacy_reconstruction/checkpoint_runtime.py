"""Isaac-facing adapter for checkpoint_schema.

This module contains no simulator startup. Callers pass the live twin namespace
(`scene`, `PLAN`, `PLAN_PATH`, `args`, `DT`, `dev`) and a Recorder instance.
"""
from __future__ import annotations
import hashlib, json
from pathlib import Path
from typing import Any
from .checkpoint_schema import SCHEMA_NAME, SCHEMA_VERSION, validate_checkpoint, save_checkpoint


def _list(x):
    if hasattr(x, 'detach'): x=x.detach().cpu()
    if hasattr(x, 'tolist'): return x.tolist()
    return x


def _sha(path):
    p=Path(path)
    return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None


def _root_state(asset):
    d=asset.data
    # Explicitly use root_* (not root_link/root_com), matching schema contract.
    pos = getattr(d, 'root_pos_w')[0]; quat = getattr(d, 'root_quat_w')[0]
    vel = getattr(d, 'root_velocity_w', None)
    if vel is not None:
        lin, ang = vel[0, :3], vel[0, 3:]
    else:
        lin = getattr(d, 'root_lin_vel_w')[0]
        ang = getattr(d, 'root_ang_vel_w')[0]
    return _list(__import__('torch').cat((pos, quat, lin, ang)))


def _targets(asset, n, fallback):
    d=asset.data
    out=[]
    for field in ('joint_pos_target','joint_vel_target','joint_effort_target'):
        v=getattr(d, field, None)
        if v is None: v=fallback
        v=v[0] if hasattr(v,'ndim') and v.ndim>1 else v
        out.append(_list(v))
    return out


def capture(ns: dict[str, Any], rec: Any, *, chain_id: str='single', segment_index: int=0,
            boundary_kind: str='task_boundary', carry_mode: str|None=None) -> dict[str, Any]:
    scene, plan, plan_path = ns['scene'], ns['PLAN'], Path(ns['PLAN_PATH'])
    torch=__import__('torch')
    robots={r['prim_path'].split('/')[-1] for r in plan.get('robots',[])}
    bodies=[]; articulations=[]; doors=[]
    for name, asset in scene.rigid_objects.items():
        prim=next((p for p in plan.get('prims',[]) if p.get('name')==name),{})
        bodies.append({'id':name,'prim_path':str(asset.cfg.prim_path),'root_state':_root_state(asset)})
    for name, asset in scene.articulations.items():
        state=_root_state(asset); d=asset.data
        names=list(asset.joint_names)
        pos=_list(d.joint_pos[0]); vel=_list(d.joint_vel[0])
        targets=_targets(asset,len(names),d.joint_pos)
        runtime={}
        view=getattr(asset,'root_physx_view',None)
        for method,key in (('get_dof_stiffnesses','stiffness'),('get_dof_dampings','damping'),('get_dof_max_forces','effort_limit')):
            if view is not None and hasattr(view,method):
                try: runtime[key]=_list(getattr(view,method)()[0])
                except Exception: pass
        row={'id':name,'prim_path':str(asset.cfg.prim_path),'joint_names':names,
             'joint_position':pos,'joint_velocity':vel,'joint_position_target':targets[0],
             'joint_velocity_target':targets[1],'joint_effort_target':targets[2],
             'runtime_properties':runtime,'root_state':state}
        if name in robots: articulations.append(row)
        else:
            # Doors/windows have a compact duplicate joint view for explicit auditing.
            articulations.append(row)
            for j,jn in enumerate(names):
                doors.append({'id':f'{name}:{jn}','joint_name':jn,
                              'position':float(pos[j]),'velocity':float(vel[j]),
                              'position_target':float(targets[0][j]),'runtime_properties':runtime})
    asset_sha={}
    for p in plan.get('prims',[]):
        f=p.get('prepared_usd')
        if f and _sha(f): asset_sha[p['name']]=_sha(f)
    for r in plan.get('robots',[]):
        if r.get('usd') and _sha(r['usd']): asset_sha[r['prim_path'].split('/')[-1]]=_sha(r['usd'])
    identity={'scene_id': plan.get('scene_id') or ns.get('SCENE_ID', 'wf01_powderdosing'), 'layout_version': plan.get('layout_version') or ns.get('LAYOUT_VERSION', 'layout_v4'),'layout_plan_path':str(plan_path),
      'layout_plan_sha256':_sha(plan_path),
      'input_manifest_sha256':plan.get('input_manifest_sha256') or ns.get('INPUT_MANIFEST_SHA256',''),
      'asset_sha256':asset_sha,'executor_source_sha256':_sha(Path(ns['__file__'])) if ns.get('__file__') else 'unknown',
      'isaac_version':str(ns.get('ISAAC_VERSION','unknown')),'physx_version':str(ns.get('PHYSX_VERSION','unknown')),
      'dt':float(ns.get('DT',1/60)),'solver_profile':str(ns.get('SOLVER_PROFILE','global255/32')),
      'device':str(ns.get('dev','cpu')),'contact_offset':float(ns.get('CONTACT_OFFSET',0.001)),
      'rest_offset':float(ns.get('REST_OFFSET',0.0)),'root_state_variant':'root_state'}
    kin={k:[_list(v[0]),_list(v[1])] for k,v in rec.kin.items()}
    pinned={k:_list(v) for k,v in rec.pinned.items()}
    arms={}
    if rec.arm is not None:
        a=rec.arm; d=a.r.data; tp,tq=a.tcp()
        arms[a.robot_name]={'g_closed':_list(a.g_closed),'g_open':_list(a.g_open),
          'last_arm_target':_list(a.last),'last_gripper_target':_list(a.last_g),
          'tcp_pose':_list(torch.cat((tp,tq))),'b20_bias':_list(getattr(a,'b20_bias',torch.zeros(6)))}
    cp={'schema':SCHEMA_NAME,'schema_version':SCHEMA_VERSION,'identity':identity,
      'physics':{'bodies':bodies,'articulations':articulations,'doors_windows':doors},
      'host':{'kin':kin,'kinematic_support':sorted(getattr(rec,'kinematic_support',set())),
        'pinned':pinned,'contact_frames':_list(rec.contact_frames[-6:]),
        'tick':int(rec.tick),'metrics':rec.metrics,'contract':getattr(rec,'contract',{}),'arms':arms},
      'randomness':{'seed':int(getattr(ns.get('rng',None),'seed',getattr(ns.get('args',None),'seed',0))),
                    'draw_count':int(ns.get('RNG_DRAW_COUNT',0))},
      'task':{'graph_position':getattr(rec,'task_graph_position',None),'metrics':rec.metrics},
      'chain_id':chain_id,'segment_index':int(segment_index),'boundary_kind':boundary_kind,
      'carry_mode':carry_mode or ('kinematic_after_verified_grasp' if kin else 'none'),
      'resumed_mid_carry':bool(kin)}
    return validate_checkpoint(cp)


def restore(ns: dict[str, Any], rec: Any, cp: dict[str, Any], *, settle_ticks: int=0) -> dict[str, Any]:
    """Restore into an existing sim; caller owns stepping and verification."""
    import torch
    cp=validate_checkpoint(cp)
    scene, plan = ns['scene'], ns['PLAN']; dev=ns.get('dev','cpu')
    expected=ns.get('CHECKPOINT_IDENTITY')
    if expected is None or cp['identity'] != expected: raise RuntimeError('checkpoint identity missing or mismatch; restore refused')
    if {x['id'] for x in cp['physics']['bodies']} != set(scene.rigid_objects):
        raise RuntimeError('rigid-object registry mismatch; restore refused')
    if {x['id'] for x in cp['physics']['articulations']} != set(scene.articulations):
        raise RuntimeError('articulation registry mismatch; restore refused')
    for row in cp['physics']['articulations']:
        if row['joint_names'] != list(scene.articulations[row['id']].joint_names):
            raise RuntimeError('joint-name registry mismatch; restore refused')
    ids=torch.arange(scene.num_envs,device=dev,dtype=torch.long)
    by_id={x['id']:x for x in cp['physics']['bodies']}
    for name, asset in scene.rigid_objects.items():
        row=by_id.get(name)
        if row is None: raise RuntimeError(f'checkpoint missing rigid body {name}')
        s=torch.tensor(row['root_state'],dtype=torch.float32,device=dev)[None]
        asset.write_root_pose_to_sim(s[:,:7],env_ids=ids)
        if name not in ns.get('KINEMATIC_RIGID_NAMES',set()):
            velocity=s[:,7:] if cp['schema_version']>=3 else torch.zeros_like(s[:,7:])
            asset.write_root_velocity_to_sim(velocity,env_ids=ids)
    for row in cp['physics']['articulations']:
        name=row['id']; asset=scene.articulations.get(name)
        if asset is None: raise RuntimeError(f'checkpoint missing articulation {name}')
        s=torch.tensor(row['root_state'],dtype=torch.float32,device=dev)[None]
        asset.write_root_pose_to_sim(s[:,:7],env_ids=ids)
        velocity=s[:,7:] if cp['schema_version']>=3 else torch.zeros_like(s[:,7:])
        asset.write_root_velocity_to_sim(velocity,env_ids=ids)
        q=torch.tensor(row['joint_position'],dtype=torch.float32,device=dev)[None]
        qd=(torch.tensor(row['joint_velocity'],dtype=torch.float32,device=dev)[None]
            if cp['schema_version']>=3 else torch.zeros_like(q))
        asset.write_joint_state_to_sim(q,qd,env_ids=ids)
        asset.set_joint_position_target(torch.tensor(row['joint_position_target'],dtype=torch.float32,device=dev)[None],env_ids=ids)
        if hasattr(asset,'set_joint_velocity_target'):
            asset.set_joint_velocity_target(torch.tensor(row['joint_velocity_target'],dtype=torch.float32,device=dev)[None],env_ids=ids)
        if hasattr(asset,'set_joint_effort_target'): asset.set_joint_effort_target(torch.tensor(row['joint_effort_target'],dtype=torch.float32,device=dev)[None],env_ids=ids)
        for key,method in (('stiffness','write_joint_stiffness_to_sim'),('damping','write_joint_damping_to_sim'),('effort_limit','write_joint_effort_limit_to_sim')):
            if key in row['runtime_properties']:
                getattr(asset,method)(torch.tensor(row['runtime_properties'][key],dtype=torch.float32,device=dev)[None],env_ids=ids)
    rec.kin={k:(torch.tensor(v[0],device=dev),torch.tensor(v[1],device=dev)) for k,v in cp['host']['kin'].items()}
    rec.kinematic_support=set(cp['host'].get('kinematic_support',[]))
    rec.pinned={k:torch.tensor(v,dtype=torch.float32,device=dev) for k,v in cp['host']['pinned'].items()}
    rec.contact_frames=list(cp['host']['contact_frames'][-6:]); rec.recent_contacts=[c for f in rec.contact_frames for c in f]
    rec.tick=int(cp['host']['tick']); rec.metrics=cp['host']['metrics']; rec.contract=cp['host']['contract']
    if rec.arm is not None:
        a=rec.arm; state=cp['host']['arms'][a.robot_name]
        for field,key in (('g_closed','g_closed'),('g_open','g_open'),('last','last_arm_target'),('last_g','last_gripper_target'),('b20_bias','b20_bias')):
            setattr(a,field,torch.tensor(state[key],dtype=torch.float32,device=dev))
    return {'restored_tick':rec.tick,'carry_mode':cp['carry_mode'],'contact_history_frames':len(rec.contact_frames),'settle_ticks_requested':settle_ticks}
