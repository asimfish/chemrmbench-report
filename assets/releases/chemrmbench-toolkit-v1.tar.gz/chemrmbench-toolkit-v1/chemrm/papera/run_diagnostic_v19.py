"""Native development interventions; preserves the sealed V15-V18 providers."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time
import traceback
from chemrm.papera.diagnostic_v19 import REVISION, RENDER_COUNTS, verify_freeze, check_render_only
from chemrm.papera.isaac_bridge_contract import Case
from chemrm.papera.isaac_bridge_verify import sha256
from chemrm.papera.native_leakage import dump


def state(backend):
    return dict(joints=backend.robot.get_joint_positions().tolist(),
                joint_velocities=backend.robot.get_joint_velocities().tolist(),
                tool_xyz=backend.robot.end_effector.get_world_pose()[0].tolist(),
                marker_xyz=[m.get_world_pose()[0].tolist() for m in backend.markers],
                marker_colors=[m.get_applied_visual_material().get_color().tolist() for m in backend.markers],
                camera_xyz=backend.camera.get_world_pose()[0].tolist(),
                rotor_xyz=backend.rotor.get_world_pose()[0].tolist(),
                rotor_orientation=backend.rotor.get_world_pose()[1].tolist(),
                probe_xyz=backend.probe.get_world_pose()[0].tolist())


def digest_value(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    for n in ('bank', 'freeze', 'out', 'asset'):
        p.add_argument('--' + n, type=Path, required=True)
    p.add_argument('--gpu', type=int, default=0)
    a = p.parse_args()
    f = verify_freeze(a.bank, a.freeze)
    bank = json.loads(a.bank.read_text())
    a.out.mkdir(parents=True, exist_ok=False)
    dump(a.out/'start.json', dict(revision=REVISION, started_at_utc=datetime.now(timezone.utc).isoformat(),
         scope=bank['scope'], expected_cases=len(bank['cases']), freeze_sha256=sha256(a.freeze),
         asset_sha256=sha256(a.asset), sources=f['sources']))
    sys.argv = [sys.argv[0]]
    from isaacsim import SimulationApp
    app = SimulationApp({'headless': True, 'active_gpu': a.gpu, 'physics_gpu': a.gpu,
                         'multi_gpu': False, 'width': 320, 'height': 320,
                         'renderer': 'RayTracedLighting'})
    failed = False
    try:
        import numpy as np
        from PIL import Image
        import carb
        from chemrm.papera.fixed_light_native_v17 import FixedLightV17
        from chemrm.papera.fixed_light_features import fixed_light_features
        b = FixedLightV17(str(a.asset))
        receipts, frame_count = [], 0
        settings = carb.settings.get_settings()
        renderer_keys = ['/rtx/post/aa/op', '/rtx/indirectDiffuse/enabled',
            '/rtx/ambientOcclusion/enabled', '/rtx/reflections/enabled', '/rtx/shadows/enabled',
            '/rtx/ecoMode/enabled', '/rtx-transient/dlssg/enabled']
        for row in bank['cases']:
            started = time.perf_counter()
            case = Case(**row['case']); folder = a.out/case.case_id; folder.mkdir()
            b.reset(case)
            observations = []

            def save(rgb, name, **metadata):
                nonlocal frame_count
                Image.fromarray(rgb).save(folder/name)
                frame_count += 1
                return dict(file=name, sha256=sha256(folder/name), detector=fixed_light_features(rgb), **metadata)

            for phase, query in [('before', case.onset_s-1.), ('cue', case.onset_s+1.)]:
                b.advance(max(0., query-b.now))
                if phase == 'cue' and row['history_mode'] == 'cue_not_rendered':
                    continue
                snap = b.capture()
                observations.append(save(snap.rgb, phase+'.png', phase=phase,
                    captured_at=snap.captured_at, rendered_at=snap.rendered_at, joints=snap.joints.tolist()))
            b.advance(max(0., case.onset_s+bank['post_age_s']-b.now))
            snap = b.capture()
            controls = []
            for count in RENDER_COUNTS:
                if count:
                    previous = controls[-1]['extra_render_calls']
                    for _ in range(count-previous):
                        b.world.render()
                b.check_settings()
                rgb = snap.rgb if count == 0 else np.asarray(b.camera.get_rgba())[:, :, :3].copy()
                current_state = state(b)
                sample = save(rgb, f'post_{count}.png', extra_render_calls=count,
                    physical_time=b.now, joints=b.robot.get_joint_positions().tolist(),
                    physical_state_sha256=digest_value(current_state), events_sha256=digest_value(b.events),
                    state=current_state, renderer_settings={k:settings.get(k) for k in renderer_keys})
                controls.append(sample)
            check_render_only(controls)
            dump(folder/'audit.json', {**row, 'revision':REVISION, 'events':b.events,
                 'observations':observations, 'paused_control':{'samples':controls},
                 'wall_seconds':time.perf_counter()-started})
            receipts.append(dict(case_id=case.case_id, audit_sha256=sha256(folder/'audit.json')))
            print(f'CASE_DONE {len(receipts)}/{len(bank["cases"])} {case.case_id}', flush=True)
        verify_freeze(a.bank, a.freeze)
        dump(a.out/'manifest.json', dict(revision=REVISION, status='COMPLETE', scope=bank['scope'],
             cases=receipts, frame_count=frame_count, render_only_case_count=len(receipts),
             start_sha256=sha256(a.out/'start.json'), freeze_sha256=sha256(a.freeze)))
        print(f'NATIVE_V19_DIAGNOSTIC_COMPLETE {frame_count}', flush=True)
    except Exception:
        failed = True
        traceback.print_exc()
        dump(a.out/'error.json', dict(traceback=traceback.format_exc()))
    finally:
        app.close()
    if failed:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
