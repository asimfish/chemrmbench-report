"""Freeze timing contracts, run a batch, or independently verify a release."""
import argparse
import json
from chemrm.papera.benchmark_release_v1 import BACKENDS,freeze_task_contract,run_release,verify_release
from chemrm.papera.native_catalog_v1 import audit_native_catalog


def main(argv=None):
    parser=argparse.ArgumentParser(description=__doc__,allow_abbrev=False)
    commands=parser.add_subparsers(dest='action',required=True)
    freeze=commands.add_parser('freeze-tasks');freeze.add_argument('--out',required=True)
    freeze.add_argument('--seed',type=int,default=19)
    run=commands.add_parser('run');run.add_argument('--manifest',required=True)
    run.add_argument('--backend',choices=tuple(BACKENDS),required=True)
    run.add_argument('--policy',choices=('reference','abstain','high-rate'),default='reference')
    run.add_argument('--max-steps',type=int,default=1000)
    run.add_argument('--out',required=True);run.add_argument('--release-id',default='papera-contract-v1')
    verify=commands.add_parser('verify');verify.add_argument('release')
    verify.add_argument('--expected-sha256')
    native=commands.add_parser('audit-native');native.add_argument('--site',required=True)
    native.add_argument('--expected-manifest-sha256',required=True)
    native.add_argument('--decode',action='store_true')
    args=parser.parse_args(argv)
    try:
        if args.action=='freeze-tasks':
            result=dict(manifest=str(freeze_task_contract(args.out,args.seed)),status='FROZEN_TASK_CONTRACT')
        elif args.action=='run':
            root=run_release(manifest_dir=args.manifest,backend=args.backend,out_dir=args.out,
                             release_id=args.release_id,policy=args.policy,max_steps=args.max_steps)
            result=verify_release(root)
        elif args.action=='verify':result=verify_release(args.release,args.expected_sha256)
        else:result=audit_native_catalog(args.site,expected_manifest_sha256=args.expected_manifest_sha256,decode=args.decode)
    except (ValueError,OSError) as exc:
        print(json.dumps(dict(status='REFUSED_RELEASE',reason=str(exc)),ensure_ascii=False));return 2
    print(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True));return 0


if __name__=='__main__':raise SystemExit(main())
