"""Read-only interval timing CLI for calibrated or diagnostic event packets.

python -B -m chemrm.papera.run_temporal_evidence_v74 --input packet.json
Scores never turn uncalibrated input into formal benchmark success.
"""
import argparse
import json
from pathlib import Path
from chemrm.papera.temporal_evidence_v74 import Interval,score_gap


def event(record):
    if record is None:return None
    expected={'bounds_s','clock_id','kind','calibrated','endpoint_semantics'}
    if type(record) is not dict or set(record)!=expected or record['endpoint_semantics']!='CONSERVATIVE_CLOSED_BOUNDS':raise ValueError('exact interval evidence schema required')
    bounds=record['bounds_s']
    if type(bounds) is not list or len(bounds)!=2:raise ValueError('two typed interval endpoints required')
    return Interval(bounds[0],bounds[1],record['clock_id'],record['kind'],record['calibrated'])


def score_packet(packet):
    if type(packet) is not dict or set(packet)!={'a','b','requested_gap_s','tolerances_s','admission_checks'}:raise ValueError('exact timing packet schema required')
    tolerances=packet['tolerances_s']
    if type(tolerances) is not list or not 1<=len(tolerances)<=32 or len(set(tolerances))!=len(tolerances):raise ValueError('bounded unique timing tolerances required')
    if type(packet['admission_checks']) is not dict or set(packet['admission_checks'])-{'physics','event_definitions','public_cue'}:raise ValueError('declared physical/calibration gates only')
    return [score_gap(event(packet['a']),event(packet['b']),packet['requested_gap_s'],eps,packet['admission_checks']) for eps in tolerances]


def main():
    ap=argparse.ArgumentParser(description=__doc__.splitlines()[0]);ap.add_argument('--input',required=True,type=Path);args=ap.parse_args()
    with args.input.open('rb') as source:data=source.read(65537)
    if len(data)>65536:raise ValueError('bounded64KiB timing packet required')
    def pairs(items):
        result={}
        for k,v in items:
            if k in result:raise ValueError('duplicate JSON key')
            result[k]=v
        return result
    def constant(value):raise ValueError('nonfinite JSON literal')
    packet=json.loads(data,object_pairs_hook=pairs,parse_constant=constant)
    print(json.dumps(dict(scores=score_packet(packet),scope='READONLY_INTERVAL_SCORING_NO_ACQUISITION_OR_CALIBRATION'),indent=2,allow_nan=False))


if __name__=='__main__':main()
