"""Keep semantic experiment paths out of the actor's actual working directory.

The existing tool-disabled client runs in an opaque temporary workspace. Private
archive paths are used only after that call; failed/uncertain evidence is retained
without another provider attempt. This does not attest undocumented provider input.
"""
import json
from pathlib import Path
import shutil
import tempfile

from .codex_memory_v81 import invoke
from .staged_collection import digest,write_once


FILES={'observation.jpg','observation.png','prompt.txt','public_request.json','schema.json','CLIENT_CONTEXT.json',
       'command.json','events.jsonl','stderr.log','answer.json','receipt.json'}


def invoke_blind(directory,observation,image,*,client=None,**kwargs):
    archive=Path(directory).resolve()
    # Fence the client invocation before any upstream work, including concurrent
    # callers. Reserving private archive storage does not make it the actor cwd.
    archive.mkdir(parents=True,exist_ok=False)
    owner=Path(tempfile.mkdtemp(prefix='chemrm-actor-',dir='/tmp'))
    work=owner/'request';client=invoke if client is None else client
    write_once(archive/'CLIENT_STARTED.json',dict(actual_actor_workdir=str(work),
        automatic_retry=False,client_invocations=1))
    answer=None;failure=None
    try:
        answer=client(work,observation,image,**kwargs)
    except BaseException as error:
        failure=error
    try:
        copied={};unexpected=[]
        for path in work.iterdir() if work.is_dir() else []:
            if path.name not in FILES or path.is_symlink() or not path.is_file():
                unexpected.append(path.name);continue
            target=archive/path.name;shutil.copyfile(path,target);copied[path.name]=digest(target)
        command_path=archive/'command.json'
        command=json.loads(command_path.read_text()) if command_path.exists() else []
        semantic_path_in_arguments=any(str(archive) in str(arg) for arg in command)
        write_once(archive/'ACTOR_WORKSPACE.json',dict(
            schema='chemrm-opaque-actor-workspace-v89',actual_actor_workdir=str(work),
            archive_was_actor_workdir=False,semantic_experiment_paths_in_cli_arguments=semantic_path_in_arguments,
            actual_workdir_scope='OPAQUE_TEMP_DIRECTORY_OUTSIDE_EXPERIMENT_TREE',
            files_sha256=copied,unexpected_entries=unexpected,client_invocations=1,
            automatic_retry=False,client_completed=failure is None,scientific_admission=False,
            undocumented_provider_context_attested=False))
        if unexpected:raise ValueError('unexpected actor workspace entries; no source dereferencing')
        if semantic_path_in_arguments:raise ValueError('semantic archive path appeared in actor arguments')
    finally:
        # Only the exact fresh directory owned by this invocation is removed.
        shutil.rmtree(owner)
    if failure is not None:raise failure
    return answer
