"""Collect paired native frames; a diagnostic collector, never an actor policy."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import time
import traceback

from chemrm.papera.native_leakage import validate_bank, dump, SCHEMA
from chemrm.papera.isaac_bridge_contract import Case
from chemrm.papera.isaac_bridge_verify import sha256


def verify_freeze(bank_path, freeze_path):
    freeze = json.loads(freeze_path.read_text())
    if sha256(bank_path) != freeze['bank_sha256']:
        raise ValueError('bank changed after preregistration')
    root = Path(__file__).resolve().parents[2]
    for name, digest in freeze['sources'].items():
        if sha256(root / name) != digest:
            raise ValueError(f'frozen source differs: {name}')
    return freeze


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bank', type=Path, required=True)
    parser.add_argument('--freeze', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--asset', type=Path, required=True)
    parser.add_argument('--splits', nargs='+', choices=['train', 'dev', 'future'], required=True)
    parser.add_argument('--gpu', type=int, default=0)
    args = parser.parse_args()
    freeze = verify_freeze(args.bank, args.freeze)
    bank = json.loads(args.bank.read_text())
    validate_bank(bank)
    cases = [r for r in bank['cases'] if r['split'] in args.splits]
    args.out.mkdir(parents=True, exist_ok=False)
    dump(args.out / 'start.json', {'schema': SCHEMA, 'splits': args.splits,
         'expected_cases': len(cases), 'freeze_sha256': sha256(args.freeze),
         'sources': freeze['sources'], 'asset_sha256': sha256(args.asset)})
    sys.argv = [sys.argv[0]]
    from isaacsim import SimulationApp
    app = SimulationApp({'headless': True, 'active_gpu': args.gpu, 'physics_gpu': args.gpu,
                         'multi_gpu': False, 'width': 320, 'height': 320,
                         'renderer': 'RayTracedLighting'})
    try:
        from PIL import Image
        from chemrm.papera.isaac_bridge_native import IsaacBridge
        from chemrm.papera.isaac_bridge_policies import visual_features
        backend = IsaacBridge(str(args.asset))
        receipts = []
        for row in cases:
            started = time.perf_counter()
            case = Case(**row['case'])
            folder = args.out / case.case_id
            folder.mkdir()
            backend.reset(case)
            observations = []
            queries = [('before', case.onset_s - 1.), ('cue', case.onset_s + 1.)]
            queries += [(f'age_{int(age)}', case.onset_s + age) for age in bank['ages_s']]
            queries += [('fixed_time', bank['fixed_query_s'])]
            for phase, query in queries:
                remaining = query - backend.now
                if remaining < -.02:
                    raise ValueError('nonmonotone capture schedule')
                backend.advance(max(0., remaining))
                snap = backend.capture()
                filename = f'{phase}.png'
                Image.fromarray(snap.rgb).save(folder / filename)
                observations.append({'phase': phase, 'file': filename,
                     'sha256': sha256(folder / filename), 'captured_at': snap.captured_at,
                     'rendered_at': snap.rendered_at, 'joints': snap.joints.tolist(),
                     'detector': visual_features(snap.rgb)})
            dump(folder / 'audit.json', {**row, 'events': backend.events,
                 'observations': observations, 'wall_seconds': time.perf_counter() - started})
            receipts.append({'case_id': case.case_id, 'audit_sha256': sha256(folder / 'audit.json')})
            print(f"CASE_DONE {len(receipts)}/{len(cases)} {case.case_id} "
                  f"{time.perf_counter()-started:.2f}s", flush=True)
        verify_freeze(args.bank, args.freeze)
        dump(args.out / 'manifest.json', {'schema': SCHEMA, 'status': 'COMPLETE',
             'splits': args.splits, 'freeze_sha256': sha256(args.freeze),
             'cases': receipts, 'frame_count': 7 * len(receipts)})
        print('NATIVE_LEAKAGE_COLLECTION_COMPLETE', flush=True)
    except Exception:
        traceback.print_exc()
        dump(args.out / 'error.json', {'traceback': traceback.format_exc()})
        sys.stdout.flush()
        sys.stderr.flush()
    finally:
        app.close()


if __name__ == '__main__':
    main()
