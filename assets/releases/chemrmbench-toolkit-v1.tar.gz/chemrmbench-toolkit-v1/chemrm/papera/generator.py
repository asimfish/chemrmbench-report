"""Deterministic public grammar for compositional-held-out and open task programs.

Only the supplied grammar, split declaration, novelty axes, and seed affect generation.  The
generator has no policy, verdict, simulator, or hidden-result input by construction.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import random
from typing import Any, Mapping, Sequence

from chemrm.task_program import GoalStep, NOVELTY_AXES, SPLITS, TaskProgram


GENERATOR_ID = "paper-a-public-grammar"
GENERATOR_VERSION = "1"


def _canonical_hash(value: Mapping[str, Any]) -> str:
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(encoded).hexdigest()


@dataclass(frozen=True)
class GoalTemplate:
    name: str
    action: str
    parameters: Mapping[str, Any] = ()

    def __post_init__(self) -> None:
        if not self.name.strip() or not self.action.strip():
            raise ValueError("goal template name and action must be non-empty")
        object.__setattr__(self, "parameters", dict(self.parameters))

    def to_dict(self) -> dict[str, Any]:
        return {"name": self.name, "action": self.action, "parameters": dict(self.parameters)}


@dataclass(frozen=True)
class PublicGrammar:
    grammar_id: str
    environments: tuple[str, ...]
    object_roles: tuple[str, ...]
    goal_templates: tuple[GoalTemplate, ...]
    max_objects: int = 3

    def __post_init__(self) -> None:
        if not self.grammar_id.strip() or not self.environments or not self.object_roles:
            raise ValueError("grammar id, environments, and object roles are required")
        if not self.goal_templates:
            raise ValueError("grammar needs at least one goal template")
        if len({template.name for template in self.goal_templates}) != len(self.goal_templates):
            raise ValueError("goal template names must be unique")
        if int(self.max_objects) < 1:
            raise ValueError("max_objects must be positive")
        object.__setattr__(self, "environments", tuple(str(value) for value in self.environments))
        object.__setattr__(self, "object_roles", tuple(str(value) for value in self.object_roles))
        object.__setattr__(self, "goal_templates", tuple(self.goal_templates))
        object.__setattr__(self, "max_objects", int(self.max_objects))

    def to_dict(self) -> dict[str, Any]:
        return {
            "grammar_id": self.grammar_id,
            "environments": list(self.environments),
            "object_roles": list(self.object_roles),
            "goal_templates": [template.to_dict() for template in self.goal_templates],
            "max_objects": self.max_objects,
        }

    @property
    def sha256(self) -> str:
        return _canonical_hash(self.to_dict())

    @classmethod
    def from_dict(cls, data: Mapping[str, Any]) -> "PublicGrammar":
        templates = tuple(
            GoalTemplate(item["name"], item["action"], item.get("parameters", {}))
            for item in data["goal_templates"]
        )
        return cls(data["grammar_id"], tuple(data["environments"]), tuple(data["object_roles"]),
                   templates, data.get("max_objects", 3))


def _validate_request(grammar: PublicGrammar, split: str, axes: frozenset[str], count: int) -> None:
    if split not in SPLITS:
        raise ValueError(f"unknown split {split!r}; expected one of {sorted(SPLITS)}")
    bad = axes - NOVELTY_AXES
    if bad:
        raise ValueError(f"unknown novelty axes: {sorted(bad)}")
    if split == "closed" and axes:
        raise ValueError("closed generation cannot declare novelty axes")
    if split != "closed" and not axes:
        raise ValueError(f"{split} generation needs at least one novelty axis")
    if split == "compositional-held-out" and not axes & {"composition", "dependency", "topology"}:
        raise ValueError("compositional-held-out generation needs a composition, dependency, or topology axis")
    if int(count) <= 0:
        raise ValueError("count must be positive")
    if ("composition" in axes or "dependency" in axes or "topology" in axes) and len(grammar.goal_templates) < 2:
        raise ValueError("compositional axes need at least two goal templates")
    if "environment" in axes and len(grammar.environments) < 2:
        raise ValueError("environment axis needs at least two public environments")
    if "object" in axes and len(grammar.object_roles) < 2:
        raise ValueError("object axis needs at least two public object roles")
    if "goal" in axes and len(grammar.goal_templates) < 2:
        raise ValueError("goal axis needs at least two public goal templates")
    if "count" in axes and grammar.max_objects < 2:
        raise ValueError("count axis needs max_objects >= 2")


def _goal_steps(grammar: PublicGrammar, rng: random.Random, axes: frozenset[str]) -> tuple[GoalStep, ...]:
    needs_composition = bool(axes & {"composition", "dependency", "topology"})
    n = 3 if "topology" in axes else (2 if needs_composition else 1)
    indices = list(range(len(grammar.goal_templates)))
    if "goal" in axes:
        forced = len(indices) - 1
        rest = [index for index in indices if index != forced]
        chosen_indices = [forced] + rng.sample(rest, n - 1)
    else:
        chosen_indices = rng.sample(indices, n)
    chosen = [grammar.goal_templates[index] for index in chosen_indices]
    if n == 1:
        return (GoalStep("step_0", chosen[0].action, parameters=chosen[0].parameters),)
    steps = [GoalStep(f"step_{index}", template.action,
                      requires=() if index < 2 or "topology" not in axes else ("step_0", "step_1"),
                      parameters=template.parameters)
             for index, template in enumerate(chosen)]
    if "topology" not in axes:
        steps[1] = GoalStep(steps[1].id, steps[1].action, requires=(steps[0].id,),
                             parameters=steps[1].parameters)
    return tuple(steps)


def public_signature(task: TaskProgram) -> str:
    """Canonical semantic signature used to audit overlap across frozen splits."""
    data = {
        "environment": dict(task.environment),
        "objects": [dict(obj) for obj in task.objects],
        "counts": dict(task.counts),
        "goals": [goal.to_dict() for goal in task.goals],
    }
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def generate_public_tasks(grammar: PublicGrammar, *, split: str, count: int, seed: int,
                          novelty_axes: Sequence[str] = ()) -> tuple[TaskProgram, ...]:
    """Generate a deterministic public task family from a frozen grammar."""
    axes = frozenset(novelty_axes)
    _validate_request(grammar, split, axes, count)
    rng = random.Random(f"{GENERATOR_ID}:{GENERATOR_VERSION}:{grammar.sha256}:{split}:{seed}")
    tasks: list[TaskProgram] = []
    for index in range(int(count)):
        environment = grammar.environments[-1] if "environment" in axes else grammar.environments[0]
        n_objects = min(grammar.max_objects, 1 + (1 if "count" in axes else 0))
        if "object" in axes:
            roles = [grammar.object_roles[-1]]
            roles.extend(grammar.object_roles[rng.randrange(len(grammar.object_roles))]
                         for _ in range(n_objects - 1))
        else:
            roles = [grammar.object_roles[rng.randrange(len(grammar.object_roles))] for _ in range(n_objects)]
        objects = tuple({"id": f"{role}_{i}", "role": role} for i, role in enumerate(roles))
        goals = _goal_steps(grammar, rng, axes)
        task_id = f"{grammar.grammar_id}:{split}:{int(seed)}:{index:04d}"
        tasks.append(TaskProgram(
            task_id=task_id,
            split=split,
            environment={"kind": environment, "grammar_id": grammar.grammar_id},
            objects=objects,
            counts={"object": n_objects},
            goals=goals,
            seed=int(seed) + index,
            novelty_axes=axes,
            public_spec_version=f"{GENERATOR_ID}-{GENERATOR_VERSION}",
            metadata={
                "generator_id": GENERATOR_ID,
                "generator_version": GENERATOR_VERSION,
                "grammar_sha256": grammar.sha256,
                "generation_index": index,
                "declared_axes": sorted(axes),
            },
        ))
    return tuple(tasks)
