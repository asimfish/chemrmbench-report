"""Run the YAML C5/C6/C13 F0 controlled-world smoke cases."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from chemrm.papera.runner import run_episode
from chemrm.papera.task_worlds import make_task_case


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--task", choices=("C5", "C6", "C13", "all"), default="all")
    ap.add_argument("--out", required=True, help="evidence directory (one child per task when --task all)")
    ap.add_argument("--seed", type=int, default=19)
    ap.add_argument("--max-steps", type=int, default=1000)
    args = ap.parse_args(argv)
    names = ("C5", "C6", "C13") if args.task == "all" else (args.task,)
    root = Path(args.out)
    results = {}
    for name in names:
        case = make_task_case(name, seed=args.seed)
        out = root / name if len(names) > 1 else root
        result = run_episode(case.task, case.world, case.policy, case.verifier(), seed=args.seed,
                             max_steps=args.max_steps, out_dir=out)
        results[name] = {"bundle": str(out), "pass_vector": dict(result.verdict.pass_vector),
                         "failure_vector": list(result.verdict.failure_vector)}
    print(json.dumps(results, indent=2, sort_keys=True))
    return 0 if all(row["pass_vector"].get("chem_ssr", False) for row in results.values()) else 1


if __name__ == "__main__":
    raise SystemExit(main())

