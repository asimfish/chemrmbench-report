"""Public-only file bridge from a paused native worker to its local model client.

The native namespace never needs a writable credential directory. Two declared
readouts are served at most once; incomplete or uncertain calls are not retried.
"""
import hashlib
import json
from pathlib import Path
import time

from .agent_memory_v81 import validate_packet
from .staged_collection import digest, write_once


def _hash(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def request(directory, observation, image, *, mode, memory=None,
            memory_sha256=None, nominal_contact_latency_s=None, timeout_s=95,
            progress=None):
    """Supervisor owns the model call; optional caller advances native physics."""
    import shutil
    observation = validate_packet(observation)
    if progress is not None and not callable(progress):
        raise ValueError('native progress callback must be callable')
    directory = Path(directory)
    if mode != 'READOUT' or observation['packet']['phase'] != 'RESUME':
        raise ValueError('bridge accepts resumed readouts only')
    if directory.name not in ('retained', 'cleared') or directory.parent.name != 'agent_requests':
        raise ValueError('unregistered model request')
    image = Path(image)
    if image.suffix.lower() != '.jpg' or digest(image) != observation['packet']['observation']['actor']['images'][0]['sha256']:
        raise ValueError('actual image differs from public packet')
    channel = directory.parent.parent / 'bridge_requests' / directory.name
    channel.mkdir(parents=True, exist_ok=False)
    shutil.copyfile(image, channel / 'observation.jpg')
    body = dict(mode=mode, public_observation=observation, memory=memory,
                memory_sha256=memory_sha256, nominal_contact_latency_s=nominal_contact_latency_s)
    write_once(channel / 'request.json', body)
    write_once(channel / 'REQUEST_COMMITTED.json', dict(request_sha256=_hash(body)))
    started = time.monotonic()
    while time.monotonic() - started < timeout_s:
        if (channel / 'RESPONSE_COMMITTED.json').exists():
            return read_response(channel, _hash(body))
        if (channel / 'ERROR.json').exists():
            raise RuntimeError('local model bridge failed; no retry')
        if progress is None:time.sleep(.1)
        else:progress()
    raise TimeoutError('uncertain local model request; no retry')


def read_request(channel):
    channel = Path(channel)
    body = json.loads((channel / 'request.json').read_text())
    commit = json.loads((channel / 'REQUEST_COMMITTED.json').read_text())
    if _hash(body) != commit['request_sha256']:
        raise ValueError('request digest changed')
    if set(body) != {'mode','public_observation','memory','memory_sha256','nominal_contact_latency_s'}:
        raise ValueError('request fields outside public contract')
    observation = validate_packet(body['public_observation'])
    if body['mode'] != 'READOUT' or observation['packet']['phase'] != 'RESUME':
        raise ValueError('non-readout bridge request')
    if digest(channel / 'observation.jpg') != observation['packet']['observation']['actor']['images'][0]['sha256']:
        raise ValueError('bridge image digest changed')
    if channel.name == 'cleared' and (body['memory'] is not None or body['memory_sha256'] is not None):
        raise ValueError('cleared request leaked retained memory')
    if channel.name not in ('retained','cleared'):
        raise ValueError('unregistered channel')
    return body, commit['request_sha256']


def read_response(channel, request_sha256):
    channel = Path(channel)
    body = json.loads((channel / 'response.json').read_text())
    commit = json.loads((channel / 'RESPONSE_COMMITTED.json').read_text())
    if commit['request_sha256'] != request_sha256 or commit['response_sha256'] != _hash(body):
        raise ValueError('stale or modified model response')
    return body


def serve_ready(root, *, invoke):
    """Serve one pending declared request; started marker fences uncertain retries."""
    root = Path(root)
    for condition in ('retained','cleared'):
        channel = root / 'bridge_requests' / condition
        if not (channel / 'REQUEST_COMMITTED.json').exists() or (channel / 'STARTED.json').exists():
            continue
        body, request_sha = read_request(channel)
        write_once(channel / 'STARTED.json', dict(request_sha256=request_sha,automatic_retry=False))
        try:
            answer = invoke(root / 'agent_requests' / condition, body['public_observation'],
                channel / 'observation.jpg', mode='READOUT', memory=body['memory'],
                memory_sha256=body['memory_sha256'],
                nominal_contact_latency_s=body['nominal_contact_latency_s'])
            write_once(channel / 'response.json', answer)
            write_once(channel / 'RESPONSE_COMMITTED.json', dict(
                request_sha256=request_sha,response_sha256=_hash(answer)))
        except BaseException as error:
            write_once(channel / 'ERROR.json', dict(type=type(error).__name__,
                message='bounded model client failed; see owned request evidence',automatic_retry=False))
            raise
        return condition
    return None
