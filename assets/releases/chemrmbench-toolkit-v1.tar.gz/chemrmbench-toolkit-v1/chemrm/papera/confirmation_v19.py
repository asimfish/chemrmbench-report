"""New prospective scene confirmation; V18 results and provider stay sealed."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from chemrm.papera.clock_repair_v17 import build_bank as v17_bank
from chemrm.papera.strong_probe_v18 import build_bank as v18_bank
from chemrm.papera.native_leakage import build_bank as v16_bank, SCHEMA, AGES
from chemrm.papera.isaac_bridge_contract import Case
from chemrm.papera.isaac_bridge_verify import sha256

REVISION='papera-settled-confirmation-v19'
SETTLING_RENDERS=64
IDENTITY_MARGIN=.02
N_FUTURE_SCENES=120


def build_bank():
    geometry,timing,order=(np.random.default_rng(s) for s in (191019,291019,391019))
    scenes=[];cases=[];prior=v17_bank()
    for i in (0,5,16,21):
        scene=dict(prior['scenes'][i],scene_id=f'v19_dev_{i:03d}',split='dev')
        scenes.append(scene)
        for target in order.permutation(5).tolist():
            c=Case(case_id=f"{scene['scene_id']}_t{target}",family='C13',split='dev',seed=171008+i,
                   target=target,onset_s=scene['onset_s'],wait_s=60.,eta=.15,latency_s=0.,scene_x=scene['scene_x'],
                   spacing=scene['spacing'],camera_height=scene['camera_height'],equivalence_ml=10.)
            cases.append(dict(scene_id=scene['scene_id'],split='dev',case=c.to_dict()))
    for i in range(N_FUTURE_SCENES):
        scene=dict(scene_id=f'v19_future_{i:03d}',split='future',scene_x=float(geometry.uniform(.4,.55)),
                   spacing=float(geometry.uniform(.12,.18)),camera_height=float(geometry.uniform(1.5,2.1)),
                   onset_s=float(timing.integers(300,2401))/60.)
        scenes.append(scene)
        for target in order.permutation(5).tolist():
            c=Case(case_id=f"{scene['scene_id']}_t{target}",family='C13',split='future',seed=191019+i,
                   target=target,onset_s=scene['onset_s'],wait_s=60.,eta=.15,latency_s=0.,scene_x=scene['scene_x'],
                   spacing=scene['spacing'],camera_height=scene['camera_height'],equivalence_ml=10.)
            cases.append(dict(scene_id=scene['scene_id'],split='future',case=c.to_dict()))
    return dict(schema=SCHEMA,revision=REVISION,scenes=scenes,cases=cases,ages_s=AGES,fixed_query_s=110.,
                capture_settling_extra_calls=SETTLING_RENDERS,paused_control_all_targets=True,
                scene_bootstrap_draws=20000,identity_margin=IDENTITY_MARGIN,
                identity_family_size=7,clock_family_size=6,family_alpha=.05,
                renderer=v18_bank()['renderer'],scope='PROSPECTIVE_FINITE_C13_CONFIRMATION')


def validate_bank(bank):
    if bank!=build_bank():raise ValueError('V19 confirmation bank changed')
    key=lambda s:tuple(s[k] for k in ['scene_x','spacing','camera_height','onset_s'])
    seen={key(s) for b in [v16_bank(),v17_bank(),v18_bank()] for s in b['scenes']}
    future=[key(s) for s in bank['scenes'] if s['split']=='future']
    if len(set(future))!=N_FUTURE_SCENES or seen.intersection(future):raise ValueError('future scene tuple is not novel')


def verify_model_seal(models,freeze_path):
    r=json.loads((models/'fit_receipt.json').read_text());root=Path(__file__).resolve().parents[2]
    if r['revision']!=REVISION or r['freeze_sha256']!=sha256(freeze_path) or r['new_future_observations_read'] is not False:
        raise ValueError('invalid new confirmation seal')
    for name,digest in r['files'].items():
        path=Path(name)
        if path.is_absolute() or '..' in path.parts or sha256(root/path)!=digest:
            raise ValueError('sealed confirmation model changed')
    if len(r['files'])!=29:raise ValueError('incomplete historical/expanded model closure')
    return sha256(models/'fit_receipt.json')
