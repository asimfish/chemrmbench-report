"""V19 prospective collector with fixed native settling and all-identity controls."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time
import traceback

from chemrm.papera.native_leakage import dump, SCHEMA
from chemrm.papera.confirmation_v19 import (
    validate_bank, REVISION, verify_model_seal,
)
from chemrm.papera.clock_repair_v17 import (
    PAUSED_RENDERS, check_paused_invariants,
)
from chemrm.papera.isaac_bridge_contract import Case
from chemrm.papera.isaac_bridge_verify import sha256


def verify_freeze(bank_path, freeze_path):
    freeze = json.loads(freeze_path.read_text())
    if sha256(bank_path) != freeze['bank_sha256']:
        raise ValueError('bank changed after preregistration')
    root = Path(__file__).resolve().parents[2]
    for name, digest in freeze['sources'].items():
        if sha256(root / name) != digest:
            raise ValueError(f'frozen source differs: {name}')
    return freeze


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bank', type=Path, required=True)
    parser.add_argument('--freeze', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--asset', type=Path, required=True)
    parser.add_argument('--splits', nargs='+', choices=['dev', 'future'], required=True)
    parser.add_argument('--gpu', type=int, default=0)
    parser.add_argument('--models', type=Path)
    args = parser.parse_args()
    freeze = verify_freeze(args.bank, args.freeze)
    bank = json.loads(args.bank.read_text())
    validate_bank(bank)
    cases = [r for r in bank['cases'] if r['split'] in args.splits]
    seal = verify_model_seal(args.models, args.freeze) if args.models is not None else None
    if 'future' in args.splits:
        if args.splits != ['future'] or args.models is None:
            raise ValueError('future-only collection requires frozen model path')
        seal = verify_model_seal(args.models, args.freeze)
    args.out.mkdir(parents=True, exist_ok=False)
    dump(args.out / 'start.json', {'schema': SCHEMA, 'splits': args.splits,
         'revision': REVISION, 'started_at_utc': datetime.now(timezone.utc).isoformat(),
         'expected_cases': len(cases), 'freeze_sha256': sha256(args.freeze),
         'fit_receipt_sha256': seal,
         'sources': freeze['sources'], 'asset_sha256': sha256(args.asset)})
    sys.argv = [sys.argv[0]]
    from isaacsim import SimulationApp
    app = SimulationApp({'headless': True, 'active_gpu': args.gpu, 'physics_gpu': args.gpu,
                         'multi_gpu': False, 'width': 320, 'height': 320,
                         'renderer': 'RayTracedLighting'})
    failed = False
    try:
        import numpy as np
        from PIL import Image
        from chemrm.papera.settled_capture_v19 import SettledCaptureV19
        from chemrm.papera.fixed_light_features import fixed_light_features as visual_features
        backend = SettledCaptureV19(str(args.asset))
        receipts = []
        paused_pairs = 0
        for row in cases:
            started = time.perf_counter()
            case = Case(**row['case'])
            folder = args.out / case.case_id
            folder.mkdir()
            backend.reset(case)
            observations = []
            queries = [('before', case.onset_s - 1.), ('cue', case.onset_s + 1.)]
            queries += [(f'age_{int(age)}', case.onset_s + age) for age in bank['ages_s']]
            queries += [('fixed_time', bank['fixed_query_s'])]
            for phase, query in queries:
                remaining = query - backend.now
                if remaining < -.02:
                    raise ValueError('nonmonotone capture schedule')
                backend.advance(max(0., remaining))
                snap = backend.capture()
                filename = f'{phase}.png'
                Image.fromarray(snap.rgb).save(folder / filename)
                observations.append({'phase': phase, 'file': filename,
                     'sha256': sha256(folder / filename), 'captured_at': snap.captured_at,
                     'rendered_at': snap.rendered_at, 'joints': snap.joints.tolist(),
                     'detector': visual_features(snap.rgb)})
            control = None
            if case.target in range(5):
                samples = []
                for calls in (0, PAUSED_RENDERS):
                    if calls:
                        for _ in range(calls):
                            backend.world.render()
                    backend.check_settings()
                    rgb = np.asarray(backend.camera.get_rgba())[:, :, :3].copy()
                    filename = f'paused_{calls}.png'
                    Image.fromarray(rgb).save(folder / filename)
                    samples.append({'extra_render_calls': calls, 'file': filename,
                        'sha256': sha256(folder / filename), 'physical_time': backend.now,
                        'joints': backend.robot.get_joint_positions().tolist(),
                        'events_sha256': hashlib.sha256(json.dumps(backend.events, sort_keys=True).encode()).hexdigest()})
                control = {'samples': samples}
                check_paused_invariants(control)
                paused_pairs += 1
            dump(folder / 'audit.json', {**row, 'revision': REVISION,
                 'paused_control': control, 'events': backend.events,
                 'observations': observations, 'wall_seconds': time.perf_counter() - started})
            receipts.append({'case_id': case.case_id, 'audit_sha256': sha256(folder / 'audit.json')})
            print(f"CASE_DONE {len(receipts)}/{len(cases)} {case.case_id} "
                  f"{time.perf_counter()-started:.2f}s", flush=True)
        verify_freeze(args.bank, args.freeze)
        dump(args.out / 'manifest.json', {'schema': SCHEMA, 'status': 'COMPLETE',
             'revision': REVISION, 'splits': args.splits, 'freeze_sha256': sha256(args.freeze),
             'cases': receipts, 'frame_count': 7 * len(receipts),
             'paused_pair_count': paused_pairs, 'additional_frame_count': 2 * paused_pairs,
             'start_sha256': sha256(args.out / 'start.json')})
        print('NATIVE_V19_CONFIRMATION_COMPLETE', flush=True)
    except Exception:
        failed = True
        traceback.print_exc()
        dump(args.out / 'error.json', {'traceback': traceback.format_exc()})
        sys.stdout.flush()
        sys.stderr.flush()
    finally:
        app.close()
    if failed:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
