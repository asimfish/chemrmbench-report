"""Acquire paired original/wider FOV observations on four already-seen scenes."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import json
import math
from pathlib import Path
import sys
import traceback
from chemrm.papera.camera_coverage_v20 import validate_bank, REVISION
from chemrm.papera.isaac_bridge_contract import Case
from chemrm.papera.isaac_bridge_verify import sha256


def dump(path, data):
    path.write_text(json.dumps(data, sort_keys=True, indent=2, allow_nan=False) + '\n')


def verify(root, bank_path, freeze_path, asset_root):
    freeze = json.loads(freeze_path.read_text())
    if sha256(bank_path) != freeze['bank_sha256']:
        raise ValueError('development bank changed')
    for name, wanted in freeze['sources'].items():
        if sha256(root / name) != wanted:
            raise ValueError(f'development source changed: {name}')
    for name, wanted in freeze['asset_dependencies'].items():
        if sha256(asset_root / name) != wanted:
            raise ValueError(f'licensed asset changed: {name}')
    return freeze


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bank', type=Path, required=True)
    parser.add_argument('--freeze', type=Path, required=True)
    parser.add_argument('--asset-root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--gpu', type=int, default=0)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    freeze = verify(root, args.bank, args.freeze, args.asset_root)
    bank = json.loads(args.bank.read_text()); validate_bank(bank)
    args.out.mkdir(parents=True, exist_ok=False)
    dump(args.out / 'start.json', {'revision': REVISION, 'scope': bank['scope'],
        'started_at_utc': datetime.now(timezone.utc).isoformat(),
        'freeze_sha256': sha256(args.freeze), 'expected_cases': 40,
        'expected_images': 120, 'future_scenes': 0, 'sources': freeze['sources'],
        'gpu': args.gpu, 'no_training_or_policy_evaluation': True})
    sys.argv = [sys.argv[0]]
    from isaacsim import SimulationApp
    app = SimulationApp({'headless': True, 'active_gpu': args.gpu,
        'physics_gpu': args.gpu, 'multi_gpu': False, 'width': 320,
        'height': 320, 'renderer': 'RayTracedLighting'})
    failed = False
    try:
        from PIL import Image
        from chemrm.papera.settled_capture_v19 import SettledCaptureV19
        from chemrm.papera.fixed_light_features import fixed_light_features

        class CameraDevelopment(SettledCaptureV19):
            def __init__(self, asset):
                super().__init__(asset)
                self.original_focal = float(self.camera.get_focal_length())
                if not math.isfinite(self.original_focal) or self.original_focal <= 0:
                    raise ValueError('invalid native focal length')
                self.multiplier = 1.

            def select_arm(self, multiplier):
                self.multiplier = multiplier
                self.camera.set_focal_length(self.original_focal * multiplier)

            def check_settings(self):
                actual = super().check_settings()
                if not math.isclose(float(self.camera.get_focal_length()),
                                    self.original_focal * self.multiplier, rel_tol=1e-6):
                    raise RuntimeError('native focal setting differs')
                return actual

            def reset(self, case):
                super().reset(case)
                self.events[0].update(camera_development_revision=REVISION,
                    focal_multiplier=self.multiplier, focal_length=float(self.camera.get_focal_length()),
                    original_focal_length=self.original_focal,
                    horizontal_aperture=float(self.camera.get_horizontal_aperture()),
                    vertical_aperture=float(self.camera.get_vertical_aperture()))

        backend = CameraDevelopment(str(args.asset_root / 'franka.usd'))
        receipts = []
        for i, row in enumerate(bank['cases']):
            if i == 20:
                verify(root, args.bank, args.freeze, args.asset_root)
            case = Case(**row['case']); folder = args.out / case.case_id; folder.mkdir()
            backend.select_arm(row['focal_multiplier']); backend.reset(case)
            observations = []
            for phase, query in [('before', case.onset_s - 1.), ('cue', case.onset_s + 1.), ('age_4', case.onset_s + 4.)]:
                remaining = query - backend.now
                if remaining < -.02:
                    raise ValueError('capture schedule went backwards')
                backend.advance(max(0., remaining)); snapshot = backend.capture()
                name = phase + '.png'; Image.fromarray(snapshot.rgb).save(folder / name)
                observations.append({'phase': phase, 'file': name,
                    'sha256': sha256(folder / name), 'captured_at': snapshot.captured_at,
                    'rendered_at': snapshot.rendered_at, 'joints': snapshot.joints.tolist(),
                    'detector': fixed_light_features(snapshot.rgb)})
            dump(folder / 'audit.json', {**row, 'revision': REVISION, 'scope': bank['scope'],
                'events': backend.events, 'observations': observations})
            receipts.append({'case_id': case.case_id, 'audit_sha256': sha256(folder / 'audit.json')})
            print(f'CAMERA_CASE_DONE {i+1}/40 {case.case_id}', flush=True)
        verify(root, args.bank, args.freeze, args.asset_root)
        dump(args.out / 'manifest.json', {'status': 'COMPLETE', 'revision': REVISION,
            'scope': bank['scope'], 'future_scenes': 0, 'freeze_sha256': sha256(args.freeze),
            'start_sha256': sha256(args.out / 'start.json'), 'cases': receipts, 'images': 120})
        print('CAMERA_SEEN_DEVELOPMENT_COMPLETE', flush=True)
    except Exception:
        failed = True
        traceback.print_exc(); dump(args.out / 'error.json', {'traceback': traceback.format_exc()})
    finally:
        app.close()
    if failed:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
