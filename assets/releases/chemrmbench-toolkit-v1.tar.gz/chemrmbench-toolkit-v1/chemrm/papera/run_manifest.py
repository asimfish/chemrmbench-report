"""Freeze a declaration-only Paper A task registry into a verified manifest."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from chemrm.papera.manifest import (
    TaskRegistration,
    load_registered_tasks,
    verify_task_manifest,
    write_task_manifest,
)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("--registry", required=True, help="JSON array of public task registrations")
    parser.add_argument("--out", required=True, help="directory for manifest.json and tasks.jsonl")
    parser.add_argument("--manifest-id", required=True)
    args = parser.parse_args(argv)
    registry_path = Path(args.registry)
    declarations = json.loads(registry_path.read_text(encoding="utf-8"))
    if not isinstance(declarations, list):
        raise ValueError("registry JSON must be an array")
    registrations = tuple(
        TaskRegistration(
            task_id=item["task_id"],
            source=item["source"],
            split=item.get("split", "closed"),
            seed=item.get("seed", 0),
            novelty_axes=frozenset(item.get("novelty_axes", ())),
        )
        for item in declarations
    )
    tasks = load_registered_tasks(registrations, base_dir=registry_path.parent)
    out = write_task_manifest(tasks, args.out, manifest_id=args.manifest_id)
    ok, errors = verify_task_manifest(out)
    print(json.dumps({"manifest": str(out), "task_count": len(tasks), "ok": ok, "errors": errors},
                     ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
