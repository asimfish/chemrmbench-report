"""Concrete Paper A F0 backend for the paired memory/time core family.

This backend reuses the Gate 0 episode generator and observation contract while running one
episode through the generic Paper A harness.  It is deliberately deterministic and low fidelity:
the scripted move-and-pour skill is the execution substitution, and the independent verifier reads
only the event trace.  A later Isaac/pixel backend can keep the same task and verifier semantics.
"""

from __future__ import annotations

from typing import Any, Mapping

from chemrm.constraints import Violation
from chemrm.events import EventBus
from chemrm.gate0.env import (
    DT,
    N_STEPS,
    STRATA,
    T_POUR,
    build_observations,
    cell_arrays,
    draw_episode_batch,
    make_tick_times,
    parse_stratum,
    skill_time,
)
from chemrm.papera.contract import EpisodeVerdict, Trace
from chemrm.papera.runner import ReadOnlyConstraintVerifier, WorldStep
from chemrm.quality import assemble_pass_vector
from chemrm.task_program import GoalStep, TaskProgram


def make_core_task(stratum: str = "M1_tight_0.15", mask: str = "none", *,
                   clock_on: bool = False, split: str = "closed", seed: int = 0) -> TaskProgram:
    """Build the public task program for one paired core-family cell."""
    if stratum not in STRATA:
        raise ValueError(f"unknown stratum {stratum!r}")
    if mask not in ("none", "identity", "timing", "both"):
        raise ValueError(f"unknown oracle mask {mask!r}")
    return TaskProgram(
        task_id=f"core-f0:{stratum}:{mask}:clock={int(clock_on)}",
        split=split,
        environment={"kind": "chemrm.core_family.f0", "dt_s": DT, "horizon_steps": N_STEPS},
        objects=tuple({"id": f"flask_{i}", "role": "candidate"} for i in range(5)),
        counts={"flask": 5},
        goals=(
            GoalStep("A", "add_reagent", parameters={"reagent": "A"}),
            GoalStep("B", "add_reagent", requires=("A",), parameters={"reagent": "B"}),
        ),
        seed=int(seed),
        metadata={"backend": "core_f0", "stratum": stratum, "mask": mask, "clock_on": bool(clock_on)},
    )


class CoreFamilyWorld:
    """One Gate 0 episode behind the Paper A controlled-world protocol."""

    def __init__(self, stratum: str = "M1_tight_0.15", mask: str = "none", *,
                 clock_on: bool = False, perturbation: str = "none", perturbation_level: float = 0.0):
        if stratum not in STRATA:
            raise ValueError(f"unknown stratum {stratum!r}")
        if mask not in ("none", "identity", "timing", "both"):
            raise ValueError(f"unknown oracle mask {mask!r}")
        self.stratum = stratum
        self.mask = mask
        self.clock_on = bool(clock_on)
        self.perturbation = perturbation
        self.perturbation_level = float(perturbation_level)
        self.clock = None
        self.event_bus = None

    def reset(self, task: TaskProgram, seed: int) -> Mapping[str, Any]:
        from chemrm.events import SimClock

        self.clock = SimClock()
        self.event_bus = EventBus(self.clock)
        self.eps = draw_episode_batch(1, seed)
        self.ticks = make_tick_times(1, N_STEPS, self.perturbation, self.perturbation_level,
                                     seed=seed + 777_000)[0]
        transient, tight, _eta, id_on, tm_on = cell_arrays(1, self.stratum, self.mask)
        self.observations = build_observations(self.eps, transient, tight, id_on, tm_on,
                                               self.clock_on, tick_times=self.ticks[None, :])[0]
        self.step_index = 0
        self.a_emitted = False
        self.b_emitted = False
        self.clock._t = float(self.ticks[0])
        return self._observation()

    def _observation(self) -> Mapping[str, Any]:
        # The runner records step/time beside the observation for audit only.  They must not cross
        # this boundary: exposing either field would give Track A an undeclared clock.
        return {"features": self.observations[self.step_index].astype(float).tolist()}

    def _emit_at(self, t: float, kind: str, **payload: Any) -> None:
        old = self.clock.now
        self.clock._t = float(t)
        self.event_bus.emit(kind, **payload)
        self.clock._t = old

    def _emit_due(self, t: float) -> None:
        t_a = float(self.eps.t_a[0])
        flask = int(self.eps.flask[0])
        if not self.a_emitted and t >= t_a:
            self._emit_at(t_a, "add_reagent", reagent="A", flask=flask, wait_s=float(self.eps.d[0]))
            self.a_emitted = True

    def step(self, action: Mapping[str, Any]) -> WorldStep:
        now = float(self.clock.now)
        self._emit_due(now)
        kind = action.get("kind", "wait")
        if kind == "add_reagent":
            if action.get("reagent", "B") != "B":
                raise ValueError("core F0 policy may only add reagent B")
            flask = int(action["flask"])
            if not 0 <= flask < 5:
                raise ValueError(f"flask index out of range: {flask}")
            landing = now + skill_time(flask)
            self.clock._t = landing
            self._emit_due(landing)
            self.event_bus.emit("add_reagent", reagent="B", flask=flask, skill_time=skill_time(flask))
            self.b_emitted = True
            return WorldStep(self._observation(), True, "add_reagent")
        if kind != "wait":
            raise ValueError(f"unknown core F0 action {kind!r}")
        if self.step_index + 1 >= len(self.ticks):
            return WorldStep(self._observation(), True, "horizon")
        self.step_index += 1
        self.clock._t = float(self.ticks[self.step_index])
        self._emit_due(self.clock.now)
        return WorldStep(self._observation(), False, "")


class CoreFamilyVerifier(ReadOnlyConstraintVerifier):
    """Independent core-family referee using only the replayed A/B event facts."""

    verifier_id = "paper-a-core-f0-verifier-0.1"

    def __init__(self):
        super().__init__(constraints=())

    def verify(self, task: TaskProgram, trace: Trace) -> EpisodeVerdict:
        trace.validate()
        bus = EventBus.replay(list(trace.events))
        failures: list[Violation] = []
        if trace.error:
            failures.append(Violation("runner", "instrumentation_invalid", trace.error, trace.end_time))
        if not trace.completed:
            failures.append(Violation("runner", "incomplete", trace.stop_reason or "episode did not terminate",
                                       trace.end_time))
        a = bus.first("add_reagent", reagent="A")
        b = bus.first("add_reagent", reagent="B")
        if a is None:
            failures.append(Violation("core_protocol", "incomplete", "reagent A was never added", trace.end_time))
        if b is None:
            failures.append(Violation("core_protocol", "incomplete", "reagent B was never added", trace.end_time))
        if a is not None and b is not None:
            if b.payload.get("flask") != a.payload.get("flask"):
                failures.append(Violation("core_protocol", "contamination", "B was added to the wrong flask", b.t))
                failures.append(Violation("core_safety", "smoke", "wrong flask triggers the surrogate hazard", b.t))
            if b.t < a.t + T_POUR:
                failures.append(Violation("core_time", "premature", "B landed before the A pour ended", b.t))
                failures.append(Violation("core_safety", "smoke", "overlapping pours trigger the surrogate hazard", b.t))
            wait = float(a.payload.get("wait_s", 0.0))
            _transient, _tight, eta = parse_stratum(task.metadata.get("stratum", "M1_tight_0.15"))
            if eta is not None:
                delta = b.t - (a.t + wait)
                if abs(delta) > eta * wait:
                    failures.append(Violation("core_time", "premature" if delta < 0 else "late",
                                               f"B timing error {delta:.3f}s exceeds {eta:.3f}D", b.t))
        goal_reached = self._goal_reached(bus, task.goals)
        pv = assemble_pass_vector(goal_reached, failures)
        metrics = {"goal_reached": bool(goal_reached), "n_steps": len(trace.actions),
                   "end_time_s": float(trace.end_time), "n_events": len(trace.events)}
        if a is not None:
            metrics.update({"t_a_s": float(a.t), "flask_a": int(a.payload["flask"])})
        if b is not None:
            metrics.update({"t_b_s": float(b.t), "flask_b": int(b.payload["flask"])})
        return EpisodeVerdict(self.verifier_id, {
            "valid": pv.valid, "goal": pv.goal, "protocol": pv.protocol,
            "quantity": pv.quantity, "time": pv.time, "safety": pv.safety,
            "chem_ssr": pv.chem_ssr,
        }, tuple({"constraint": v.constraint, "kind": v.kind, "detail": v.detail, "t": v.t}
                 for v in failures), metrics)


class FeaturePolicy:
    """Small deterministic reference policy for smoke tests and evidence examples."""

    policy_id = "core-f0-feature-reference"
    policy_hash = "sha256:core-f0-feature-reference-v1"

    def __init__(self, flask: int, action_step: int):
        self.flask = int(flask)
        self.action_step = int(action_step)

    def reset(self, _task: TaskProgram, _seed: int) -> None:
        self.calls = 0

    def act(self, observation: Mapping[str, Any]) -> Mapping[str, Any]:
        if self.calls == self.action_step:
            self.calls += 1
            return {"kind": "add_reagent", "reagent": "B", "flask": self.flask}
        self.calls += 1
        return {"kind": "wait"}


class DyeReferencePolicy:
    """A non-privileged M0 relaxed reference that uses only persistent dye and cue absence."""

    policy_id = "core-f0-dye-reference"
    policy_hash = "sha256:core-f0-dye-reference-v1"

    def reset(self, _task: TaskProgram, _seed: int) -> None:
        pass

    def act(self, observation: Mapping[str, Any]) -> Mapping[str, Any]:
        features = observation["features"]
        dye = features[:5]
        poured = features[5:10]
        if max(dye) > 0.5 and max(poured) == 0:
            return {"kind": "add_reagent", "reagent": "B", "flask": int(dye.index(max(dye)))}
        return {"kind": "wait"}
