"""Execute a frozen thermal-dose diagnostic and retain success/failure evidence."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from chemrm.papera.runner import run_episode
from chemrm.papera.thermal_dose import (
    ThermalDosePolicy, ThermalDoseVerifier, ThermalDoseWorld, make_thermal_dose_task,
)
from chemrm.task_program import TaskProgram


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--task", help="frozen task.json; omitted to use the synthetic diagnostic")
    parser.add_argument("--seed", type=int, help="default task seed; must match --task if both are supplied")
    parser.add_argument("--rate", type=float, default=0.2, help="constant addition rate in mL/s")
    parser.add_argument("--dose-fraction", type=float, default=1.0, help="declared incorrect-dose control")
    parser.add_argument("--max-steps", type=int, default=1000)
    parser.add_argument("--out", required=True, help="evidence bundle directory")
    args = parser.parse_args(argv)
    if args.task:
        task = TaskProgram.from_dict(json.loads(Path(args.task).read_text(encoding="utf-8")))
        if args.seed is not None and args.seed != task.seed:
            parser.error("--seed must match the frozen task seed")
    else:
        task = make_thermal_dose_task(seed=args.seed if args.seed is not None else 19)
    result = run_episode(task, ThermalDoseWorld(), ThermalDosePolicy(args.rate, args.dose_fraction),
                         ThermalDoseVerifier(task), seed=task.seed, max_steps=args.max_steps, out_dir=args.out)
    print(json.dumps({"task_id": task.task_id, "bundle": str(Path(args.out)),
                      "pass_vector": dict(result.verdict.pass_vector),
                      "failure_vector": list(result.verdict.failure_vector),
                      "metrics": dict(result.verdict.metrics)}, ensure_ascii=False, sort_keys=True, indent=2))
    return 0 if result.verdict.pass_vector["chem_ssr"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
