"""Minimal controlled world for executing generated public goal programs.

This backend deliberately models only the public goal graph. It is an execution contract smoke
test for generated task manifests; it is not a chemistry or Isaac simulator.
"""

from __future__ import annotations

from typing import Any, Mapping

from chemrm.events import EventBus, SimClock
from chemrm.papera.runner import FrozenPolicy, ReadOnlyConstraintVerifier, WorldStep
from chemrm.papera.semantics import SemanticEventCheck, SemanticGrammar, TASK_VERSION, validate_semantic_task
from chemrm.task_program import GoalStep, TaskProgram


class GeneratedGoalWorld:
    """Execute ready public goal nodes and record semantic events on the referee clock."""

    def __init__(self, dt: float = 1.0, horizon: float = 120.0,
                 semantic_grammar: SemanticGrammar | None = None):
        self.dt = float(dt)
        self.horizon = float(horizon)
        self.clock = SimClock()
        self.event_bus = EventBus(self.clock)
        self.semantic_grammar = semantic_grammar

    def reset(self, task: TaskProgram, _seed: int) -> Mapping[str, Any]:
        self.primitives = {}
        self.facts: set[str] = set()
        if task.public_spec_version == TASK_VERSION:
            if self.semantic_grammar is None:
                raise ValueError("v2 execution requires the bound semantic grammar")
            program = validate_semantic_task(task, self.semantic_grammar)
            self.primitives = {node.id: self.semantic_grammar.primitive_map[node.primitive] for node in program.nodes}
            self.facts = set(self.semantic_grammar.initial_facts)
        self.clock.reset()
        self.event_bus = EventBus(self.clock)
        self.task = task
        self.completed: set[str] = set()
        self.done = False
        return self._observation()

    def _ready(self) -> tuple[GoalStep, ...]:
        return tuple(goal for goal in self.task.goals
                     if goal.id not in self.completed and set(goal.requires) <= self.completed)

    def _observation(self) -> Mapping[str, Any]:
        return {
            "instruction": "execute_public_goal_program",
            "ready_goal_ids": [goal.id for goal in self._ready()],
        }

    def step(self, action: Mapping[str, Any]) -> WorldStep:
        if self.done:
            return WorldStep(self._observation(), True, "goal_program")
        ready = self._ready()
        kind = action.get("kind")
        params = {key: value for key, value in action.items() if key != "kind"}
        goal = next((candidate for candidate in ready
                     if candidate.action == kind and dict(candidate.parameters) == params), None)
        if goal is None:
            raise ValueError(f"action does not match a ready public goal: {action!r}")
        if self.primitives:
            primitive = self.primitives[goal.id]
            if not set(primitive.preconditions) <= self.facts:
                raise ValueError("primitive precondition not satisfied")
            self.facts.difference_update(primitive.delete)
            self.facts.update(primitive.add)
        self.event_bus.emit(goal.action, goal_id=goal.id, **params)
        self.completed.add(goal.id)
        self.done = len(self.completed) == len(self.task.goals)
        if not self.done:
            self.clock.step(self.dt)
            if self.clock.now >= self.horizon:
                return WorldStep(self._observation(), True, "horizon")
        return WorldStep(self._observation(), self.done, "goal_program" if self.done else "")


class GeneratedGoalPolicy:
    """Declared reference policy that follows the public dependency graph."""

    policy_id = "paper-a-generated-goal-reference"
    policy_hash = "sha256:paper-a-generated-goal-reference-v1"

    def reset(self, task: TaskProgram, _seed: int) -> None:
        self.goals = {goal.id: goal for goal in task.goals}
        self.completed: set[str] = set()

    def act(self, observation: Mapping[str, Any]) -> Mapping[str, Any]:
        ready_ids = tuple(observation.get("ready_goal_ids", ()))
        goal = next((self.goals[goal_id] for goal_id in ready_ids if goal_id not in self.completed), None)
        if goal is None:
            return {"kind": "wait"}
        self.completed.add(goal.id)
        return {"kind": goal.action, **dict(goal.parameters)}


class _SemanticVerifier(ReadOnlyConstraintVerifier):
    verifier_id = "paper-a-semantic-goal-verifier-v2"

    def __init__(self, task: TaskProgram, grammar: SemanticGrammar):
        self.task_json = task.canonical_json()
        super().__init__((SemanticEventCheck(task, grammar),), task.goals)

    def verify(self, task, trace):
        if task.canonical_json() != self.task_json or trace.verifier_id != self.verifier_id:
            raise ValueError("semantic verifier task/identity binding mismatch")
        return super().verify(task, trace)


def generated_verifier(task: TaskProgram, *, semantic_grammar: SemanticGrammar | None = None) -> ReadOnlyConstraintVerifier:
    """Return the generic read-only goal verifier for one generated task."""
    if task.public_spec_version == TASK_VERSION:
        if semantic_grammar is None:
            raise ValueError("v2 verification requires the bound semantic grammar")
        return _SemanticVerifier(task, semantic_grammar)
    return ReadOnlyConstraintVerifier((), task.goals)
