"""Private fixed-action validator: ordered SDK inputs and simulator targets.

This audits a pinned Python executor, not arbitrary code. It never grants
checkpoint, agent-observation, scientific or training admission.
"""
import copy
import hashlib
import json
from pathlib import Path

import numpy as np


CHANNELS = ('joint_position_target', 'joint_velocity_target', 'joint_effort_target')
METHODS = tuple('set_' + field for field in CHANNELS)
TASK_CALLS = (('fr3_A', METHODS[0]), ('fr3_A', METHODS[2]))
TOTAL_COMMANDS, CUT, HOLD = 13427, 2400, 30
TOTAL_STEPS = TOTAL_COMMANDS + HOLD
MAX_TRACE_BYTES = 256 * 1024 * 1024


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def tensor(value):
    if hasattr(value, 'detach'):
        value = value.detach().cpu().numpy()
    value = np.asarray(value)
    if value.dtype != np.float32 or value.ndim != 2 or value.shape[0] != 1 or not 1 <= value.shape[1] <= 128:
        raise ValueError('one complete float32 environment tensor required')
    if not np.isfinite(value).all():
        raise ValueError('nonfinite actuator input')
    value = np.ascontiguousarray(value, dtype='<f4')
    return dict(dtype='float32', shape=list(value.shape), values=value.tolist(),
                sha256=hashlib.sha256(value.tobytes()).hexdigest())


def checked_tensor(record, joints):
    if type(record) is not dict or set(record) != {'dtype', 'shape', 'values', 'sha256'}:
        raise ValueError('exact tensor record required')
    if record['dtype'] != 'float32' or record['shape'] != [1, joints]:
        raise ValueError('actuator dtype or joint count differs')
    v = record['values']
    if (type(v) is not list or len(v) != 1 or type(v[0]) is not list or len(v[0]) != joints or
            any(type(x) not in (int, float) for x in v[0])):
        raise ValueError('complete numeric actuator values required')
    with np.errstate(over='raise', invalid='raise'):
        a = np.asarray(v, dtype=np.float32)
    if tensor(a) != record:
        raise ValueError('actuator bytes are not exact canonical float32 values')
    return a


def registry_checked(registry):
    if type(registry) is not dict or not 1 <= len(registry) <= 32 or 'fr3_A' not in registry:
        raise ValueError('bounded articulation registry required')
    for name, joints in registry.items():
        if (type(name) is not str or not name or type(joints) is not list or not 1 <= len(joints) <= 128 or
                any(type(j) is not str or not j for j in joints) or len(joints) != len(set(joints))):
            raise ValueError('ordered unique joint registry required')
    return copy.deepcopy(registry)


def context(index):
    if type(index) is not int or not 0 <= index < TOTAL_STEPS:
        raise ValueError('bounded canonical action step required')
    if CUT <= index < CUT + HOLD:
        return dict(index=index, kind='hold', source_before=CUT, source_after=CUT)
    source = index if index < CUT else index - HOLD
    return dict(index=index, kind='task', source_before=source, source_after=source + 1)


def header(source_pins_sha256, checkpoint_identity, registry):
    if type(source_pins_sha256) is not str or len(source_pins_sha256) != 64 or any(c not in '0123456789abcdef' for c in source_pins_sha256):
        raise ValueError('source digest required')
    if type(checkpoint_identity) is not dict or not checkpoint_identity:
        raise ValueError('exact checkpoint identity required')
    return dict(schema='chemrm-v100-private-complete-action-trace-v1',
                source_pins_sha256=source_pins_sha256, checkpoint_identity=copy.deepcopy(checkpoint_identity),
                registry=registry_checked(registry), channels=list(CHANNELS), total_steps=TOTAL_STEPS,
                cut_command=CUT, hold_steps=HOLD, private_validator_only=True,
                agent_visible=False, scientific_admission=False, training_admission=False)


def snapshot_checked(snapshot, registry):
    if type(snapshot) is not dict or set(snapshot) != set(registry):
        raise ValueError('complete action target registry required')
    for name, values in snapshot.items():
        if type(values) is not dict or set(values) != set(CHANNELS):
            raise ValueError('all three effective actuator channels required')
        for payload in values.values():
            checked_tensor(payload, len(registry[name]))


def row_checked(row, expected_index, registry):
    if type(row) is not dict or set(row) != {'index', 'kind', 'source_before', 'source_after', 'calls', 'targets', 'simulator_targets'}:
        raise ValueError('complete canonical action row required')
    if any(row[k] != v or type(row[k]) != type(v) for k, v in context(expected_index).items()):
        raise ValueError('action phase, source cursor or order differs')
    expected = () if row['kind'] == 'hold' else TASK_CALLS
    calls = row['calls']
    if type(calls) is not list or len(calls) != len(expected):
        raise ValueError('missing or extra actuator calls')
    for event, (name, method) in zip(calls, expected):
        if type(event) is not dict or set(event) != {'entity', 'method', 'input'} or (event['entity'], event['method']) != (name, method):
            raise ValueError('actuator setter or call order differs')
        checked_tensor(event['input'], len(registry[name]))
        if event['input'] != row['targets'][name][method[4:]]:
            raise ValueError('setter input and effective readback differ')
    for key in ('targets', 'simulator_targets'):
        snapshot_checked(row[key], registry)
    if row['targets'] != row['simulator_targets']:
        raise ValueError('actuator model changed applied simulator targets')
    return row


def json_line(line):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('duplicate JSON field')
            result[key] = value
        return result
    return json.loads(line, object_pairs_hook=pairs)


def verify_trace(directory, expected_header):
    directory = Path(directory)
    if json_line((directory/'header.json').read_text()) != expected_header:
        raise ValueError('private action trace identity or registry differs')
    path = directory/'actions.jsonl'
    if path.is_symlink() or not 0 < path.stat().st_size <= MAX_TRACE_BYTES:
        raise ValueError('bounded regular action trace required')
    seal = json_line((directory/'SEALED.json').read_text())
    if seal != dict(schema='chemrm-v100-action-seal-v1', rows=TOTAL_STEPS,
                    header_sha256=sha(directory/'header.json'), actions_sha256=sha(path)):
        raise ValueError('private action trace seal differs')
    count = 0
    with path.open() as stream:
        for count, line in enumerate(stream, 1):
            if count > TOTAL_STEPS or len(line) > 128 * 1024:
                raise ValueError('unbounded action trace row')
            row_checked(json_line(line), count - 1, expected_header['registry'])
    if count != TOTAL_STEPS:
        raise ValueError('action trace has missing canonical steps')
    return seal


def poison_on_error(method):
    def checked(self, *args, **kwargs):
        try:
            return method(self, *args, **kwargs)
        except BaseException:
            self.broken = True
            raise
    return checked


class ActionTrace:
    """Fail-closed ordered control seam, including hold steps with no setters."""
    def __init__(self, directory, expected_header, *, replay=None):
        self.directory, self.header = Path(directory), copy.deepcopy(expected_header)
        self.registry = registry_checked(expected_header['registry'])
        if self.header != header(self.header['source_pins_sha256'], self.header['checkpoint_identity'], self.registry):
            raise ValueError('action header has unsupported fields or scope')
        self.reference = None
        if replay is not None:
            replay = Path(replay)
            self.reference_seal = verify_trace(replay, self.header)
            self.reference = (replay/'actions.jsonl').open()
            for _ in range(CUT):
                self.reference.readline()
        self.next_index = CUT if self.reference else 0
        self.directory.mkdir(exist_ok=False)
        (self.directory/'header.json').write_text(json.dumps(self.header, allow_nan=False, sort_keys=True)+'\n')
        self.stream = (self.directory/'actions.jsonl').open('x')
        self.active = None
        self.expected = None
        self.broken = False

    def fail(self, message):
        self.broken = True
        raise ValueError(message)

    @poison_on_error
    def begin(self, kind, source_before):
        if self.broken or self.active is not None:
            self.fail('action step unavailable or previous step incomplete')
        ctx = context(self.next_index)
        if ctx['kind'] != kind or type(source_before) is not int or ctx['source_before'] != source_before:
            self.fail('source command is out of canonical action order')
        self.expected = json_line(self.reference.readline()) if self.reference else None
        if self.expected is not None:
            row_checked(self.expected, self.next_index, self.registry)
        self.active = dict(**ctx, calls=[], targets=None, simulator_targets={})

    @poison_on_error
    def call(self, entity, method, payload, forward):
        if self.broken or self.active is None:
            self.fail('actuator setter outside an accounted action step')
        plan = () if self.active['kind'] == 'hold' else TASK_CALLS
        number = len(self.active['calls'])
        if number >= len(plan) or (entity, method) != plan[number]:
            self.fail('extra or unordered actuator setter refused before forwarding')
        try:
            checked_tensor(payload, len(self.registry[entity]))
        except (ValueError, TypeError, KeyError, FloatingPointError, OverflowError):
            self.fail('invalid actuator payload refused before forwarding')
        event = dict(entity=entity, method=method, input=copy.deepcopy(payload))
        if self.expected is not None and event != self.expected['calls'][number]:
            self.fail('actuator bytes differ from the private live action')
        try:
            result = forward()
        except BaseException:
            self.broken = True
            raise
        self.active['calls'].append(event)
        return result

    @poison_on_error
    def before_flush(self, targets):
        if self.broken or self.active is None:
            self.fail('unaccounted physical advance')
        expected = 0 if self.active['kind'] == 'hold' else len(TASK_CALLS)
        if len(self.active['calls']) != expected:
            self.fail('missing actuator setter before physics')
        snapshot_checked(targets, self.registry)
        if self.expected is not None and targets != self.expected['targets']:
            self.fail('effective target readback differs before physics')
        self.active['targets'] = copy.deepcopy(targets)

    @poison_on_error
    def simulator_output(self, entity, values):
        if self.broken or self.active is None or self.active['targets'] is None or entity in self.active['simulator_targets']:
            self.fail('unaccounted or duplicate simulator actuator output')
        snapshot_checked({entity: values}, {entity: self.registry[entity]})
        if values != self.active['targets'][entity]:
            self.fail('simulator output differs from declared effective targets')
        self.active['simulator_targets'][entity] = copy.deepcopy(values)

    @poison_on_error
    def before_physics(self):
        if self.broken or self.active is None:
            self.fail('action record not open before physics')
        row_checked(self.active, self.next_index, self.registry)
        if self.expected is not None and self.active != self.expected:
            self.fail('full applied action differs before physics')
        self.stream.write(json.dumps(self.active, allow_nan=False, separators=(',', ':'))+'\n')
        self.next_index += 1
        self.active = self.expected = None

    @poison_on_error
    def replay_calls(self):
        if self.broken or self.active is None or self.expected is None:
            self.fail('no authorized private replay step')
        return copy.deepcopy(self.expected['calls'])

    def close(self, *, complete):
        if self.stream.closed:
            return
        self.stream.flush()
        __import__('os').fsync(self.stream.fileno())
        self.stream.close()
        if self.reference is not None:
            self.reference.close()
        if complete and (self.broken or self.active is not None or self.next_index != TOTAL_STEPS):
            self.fail('cannot seal an incomplete action trace')
        if complete:
            rows = TOTAL_STEPS - (CUT if self.reference is not None else 0)
            seal = dict(schema='chemrm-v100-action-seal-v1', rows=rows,
                        header_sha256=sha(self.directory/'header.json'), actions_sha256=sha(self.directory/'actions.jsonl'))
            (self.directory/'SEALED.json').write_text(json.dumps(seal, sort_keys=True)+'\n')
