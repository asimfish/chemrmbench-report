"""Paper A: a simulator-agnostic, read-only benchmark harness.

The harness keeps the measurement boundary explicit:

    TaskProgram -> ControlledWorld -> FrozenPolicy -> Trace -> ReadOnlyVerifier -> Evidence

It is intentionally small and backend-neutral.  The current implementation is an F0 contract
runner; Isaac/pixel worlds can implement the same world protocol without changing the verifier or
evidence format.
"""

from chemrm.papera.contract import (
    BundleCheck,
    EpisodeVerdict,
    EvidenceBundle,
    Trace,
    verify_bundle,
)
from chemrm.papera.runner import (
    ControlledWorld,
    FrozenPolicy,
    ReadOnlyConstraintVerifier,
    RunResult,
    WorldStep,
    run_episode,
)
from chemrm.papera.core_f0 import (CoreFamilyVerifier, CoreFamilyWorld, DyeReferencePolicy,
                                    FeaturePolicy, make_core_task)
from chemrm.papera.spec import BenchmarkTask, load_benchmark_task
from chemrm.papera.task_worlds import (
    C5EndpointPolicy,
    C5EndpointWorld,
    C6StirringPolicy,
    C6StirringWorld,
    C13MemoryTimePolicy,
    C13MemoryTimeWorld,
    TaskCase,
    load_f0_task,
    make_task_case,
)
from chemrm.papera.manifest import (
    FrozenTaskManifest,
    ManifestTask,
    TaskRegistration,
    load_registered_tasks,
    load_task_manifest,
    verify_task_manifest,
    write_task_manifest,
)
from chemrm.papera.release import F1ReleaseResult, ScheduleResult, run_f1_release_gate, validate_tick_schedule
from chemrm.papera.generator import GoalTemplate, PublicGrammar, generate_public_tasks, public_signature
from chemrm.papera.generated_world import GeneratedGoalPolicy, GeneratedGoalWorld, generated_verifier
from chemrm.papera.thermal_dose import (
    ThermalDosePolicy, ThermalDoseSpec, ThermalDoseVerifier, ThermalDoseWorld,
    make_thermal_dose_task, replay_thermal_dose_bundle, thermal_dose_spec,
)
from chemrm.papera.semantics import (
    Primitive, ProgramNode, SemanticGrammar, SemanticProgram, TaskFamily,
    audit_semantic_grammar, generate_semantic_tasks, semantic_signature, validate_semantic_task,
)

__all__ = [
    "BundleCheck",
    "BenchmarkTask",
    "C5EndpointPolicy",
    "C5EndpointWorld",
    "C6StirringPolicy",
    "C6StirringWorld",
    "C13MemoryTimePolicy",
    "C13MemoryTimeWorld",
    "CoreFamilyVerifier",
    "CoreFamilyWorld",
    "DyeReferencePolicy",
    "ControlledWorld",
    "EpisodeVerdict",
    "EvidenceBundle",
    "F1ReleaseResult",
    "GoalTemplate",
    "GeneratedGoalPolicy",
    "GeneratedGoalWorld",
    "FeaturePolicy",
    "FrozenPolicy",
    "FrozenTaskManifest",
    "ReadOnlyConstraintVerifier",
    "RunResult",
    "PublicGrammar",
    "Primitive",
    "ProgramNode",
    "SemanticGrammar",
    "SemanticProgram",
    "TaskFamily",
    "audit_semantic_grammar",
    "generate_semantic_tasks",
    "semantic_signature",
    "validate_semantic_task",
    "ScheduleResult",
    "Trace",
    "ThermalDosePolicy",
    "ThermalDoseSpec",
    "ThermalDoseVerifier",
    "ThermalDoseWorld",
    "WorldStep",
    "run_episode",
    "make_core_task",
    "make_thermal_dose_task",
    "replay_thermal_dose_bundle",
    "thermal_dose_spec",
    "load_benchmark_task",
    "TaskCase",
    "ManifestTask",
    "TaskRegistration",
    "load_f0_task",
    "load_registered_tasks",
    "load_task_manifest",
    "make_task_case",
    "verify_task_manifest",
    "verify_bundle",
    "run_f1_release_gate",
    "generate_public_tasks",
    "generated_verifier",
    "public_signature",
    "validate_tick_schedule",
    "write_task_manifest",
]
