"""New development-only renderer candidate; sealed V15 provider is unchanged.

Use explicit analytic distant lighting with sampled direct lighting disabled.
This candidate is not a passed future gate or a complete F2 benchmark release.
"""
from __future__ import annotations
import math

from chemrm.papera.isaac_bridge_native import IsaacBridge

STATIC_SETTINGS = {
    '/rtx/directLighting/sampledLighting/enabled': False,
    '/rtx/directLighting/sampledLighting/autoEnable': False,
    '/rtx-transient/directLighting/sampledLighting/enforced': False,
}


class FixedLightCandidate(IsaacBridge):
    def __init__(self, asset_path, intensity=1000.):
        if not math.isfinite(intensity) or intensity <= 0:
            raise ValueError('positive finite distant-light intensity required')
        super().__init__(asset_path)
        import carb
        import omni.usd
        from pxr import UsdLux
        self.settings = carb.settings.get_settings()
        for key, value in STATIC_SETTINGS.items():
            self.settings.set_bool(key, value)
        light = UsdLux.DistantLight.Define(omni.usd.get_context().get_stage(), '/World/explicit_fixed_light')
        light.CreateIntensityAttr(float(intensity))
        light.CreateAngleAttr(0.)
        self.light_intensity = float(intensity)

    def check_settings(self):
        actual = {key: self.settings.get(key) for key in STATIC_SETTINGS}
        if actual != STATIC_SETTINGS:
            raise RuntimeError('fixed-light candidate settings changed')
        return actual

    def reset(self, case):
        super().reset(case)
        self.check_settings()
        self.events[0]['candidate_renderer_settings'] = self.check_settings()
        self.events[0]['candidate_distant_light_intensity'] = self.light_intensity

    def capture(self):
        self.check_settings()
        return super().capture()
