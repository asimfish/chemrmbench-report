"""Pinned implicit-actuator SDK seam, installed after checkpoint restoration.

Every named asset setter outside the three supported joint target setters is
denied. Actual pre-integration PhysX input buffers are checked for all joints.
This is an executor audit, not an isolation boundary against arbitrary Python.
"""
from .action_trace_v100 import CHANNELS, METHODS, tensor, checked_tensor


SDK_FIELDS = ('joint_pos_target', 'joint_vel_target', 'joint_effort_target')
SIM_FIELDS = ('_joint_pos_target_sim', '_joint_vel_target_sim', '_joint_effort_target_sim')


class SDKActionAudit:
    def __init__(self, scene, trace, tensor_factory):
        self.scene, self.trace, self.tensor_factory = scene, trace, tensor_factory
        self.originals = {}
        if {n: list(a.joint_names) for n, a in scene.articulations.items()} != trace.registry:
            raise ValueError('runtime articulation joint registry differs')
        self.assets = {**scene.rigid_objects, **scene.articulations}
        self._check_environment()
        for name, asset in self.assets.items():
            for method in dir(asset):
                if (method.startswith('set_') or
                        method.startswith('write_') and method.endswith('_to_sim')) and callable(getattr(asset, method)):
                    original = getattr(asset, method)
                    self.originals[(name, method)] = original
                    if name in scene.articulations and method in METHODS:
                        setattr(asset, method, self._setter(name, method, original))
                    elif method != 'write_data_to_sim':
                        setattr(asset, method, self._deny(name, method))
            if name in scene.articulations:
                original = asset.write_data_to_sim
                self.originals[(name, 'write_data_to_sim')] = original
                setattr(asset, 'write_data_to_sim', self._flush(name, asset, original))

    def _check_environment(self):
        for asset in self.scene.articulations.values():
            if not asset.actuators or any(a.is_implicit_model is not True for a in asset.actuators.values()):
                self.trace.fail('only pinned implicit actuator groups are supported')
            if not asset._has_implicit_actuators:
                self.trace.fail('implicit position/velocity channels missing')
        for asset in self.assets.values():
            if asset.instantaneous_wrench_composer.active or asset.permanent_wrench_composer.active:
                self.trace.fail('external wrench is outside the fixed-action contract')

    def _deny(self, entity, method):
        def denied(*args, **kwargs):
            self.trace.fail('unrecorded asset state/property/action method: '+entity+'/'+method)
        return denied

    def _setter(self, entity, method, original):
        def checked(*args, **kwargs):
            if len(args) != 1 or kwargs:
                self.trace.fail('only full ordered joint-target tensors may be replayed')
            try:
                payload = tensor(args[0])
            except (ValueError, TypeError):
                self.trace.fail('invalid SDK target payload before setter')
            return self.trace.call(entity, method, payload, lambda: original(*args))
        return checked

    def _flush(self, name, asset, original):
        def checked():
            if self.trace.active is None or self.trace.active['targets'] is None:
                self.trace.fail('unaccounted SDK action flush')
            original()
            values = {c: tensor(getattr(asset, f)) for c, f in zip(CHANNELS, SIM_FIELDS)}
            self.trace.simulator_output(name, values)
        return checked

    def before_flush(self):
        self._check_environment()
        current = {name: {c: tensor(getattr(asset.data, f)) for c, f in zip(CHANNELS, SDK_FIELDS)}
                   for name, asset in self.scene.articulations.items()}
        self.trace.before_flush(current)

    def replay(self):
        for event in self.trace.replay_calls():
            entity = event['entity']
            values = checked_tensor(event['input'], len(self.trace.registry[entity]))
            getattr(self.scene.articulations[entity], event['method'])(self.tensor_factory(values))

    def receipt(self):
        return dict(schema='chemrm-v100-implicit-sdk-action-audit-v1',
                    wrapped_methods=[list(x) for x in sorted(self.originals)],
                    articulation_count=len(self.scene.articulations), all_actuators_implicit=True,
                    external_wrenches_allowed=False, all_three_simulator_channels_observed=True,
                    private_validator_only=True, agent_visible=False, scientific_admission=False)
