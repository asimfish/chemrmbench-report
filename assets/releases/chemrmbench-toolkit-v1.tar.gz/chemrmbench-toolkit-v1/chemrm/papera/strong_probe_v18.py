"""Prospective stronger C13 diagnostic; old train/dev, genuinely new future."""
from __future__ import annotations

import json
import math
import numpy as np
from chemrm.papera.clock_repair_v17 import build_bank as old_bank, SETTINGS, LIGHT_INTENSITY
from chemrm.papera.isaac_bridge_contract import Case
from chemrm.papera.isaac_bridge_verify import sha256
from chemrm.papera.native_leakage import SCHEMA, AGES, require_disjoint_scenes

REVISION = 'papera-strong-probe-v18'
CHANNELS = ['rgb', 'joints', 'rgb_joints', 'full_rgb', 'clip_pool', 'clip_patches']
VISUAL_CHANNELS = ['rgb', 'rgb_joints', 'full_rgb', 'clip_pool', 'clip_patches']
TASKS = [('post', 'clock'), ('fixed_time', 'clock'), ('post', 'identity'), ('cue', 'identity')]
ALPHAS = [1e-4, .01, 1., 100., 10000.]


def build_bank():
    prior = old_bank()
    scenes = [s for s in prior['scenes'] if s['split'] != 'future']
    cases = [r for r in prior['cases'] if r['split'] != 'future']
    geometry, timing, order = (np.random.default_rng(s) for s in (181008, 281008, 381008))
    for i in range(60):
        scene_id = f'v18_future_{i:03d}'
        scene = dict(scene_id=scene_id, split='future', scene_x=float(geometry.uniform(.4, .55)),
                     spacing=float(geometry.uniform(.12, .18)), camera_height=float(geometry.uniform(1.5, 2.1)),
                     onset_s=float(timing.integers(300, 2401))/60.)
        scenes.append(scene)
        for target in order.permutation(5).tolist():
            c = Case(case_id=f'{scene_id}_t{target}', family='C13', split='future', seed=181008+i,
                     target=target, onset_s=scene['onset_s'], wait_s=60., eta=.15, latency_s=0.,
                     scene_x=scene['scene_x'], spacing=scene['spacing'], camera_height=scene['camera_height'],
                     equivalence_ml=10.)
            cases.append(dict(scene_id=scene_id, split='future', case=c.to_dict()))
    return dict(schema=SCHEMA, revision=REVISION, ages_s=AGES, fixed_query_s=110., scenes=scenes, cases=cases,
                channels=CHANNELS, alphas=ALPHAS, renderer=prior['renderer'], paused_control=prior['paused_control'],
                reused_train_dev_revision=prior['revision'], future_scene_count=60)


def validate_bank(bank):
    if bank != build_bank():
        raise ValueError('V18 bank differs from prospective generator')
    require_disjoint_scenes(bank['cases'])
    for row in bank['cases']:
        Case(**row['case'])
    # Check geometry novelty as well as names; discrete onset values may repeat.
    from chemrm.papera.native_leakage import build_bank as v16_bank
    key = lambda s: tuple(s[k] for k in ('scene_x', 'spacing', 'camera_height', 'onset_s'))
    prior = {key(s) for s in old_bank()['scenes'] + v16_bank()['scenes']}
    future = [key(s) for s in bank['scenes'] if s['split'] == 'future']
    if len(set(future)) != 60 or prior.intersection(future):
        raise ValueError('future geometry/timing tuple is not novel')


def exact_lower(successes, total, alpha=.05):
    """One-sided Clopper-Pearson bound, using independent scene Bernoulli units."""
    if not 0 <= successes <= total or total < 1 or not 0 < alpha < 1:
        raise ValueError('invalid binomial evidence')
    if successes == 0:
        return 0.
    if successes == total:
        return alpha ** (1/total)
    lo, hi = 0., 1.
    for _ in range(80):
        p = (lo + hi)/2
        tail = sum(math.comb(total, k)*p**k*(1-p)**(total-k) for k in range(successes, total+1))
        if tail < alpha:
            lo = p
        else:
            hi = p
    return (lo+hi)/2


def classify(results, roi_pass, visual_controls_pass):
    primary = [r for r in results if r['group'] == 'post']
    if any(r['score'] > (.05 if r['target'] == 'clock' else .30) for r in primary):
        return 'LEAKAGE_DETECTED'
    if not roi_pass:
        return 'PERCEPTION_CONTROL_FAILED'
    if not visual_controls_pass:
        return 'PROBE_CONTROLS_LIMITED'
    if all(r['ci95_scene_bootstrap'][1] <= (.05 if r['target'] == 'clock' else .30) for r in primary):
        return 'BOUNDED_NO_LEAKAGE'
    return 'INCONCLUSIVE'


def verify_model_seal(models, freeze_path):
    path = models / 'fit_receipt.json'
    r = json.loads(path.read_text())
    expected = {(g, t, c) for g, t in TASKS for c in CHANNELS}
    if (r.get('revision') != REVISION or r.get('status') != 'FROZEN_BEFORE_FUTURE_READ' or
            r.get('future_observations_read') is not False or r.get('freeze_sha256') != sha256(freeze_path) or
            len(r['choices']) != 24 or {(c['group'], c['target'], c['channel']) for c in r['choices']} != expected):
        raise ValueError('invalid V18 model seal')
    for c in r['choices']:
        if c['model'] != f"{c['group']}_{c['target']}_{c['channel']}.npz" or sha256(models/c['model']) != c['sha256']:
            raise ValueError('changed sealed model')
    if sha256(models/'declared_age_oracle.npz') != r['oracle_sha256']:
        raise ValueError('changed oracle')
    return sha256(path)
