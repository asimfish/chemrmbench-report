"""Permitted causal lift report and explicit memory on a preserved task clock.

The instrument report is a declared ideal simulation observation. Its existence
does not calibrate physical sensing or establish a memory-effect comparison.
"""
import json
import re
from pathlib import Path

from .agent_memory_v81 import physics_binding,finite
from .astra_boundary_v70 import public_observation
from .collection_engine_v70 import encoded,identity,publish
from .staged_collection import digest
from .task_clock_v88 import TaskClockLedger
from .temporal_evidence_v74 import Interval

DELAYS={'green':30.,'amber':36.}
SKILL='A1_regrasp_return'
INSTRUCTION=(
    'A declared simulation instrument reports the past bottle lift above 30 mm as a closed event-time interval. '
    'At that confirmation a floating status square above the weighing scale briefly shows green or amber. '
    'Remember the interval, task clock id and square color. Green requests bilateral regrasp 30 seconds '
    'after that original lift event; amber requests 36 seconds. The instrument report is an ideal simulated '
    'observation, not calibrated chemistry. On resumption the old image and report are absent. '
    'The same logical task clock continues: failed native attempts and reconstruction steps spend the '
    'original deadline. Never re-anchor the target at resumption or retry. Use A1_regrasp_return only. '
    'If history is insufficient choose wait or abort; do not invent a past event.')

def _clock(value):
    if type(value) is not str or not re.fullmatch(r'task_v88:[a-f0-9]{16}',value):
        raise ValueError('declared logical task clock required')
    return value

def _bounds(value):
    if type(value) is not list or len(value)!=2 or not all(finite(x) for x in value) or value[0]>value[1]:
        raise ValueError('finite ordered closed event bounds required')
    return value

def packet(*,phase,clock_id,joints,image_sha256,timestamp_s,event_report=None):
    _clock(clock_id)
    if phase not in ('CUE','RESUME'):raise ValueError('registered observation phase required')
    if not finite(timestamp_s):raise ValueError('finite current task time required')
    if phase=='CUE':
        if type(event_report) is not dict or set(event_report)!={'bounds_s','clock_id','kind','calibrated','endpoint_semantics'}:
            raise ValueError('causal public event report required')
        if (event_report['clock_id']!=clock_id or event_report['kind']!='bottle_lift_30mm'
            or event_report['calibrated'] is not False or event_report['endpoint_semantics']!='CONSERVATIVE_CLOSED_BOUNDS'
            or _bounds(event_report['bounds_s'])[1]>timestamp_s):raise ValueError('past uncalibrated lift report required')
    elif event_report is not None:raise ValueError('old event report forbidden in current-only packet')
    observation=public_observation(track='B',instruction={'text':INSTRUCTION},joints_q=joints,
        images=[{'view':'station','sha256':image_sha256}],current_clock_s=timestamp_s)
    body=dict(schema='chemrm-public-original-event-packet-v90',phase=phase,
        clock_id=clock_id,observation=observation,event_report=event_report)
    return dict(packet=body,sha256=identity(body))

def validate_packet(value):
    if type(value) is not dict or set(value)!={'packet','sha256'}:raise ValueError('public envelope required')
    p=value['packet']
    if type(p) is not dict or set(p)!={'schema','phase','clock_id','observation','event_report'} or p['schema']!='chemrm-public-original-event-packet-v90':
        raise ValueError('private fields outside the public contract')
    obs=p['observation']
    if type(obs) is not dict or set(obs)!={'actor','sha256','track'} or obs['track']!='B':raise ValueError('public observation required')
    actor=obs['actor']
    if type(actor) is not dict or set(actor)!={'instruction','joints_q','images','timestamp_s'} or actor['instruction']!={'text':INSTRUCTION}:
        raise ValueError('fixed instruction and measured channels only')
    images=actor['images']
    if type(images) is not list or len(images)!=1 or type(images[0]) is not dict or set(images[0])!={'view','sha256'} or images[0]['view']!='station':
        raise ValueError('one bound current station image required')
    expected=packet(phase=p['phase'],clock_id=p['clock_id'],joints=actor['joints_q'],
        image_sha256=images[0]['sha256'],timestamp_s=actor['timestamp_s'],event_report=p['event_report'])
    if expected!=value:raise ValueError('public packet binding changed')
    return json.loads(encoded(value))

def validate_memory(memory,observation):
    observation=validate_packet(observation)
    if observation['packet']['phase']!='CUE':raise ValueError('past cue observation required')
    required={'observation_sha256','cue_color','requested_gap_s','event_a_bounds_s','event_a_clock_id'}
    if type(memory) is not dict or set(memory)!=required or memory['observation_sha256']!=observation['sha256']:
        raise ValueError('memory must bind the exact cue packet')
    color=memory['cue_color']
    if color not in (*DELAYS,'unknown'):raise ValueError('bounded cue interpretation required')
    if color=='unknown':
        if any(memory[k] is not None for k in ('requested_gap_s','event_a_bounds_s','event_a_clock_id')):
            raise ValueError('unknown history cannot invent an event')
    else:
        if memory['requested_gap_s']!=DELAYS[color]:raise ValueError('declared color-to-gap mapping required')
        _bounds(memory['event_a_bounds_s']);_clock(memory['event_a_clock_id'])
    # Recalled-event and color correctness are independently assessed, not repaired.
    return json.loads(encoded(memory))

def seal_memory(directory,observation,memory,checkpoint_directory,policy_sha256,cursor,ledger_directory):
    observation=validate_packet(observation);memory=validate_memory(memory,observation)
    binding=physics_binding(checkpoint_directory,policy_sha256,cursor)
    timer=TaskClockLedger(ledger_directory);header=timer._header()
    if binding['checkpoint_sha256']!=header['checkpoint_sha256'] or observation['packet']['clock_id']!=timer.clock_id:
        raise ValueError('memory/event/physical checkpoint lineage differs')
    directory=Path(directory);directory.mkdir(parents=True,exist_ok=False)
    body=dict(schema='chemrm-original-event-memory-v90',source_public_packet=observation,memory=memory,
        contains_past_images=False,hidden_model_state_restored=False,scientific_admission=False)
    publish(directory/'memory.json',encoded(body))
    manifest=dict(schema='chemrm-original-event-memory-binding-v90',binding=binding,
        memory_sha256=digest(directory/'memory.json'),timer_header_sha256=digest(Path(ledger_directory)/'HEADER.json'),
        clock_id=timer.clock_id,scientific_admission=False)
    publish(directory/'manifest.json',encoded(manifest))
    publish(directory/'COMMITTED.json',encoded({'manifest_sha256':digest(directory/'manifest.json')}))
    return manifest

def restore_memory(directory,checkpoint_directory,policy_sha256,cursor,ledger_directory):
    directory=Path(directory);timer=TaskClockLedger(ledger_directory)
    marker=json.loads((directory/'COMMITTED.json').read_text());manifest=json.loads((directory/'manifest.json').read_text())
    required={'schema','binding','memory_sha256','timer_header_sha256','clock_id','scientific_admission'}
    if (set(manifest)!=required or manifest['schema']!='chemrm-original-event-memory-binding-v90'
        or manifest['scientific_admission'] is not False or marker!={'manifest_sha256':digest(directory/'manifest.json')}
        or manifest['binding']!=physics_binding(checkpoint_directory,policy_sha256,cursor)
        or manifest['binding']['checkpoint_sha256']!=timer._header()['checkpoint_sha256']
        or manifest['timer_header_sha256']!=digest(Path(ledger_directory)/'HEADER.json')
        or manifest['clock_id']!=timer.clock_id or digest(directory/'memory.json')!=manifest['memory_sha256']):
        raise ValueError('memory or physical/timer binding changed')
    body=json.loads((directory/'memory.json').read_text())
    if (set(body)!={'schema','source_public_packet','memory','contains_past_images','hidden_model_state_restored','scientific_admission'}
        or body['schema']!='chemrm-original-event-memory-v90' or body['contains_past_images'] is not False
        or body['hidden_model_state_restored'] is not False or body['scientific_admission'] is not False):
        raise ValueError('explicit public memory only')
    source=validate_packet(body['source_public_packet']);validate_memory(body['memory'],source)
    if source['packet']['clock_id']!=timer.clock_id:raise ValueError('stored memory clock differs')
    return body,manifest

def checked_schedule(proposal,observation,memory_sha256,nominal_contact_latency_s,dt_s):
    observation=validate_packet(observation)
    if observation['packet']['phase']!='RESUME':raise ValueError('current resume packet required')
    required={'observation_sha256','memory_sha256','decision','selected_skill','requested_gap_s',
        'contact_task_s','start_task_s','remembered_a_bounds_s','remembered_clock_id'}
    if (type(proposal) is not dict or set(proposal)!=required or proposal['observation_sha256']!=observation['sha256']
        or proposal['memory_sha256']!=memory_sha256):raise ValueError('proposal/current-memory binding changed')
    if proposal['decision'] not in ('schedule','wait','abort'):raise ValueError('bounded decision required')
    if proposal['decision']!='schedule':
        if any(proposal[k] is not None for k in required-{'observation_sha256','memory_sha256','decision'}):
            raise ValueError('abstention cannot dispatch')
        return dict(decision=proposal['decision'],dispatch_requested=False)
    if (proposal['selected_skill']!=SKILL or proposal['requested_gap_s'] not in DELAYS.values()
        or not finite(proposal['start_task_s']) or not finite(proposal['contact_task_s'])
        or not finite(nominal_contact_latency_s,0,20) or not finite(dt_s,1e-5,.1)
        or _clock(proposal['remembered_clock_id'])!=observation['packet']['clock_id']):
        raise ValueError('registered skill on the original task clock required')
    bounds=_bounds(proposal['remembered_a_bounds_s'])
    if (abs(proposal['contact_task_s']-(sum(bounds)/2+proposal['requested_gap_s']))>dt_s
        or abs(proposal['start_task_s']+nominal_contact_latency_s-proposal['contact_task_s'])>dt_s):
        raise ValueError('original-event proposal and public latency estimate disagree')
    return dict(decision='schedule',dispatch_requested=True,skill=SKILL,
        requested_gap_s=proposal['requested_gap_s'],contact_task_s=proposal['contact_task_s'],
        start_task_s=proposal['start_task_s'],remembered_a_bounds_s=bounds,
        remembered_clock_id=proposal['remembered_clock_id'],scientific_admission=False)
