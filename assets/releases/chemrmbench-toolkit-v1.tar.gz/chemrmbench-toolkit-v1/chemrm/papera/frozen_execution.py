"""Explicit factories for preflighted frozen-manifest execution; no dynamic imports."""

from dataclasses import dataclass
from typing import Callable

from chemrm.papera.generated_world import GeneratedGoalPolicy, GeneratedGoalWorld, generated_verifier
from chemrm.papera.manifest import FrozenTaskManifest
from chemrm.papera.runner import ControlledWorld, FrozenPolicy, ReadOnlyVerifier
from chemrm.papera.semantics import TASK_VERSION, validate_semantic_task
from chemrm.papera.thermal_dose import ThermalDosePolicy, ThermalDoseVerifier, ThermalDoseWorld, thermal_dose_spec
from chemrm.task_program import TaskProgram


@dataclass(frozen=True)
class ExecutionCase:
    task: TaskProgram
    world: ControlledWorld
    policy: FrozenPolicy
    verifier: ReadOnlyVerifier


def _graph(task: TaskProgram, snapshot: FrozenTaskManifest) -> ExecutionCase:
    if task.public_spec_version not in {"paper-a-public-grammar-1", TASK_VERSION}:
        raise ValueError("graph-contract backend accepts only declared generated graph tasks")
    grammar = snapshot.semantic_grammar
    if task.public_spec_version == TASK_VERSION:
        if grammar is None:
            raise ValueError("v2 graph task requires its frozen semantic grammar")
        validate_semantic_task(task, grammar)
    return ExecutionCase(task, GeneratedGoalWorld(semantic_grammar=grammar), GeneratedGoalPolicy(),
                         generated_verifier(task, semantic_grammar=grammar))


def _thermal(task: TaskProgram, _snapshot: FrozenTaskManifest) -> ExecutionCase:
    thermal_dose_spec(task)
    return ExecutionCase(task, ThermalDoseWorld(), ThermalDosePolicy(), ThermalDoseVerifier(task))


_BACKENDS: dict[str, Callable[[TaskProgram, FrozenTaskManifest], ExecutionCase]] = {
    "graph-contract": _graph, "thermal-dose": _thermal,
}


def build_manifest_cases(snapshot: FrozenTaskManifest, backend: str) -> tuple[ExecutionCase, ...]:
    """Validate all rows before the caller creates any output or runs an episode."""
    if backend not in _BACKENDS:
        raise ValueError(f"unsupported backend {backend!r}")
    return tuple(_BACKENDS[backend](entry.task, snapshot) for entry in snapshot.tasks)
