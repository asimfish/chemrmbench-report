"""Native RGB sequence commitments and CPU video packaging.

The recorder samples existing simulator output. It cannot step, reconstruct or
correct the world. RGB frames remain available when a native worker fails.
"""
from dataclasses import dataclass
import json
import math
from pathlib import Path
import subprocess
from typing import Protocol

from .staged_collection import digest, write_once


class NativeFrameSource(Protocol):
    def __call__(self) -> dict:
        """Return RGB plus native/callback and registered-state render checks."""


@dataclass(frozen=True)
class VideoSpec:
    physics_hz: int = 240
    sample_stride: int = 20
    width: int = 640
    height: int = 400
    camera: str = 'station_a_camera'

    def __post_init__(self):
        for value in (self.physics_hz, self.sample_stride, self.width, self.height):
            if type(value) is not int or value <= 0:
                raise ValueError('positive integer video configuration required')
        if self.physics_hz % self.sample_stride or self.width % 2 or self.height % 2:
            raise ValueError('integer video frequency and even dimensions required')
        if self.camera != 'station_a_camera':
            raise ValueError('declared native camera required')

    @property
    def fps(self):
        return self.physics_hz // self.sample_stride


class VideoJournal:
    def __init__(self, directory, spec, native_origin_s):
        if not math.isfinite(native_origin_s) or native_origin_s < 0:
            raise ValueError('finite actual native origin required')
        self.directory = Path(directory)
        self.directory.mkdir(exist_ok=False)
        (self.directory / 'frames').mkdir()
        self.spec, self.origin = spec, native_origin_s
        self.last_tick, self.last_cursor, self.count = -1, -1, 0
        write_once(self.directory / 'stream.json', dict(
            schema='chemrm-native-video-stream-v1', spec=spec.__dict__, fps=spec.fps,
            native_origin_s=native_origin_s, capture='NATIVE_RGB_DURING_NEW_PHYSICS',
            frame_index='frames.jsonl', paused_host_rendering=True,
            quantitative_timing_source='240Hz native state/contact logs, not video playback',
            cold_restart_admission=False, scientific_admission=False))

    def capture(self, physics_tick, source_cursor, kind, source: NativeFrameSource):
        if type(physics_tick) is not int or type(source_cursor) is not int:
            raise ValueError('typed native tick and source cursor required')
        if physics_tick != self.count * self.spec.sample_stride:
            raise ValueError('no skipped or duplicate video samples')
        if source_cursor < self.last_cursor or source_cursor < 0 or kind not in ('task', 'hold'):
            raise ValueError('monotone source cursor and declared phase required')
        observation = source()
        if (observation['physics_callbacks_during_render'] != 0
                or observation['physical_state_changed']
                or observation['native_before_s'] != observation['native_after_s']
                or observation['state_sha256_before'] != observation['state_sha256_after']):
            raise ValueError('video render advanced or changed the native world')
        elapsed = observation['native_after_s'] - self.origin
        if not math.isclose(elapsed, physics_tick / self.spec.physics_hz, abs_tol=1e-5, rel_tol=0):
            raise ValueError('video native time and callback count disagree')
        rgb = observation.pop('rgb')
        import numpy as np
        from PIL import Image
        if rgb.shape != (self.spec.height, self.spec.width, 3) or rgb.dtype != np.uint8 or rgb.std() < 2:
            raise ValueError('missing or invalid native RGB frame')
        relative = f'frames/{self.count:06d}.jpg'
        path = self.directory / relative
        Image.fromarray(rgb).save(path, quality=92)
        row = dict(index=self.count, image=relative, image_sha256=digest(path),
                   physics_tick=physics_tick, source_command_cursor=source_cursor, kind=kind,
                   native_elapsed_s=elapsed, video_pts_s=self.count / self.spec.fps, **observation)
        with (self.directory / 'frames.jsonl').open('a') as handle:
            handle.write(json.dumps(row, allow_nan=False) + '\n')
            handle.flush()
        self.count += 1
        self.last_tick, self.last_cursor = physics_tick, source_cursor
        return row


def verify_video_frames(directory):
    directory = Path(directory)
    header = json.loads((directory / 'stream.json').read_text())
    spec = VideoSpec(**header['spec'])
    rows = [json.loads(line) for line in (directory / 'frames.jsonl').read_text().splitlines()]
    if not rows:
        raise ValueError('empty video evidence')
    prior_cursor = -1
    for index, row in enumerate(rows):
        if (row['index'] != index or row['physics_tick'] != index * spec.sample_stride
                or row['source_command_cursor'] < prior_cursor or row['kind'] not in ('task', 'hold')):
            raise ValueError('video index continuity failed')
        if row['image'] != f'frames/{index:06d}.jpg' or digest(directory / row['image']) != row['image_sha256']:
            raise ValueError('video frame hash or owned path failed')
        if (row['physics_callbacks_during_render'] or row['physical_state_changed']
                or row['state_sha256_before'] != row['state_sha256_after']
                or row['native_before_s'] != row['native_after_s']):
            raise ValueError('nonpassive video capture')
        if not math.isclose(row['native_elapsed_s'], row['physics_tick']/spec.physics_hz, abs_tol=1e-5, rel_tol=0):
            raise ValueError('video/native sample time mismatch')
        if row['video_pts_s'] != index/spec.fps:
            raise ValueError('video presentation time mismatch')
        prior_cursor = row['source_command_cursor']
    return dict(schema='chemrm-native-video-verified-v1', frames=len(rows), fps=spec.fps,
                camera=spec.camera, width=spec.width, height=spec.height,
                recorded_native_span_s=rows[-1]['native_elapsed_s'],
                playback_duration_s=len(rows)/spec.fps,
                frame_index_sha256=digest(directory/'frames.jsonl'),
                header_sha256=digest(directory/'stream.json'),
                capture='NATIVE_RGB_DURING_NEW_PHYSICS', physical_callbacks_during_render=0,
                scientific_admission=False)


def encode_video(directory):
    """After GPU closure, compress the committed sequence with a bounded CPU job."""
    directory = Path(directory)
    verified = verify_video_frames(directory)
    target = directory / 'native.mp4'
    if target.exists():
        raise ValueError('immutable video output already exists')
    command = ['ffmpeg', '-nostdin', '-hide_banner', '-loglevel', 'error', '-n',
               '-framerate', str(verified['fps']), '-i', str(directory/'frames/%06d.jpg'),
               '-c:v', 'libx264', '-threads', '2', '-preset', 'fast', '-crf', '20',
               '-pix_fmt', 'yuv420p', '-movflags', '+faststart', str(target)]
    subprocess.run(command, check=True, timeout=120, capture_output=True)
    probe = json.loads(subprocess.check_output([
        'ffprobe', '-v', 'error', '-count_frames', '-select_streams', 'v:0',
        '-show_entries', 'stream=width,height,nb_read_frames,r_frame_rate,duration',
        '-of', 'json', str(target)], text=True, timeout=30))['streams'][0]
    if (int(probe['nb_read_frames']) != verified['frames']
            or int(probe['width']) != verified['width'] or int(probe['height']) != verified['height']):
        raise ValueError('encoded video coverage or dimensions differ')
    subprocess.run(['ffmpeg', '-nostdin', '-v', 'error', '-i', str(target), '-f', 'null', '-'],
                   check=True, timeout=60, capture_output=True)
    receipt = verified | dict(mp4='native.mp4', mp4_sha256=digest(target),
                              encoded_frame_count=int(probe['nb_read_frames']),
                              codec='H264', all_frames_decoded=True,
                              encoding_after_native_worker_closed=True)
    write_once(directory / 'ENCODED.json', receipt)
    return receipt
