"""Tool-disabled client for the absolute original-event task-clock contract."""
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

from .codex_memory_v81 import nullable,NUMBER
from .codex_vision_v75 import MODEL,DISABLED
from .event_memory_v90 import validate_packet,SKILL
from .staged_collection import digest

BOUNDS=dict(type='array',items=NUMBER,minItems=2,maxItems=2)
MEMORY_SCHEMA=dict(type='object',properties=dict(
    observation_sha256=dict(type='string'),cue_color=dict(type='string',enum=['green','amber','unknown']),
    requested_gap_s=nullable(dict(type='number',enum=[30.,36.])),
    event_a_bounds_s=nullable(BOUNDS),event_a_clock_id=nullable(dict(type='string'))),
    required=['observation_sha256','cue_color','requested_gap_s','event_a_bounds_s','event_a_clock_id'],additionalProperties=False)
ACTION_SCHEMA=dict(type='object',properties=dict(
    observation_sha256=dict(type='string'),memory_sha256=nullable(dict(type='string')),
    decision=dict(type='string',enum=['schedule','wait','abort']),
    selected_skill=nullable(dict(type='string',enum=[SKILL])),requested_gap_s=nullable(dict(type='number',enum=[30.,36.])),
    contact_task_s=nullable(NUMBER),start_task_s=nullable(NUMBER),remembered_a_bounds_s=nullable(BOUNDS),
    remembered_clock_id=nullable(dict(type='string'))),
    required=['observation_sha256','memory_sha256','decision','selected_skill','requested_gap_s',
        'contact_task_s','start_task_s','remembered_a_bounds_s','remembered_clock_id'],additionalProperties=False)

def invoke(directory,observation,image,*,mode,memory=None,memory_sha256=None,nominal_contact_latency_s=None,timeout_s=60):
    observation=validate_packet(observation)
    if mode not in ('INGEST','READOUT') or (mode=='INGEST')!=(observation['packet']['phase']=='CUE'):
        raise ValueError('public phase and client mode disagree')
    image=Path(image)
    if image.suffix.lower()!='.jpg' or digest(image)!=observation['packet']['observation']['actor']['images'][0]['sha256']:
        raise ValueError('public image binding differs')
    directory=Path(directory);directory.mkdir(exist_ok=False,parents=True)
    shutil.copyfile(image,directory/'observation.jpg')
    if mode=='INGEST':
        payload=dict(public_observation=observation);schema=MEMORY_SCHEMA
        text=('Identify the floating square above the right-hand weighing scale; ignore colored bottle caps. '
            'Author explicit memory with its color and the original lift event interval and clock id from '
            'the causal instrument report. Use green=30 or amber=36 seconds for requested_gap_s. '
            'Copy the event interval, not the later confirmation/observation timestamp. '
            'Unknown cue means unknown and null recalled fields.')
    else:
        payload=dict(public_observation=observation,agent_semantic_memory=memory,
            memory_sha256=memory_sha256,public_nominal_contact_latency_s=nominal_contact_latency_s)
        schema=ACTION_SCHEMA
        text=('The image and clock show the current resumed state; old cue pixels and the event report '
            'are not attached. Use only supplied explicit memory. For scheduling, copy its original '
            'event bounds and task clock id. Set contact_task_s to the midpoint of those ORIGINAL '
            'bounds plus the remembered gap. Set start_task_s to contact_task_s minus the public '
            'nominal skill latency. These are absolute task-clock times, never delays after resume. '
            'Failure and retry do not reset this clock or target. Choose wait or abort if history '
            'is insufficient; for either decision all action and recalled-event fields must be null.')
    prompt=('Laboratory benchmark actor. No tools. Return only schema JSON. Copy the outer supplied '
        'public_observation.sha256. Do not claim chemical success.\n'+text+'\n'+json.dumps(payload,allow_nan=False))
    (directory/'prompt.txt').write_text(prompt)
    (directory/'public_request.json').write_text(json.dumps(payload,indent=2,allow_nan=False)+'\n')
    (directory/'schema.json').write_text(json.dumps(schema,indent=2)+'\n')
    command=['codex','exec','--ignore-user-config','--ignore-rules','--ephemeral','--skip-git-repo-check',
        '--model',MODEL,'--sandbox','read-only']
    for feature in DISABLED:command+=['--disable',feature]
    command+=['-c','web_search="disabled"','-c','approval_policy="never"','-c','model_reasoning_effort="low"',
        '-c','features.skip_host_skill_discovery=true','--json','--image','observation.jpg',
        '--output-schema','schema.json','--output-last-message','answer.json','-']
    (directory/'command.json').write_text(json.dumps(command,indent=2)+'\n')
    env=dict(os.environ)
    for key in list(env):
        if key in ('LD_LIBRARY_PATH','LD_PRELOAD','PWD','OLDPWD') or key.startswith(('CHEMRM_','ALAB_')):
            del env[key]
    # Names and configuration sources only: never record credential values or
    # digests of secrets. Unavailable upstream context is explicitly unattested.
    (directory/'CLIENT_CONTEXT.json').write_text(json.dumps(dict(
        schema='chemrm-client-context-manifest-v90',actual_actor_workdir=str(directory),
        environment_key_names=sorted(env),environment_values_recorded=False,
        stale_shell_workdirs_removed=True,experiment_environment_prefixes_removed=['CHEMRM_','ALAB_'],
        cli_configuration_source='EXPLICIT_ARGUMENTS_WITH_IGNORE_USER_CONFIG_AND_IGNORE_RULES',
        authentication_source='EXISTING_HOST_CLIENT_ENVIRONMENT_OR_CREDENTIAL_STORE_VALUES_NOT_ARCHIVED',
        host_skills_disabled=True,tools_disabled=True,undocumented_provider_context_attested=False),indent=2)+'\n')
    before=time.monotonic()
    with (directory/'events.jsonl').open('xb') as output,(directory/'stderr.log').open('xb') as error:
        child=subprocess.Popen(command,cwd=directory,env=env,stdin=subprocess.PIPE,stdout=output,stderr=error,start_new_session=True)
        try:child.communicate(prompt.encode(),timeout=timeout_s)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=3)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
            raise TimeoutError('uncertain provider result; no automatic retry') from None
    if child.returncode:raise RuntimeError('provider unsuccessful; no automatic retry')
    events=[json.loads(x) for x in (directory/'events.jsonl').read_text().splitlines()]
    if any(e.get('item',{}).get('type') not in (None,'agent_message','reasoning','error') for e in events):
        raise ValueError('provider tool use rejected')
    completed=[e for e in events if e.get('type')=='turn.completed']
    if len(completed)!=1:raise ValueError('unconfirmed provider completion/billing')
    usage=completed[0]['usage'];tokens=usage['input_tokens']+usage['output_tokens']
    if type(tokens) is not int or not 0<=tokens<=16384:raise ValueError('observed token ceiling exceeded')
    result=dict(answer=json.loads((directory/'answer.json').read_text()),usage=usage,known_billed_tokens=tokens,
        host_elapsed_s=time.monotonic()-before,requested_model=MODEL,backend_model_id=None,
        model_identity_scope='EXPLICIT_CLI_SELECTION_BACKEND_ID_NOT_EXPOSED',tool_calls=0,
        provider_response_observed=True,mode=mode,scientific_admission=False)
    (directory/'receipt.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    return result
