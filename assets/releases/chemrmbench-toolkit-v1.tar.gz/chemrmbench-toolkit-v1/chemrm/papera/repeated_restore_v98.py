"""Typed repeated-condition plan and an exact-pose no-op decision.

Skipping a redundant pose write is a narrowly scoped mitigation, not a physical
checkpoint restore or an admission for hidden solver state.
"""
from dataclasses import dataclass
import copy
import numpy as np

CONDITIONS = ('no_write', 'read_only_sham', 'single_pose_write')
ORDER = (CONDITIONS, ('read_only_sham', 'single_pose_write', 'no_write'),
         ('single_pose_write', 'no_write', 'read_only_sham'))


@dataclass(frozen=True)
class Trial:
    phase: str
    repeat: int
    condition: str
    reference_phase: str = 'r1_no_write'


def trials():
    return [Trial(f'r{i}_{condition}', i, condition)
            for i, order in enumerate(ORDER, 1) for condition in order]


def validate_plan(protocol):
    expected = trials()
    if (protocol.get('native_phases') != [t.phase for t in expected] or
        protocol.get('condition_by_phase') != {t.phase: t.condition for t in expected} or
        protocol.get('repeat_by_phase') != {t.phase: t.repeat for t in expected} or
        any(type(v) is not int for v in protocol.get('repeat_by_phase', {}).values()) or
        type(protocol.get('maximum_worker_count')) is not int or protocol['maximum_worker_count'] != 9 or
        protocol.get('reference_phase') != 'r1_no_write' or
        protocol.get('model_request_limit') != 0 or protocol.get('training_jobs') != 0):
        raise ValueError('only the declared balanced nine-trial plan is admitted')
    return expected


def pose_decision(desired, observed):
    """Interface: returns a JSON-safe WRITE or SKIP decision, never forwards."""
    def checked(value):
        if not isinstance(value, (list, tuple, np.ndarray)) or np.shape(value) != (7,):
            raise ValueError('a seven-coordinate pose is required')
        if any(isinstance(x, (bool, np.bool_)) or not isinstance(x, (int, float, np.integer, np.floating)) for x in value):
            raise ValueError('pose coordinates must be real numeric values')
        try:
            with np.errstate(over='raise', invalid='raise'):
                result = np.asarray(value, dtype=np.float32)
        except (ValueError, OverflowError, FloatingPointError) as e:
            raise ValueError('pose cannot be represented by the SDK float32 payload') from e
        if not np.isfinite(result).all() or np.linalg.norm(result[3:].astype(np.float64)) == 0:
            raise ValueError('finite pose and nonzero quaternion are required')
        return result
    a, b = checked(desired), checked(observed)
    return dict(status='SKIP_EXACT_FLOAT32_POSE' if np.array_equal(a, b) else 'WRITE_POSE',
                desired_pose=a.tolist(), observed_pose=b.tolist(), comparison='EXACT_SDK_FLOAT32_COORDINATES',
                approximate_tolerance_used=False, physical_restart_admitted=False)


def restore_pose_if_changed(desired, observed, writer):
    """Caller supplies an authorized SDK writer; the helper grants no write scope."""
    decision = pose_decision(desired, observed)
    if decision['status'] == 'WRITE_POSE':
        writer(decision['desired_pose'])
    return decision


class StateWritesDisabled:
    """Reject state/property setters before forwarding in both zero-write arms."""
    active = False
    def __init__(self, cursor):
        if type(cursor) is not int or cursor < 0:
            raise ValueError('explicit cursor required')
        self.cursor, self.broken, self.events = cursor, False, []

    def invoke(self, entity, method, forward, *args, **kwargs):
        self.broken = True
        self.events.append(dict(entity=entity, method=method, allowed=False,
                                source_cursor=self.cursor, status='DENIED_NOT_FORWARDED'))
        raise RuntimeError('state/property writes disabled for this condition')

    def receipt(self):
        return dict(schema='chemrm-v98-zero-state-write-fence', declared_source_cursor=self.cursor,
                    window_consumed=False, window_open=False, broken=self.broken, planned_calls=0,
                    remaining_calls=0, events=copy.deepcopy(self.events), physical_restart_admitted=False,
                    scientific_admission=False, training_admission=False)
