"""Astra proposal boundary; no provider transport or native actuator is implied.

The provider callable must resolve actual public images separately. This module
validates inputs and records requests, transport errors and bounded proposals.
Neither a model response nor an accepted action is a physical success receipt.
"""
import fcntl
import json
import math
from pathlib import Path
import re

from chemrm.papera.collection_engine_v70 import encoded, identity, publish
from chemrm.papera.isaac_bridge_contract import Action


def public_observation(*, track, instruction, joints_q, images, current_clock_s):
    if track not in {'A','B','C'}:
        raise ValueError('unknown observation track')
    if not isinstance(instruction, dict) or set(instruction)-{'text','duration_s','tolerance_s'} or 'text' not in instruction:
        raise ValueError('public instruction fields only; no event truth')
    if not isinstance(instruction['text'], str) or not 1<=len(instruction['text'])<=8192:
        raise ValueError('bounded public instruction required')
    for key in set(instruction)-{'text'}:
        v = instruction[key]
        if type(v) not in (float,int) or not math.isfinite(v) or v<0:
            raise ValueError('finite public timing instruction required')
    if not isinstance(joints_q, (list,tuple)) or len(joints_q)!=9 or any(
            type(v) not in (int,float) or not math.isfinite(v) for v in joints_q):
        raise ValueError('nine finite measured joint positions required')
    if not isinstance(images, list) or not 1<=len(images)<=5:
        raise ValueError('one to five actual public image bindings required')
    seen = set()
    for image in images:
        if not isinstance(image,dict) or set(image)!={'view','sha256'}:
            raise ValueError('public image binding cannot contain hidden state or clock')
        if image['view'] not in {'station','front','side','top','wrist'} or image['view'] in seen:
            raise ValueError('unique declared camera view required')
        if not isinstance(image['sha256'],str) or not re.fullmatch(r'[a-f0-9]{64}',image['sha256']):
            raise ValueError('actual image content digest required')
        seen.add(image['view'])
    if type(current_clock_s) not in (int,float) or not math.isfinite(current_clock_s) or current_clock_s<0:
        raise ValueError('finite current shared clock required internally')
    actor = dict(instruction=instruction, joints_q=list(joints_q), images=images)
    if track in {'B','C'}:
        actor['timestamp_s'] = float(current_clock_s)
    actor = json.loads(encoded(actor))  # Own the packet; do not retain caller aliases.
    return dict(actor=actor, sha256=identity(actor), track=track)


class PlannerSession:
    def __init__(self, root, *, request_limit, token_limit, transport_mode):
        if type(request_limit) is not int or not 1<=request_limit<=10000 or type(token_limit) is not int or token_limit<1:
            raise ValueError('bounded typed request/token budget required')
        if transport_mode not in {'TEST_DOUBLE','LIVE_PROVIDER'}:
            raise ValueError('explicit transport provenance required')
        self.root = Path(root)
        self.config = dict(schema='chemrm-astra-proposal-boundary-v70', request_limit=request_limit,
                           token_limit=token_limit, transport_mode=transport_mode, model='gpt-6-astra')

    def __enter__(self):
        self.root.mkdir(parents=True, exist_ok=True)
        self.owner = (self.root/'owner.lock').open('a+b')
        try:
            fcntl.flock(self.owner, fcntl.LOCK_EX|fcntl.LOCK_NB)
        except BlockingIOError:
            self.owner.close()
            raise ValueError('another planner owner is active') from None
        path = self.root/'config.json'
        if not path.exists():
            publish(path,encoded(self.config))
        elif json.loads(path.read_bytes())!=self.config:
            self.owner.close()
            raise ValueError('planner budget/provenance cannot change on reopen')
        return self

    def __exit__(self, *args):
        self.owner.close()

    def summary(self):
        requests = sorted(self.root.glob('*.request.json'))
        receipts = []
        unresolved = 0
        for index, path in enumerate(requests):
            if path.name != f'{index:04d}.request.json':
                raise ValueError('planner request sequence mismatch')
            receipt = self.root/f'{index:04d}.response.json'
            if receipt.exists():
                receipts.append(json.loads(receipt.read_bytes()))
            else:
                unresolved += 1
        responses = [r for r in receipts if r['provider_response_observed']]
        return dict(requests=len(requests), provider_responses=len(responses),
            validated_proposals=sum(r['status']=='VALIDATED_PROPOSAL_ONLY' for r in receipts),
            unresolved_requests=unresolved, unknown_billing_receipts=sum(r['billed_tokens'] is None for r in receipts),
            known_billed_tokens=sum(r['billed_tokens'] or 0 for r in receipts),
            live_astra_calls=len(responses) if self.config['transport_mode']=='LIVE_PROVIDER' else 0,
            physical_executions=0, scientific_admission=False, training_admitted=False)

    def request(self, observation, invoke):
        # Revalidate instead of trusting an arbitrary mapping at this boundary.
        if not isinstance(observation,dict) or set(observation)!={'actor','sha256','track'}:
            raise ValueError('typed public observation required')
        actor = observation['actor']
        if set(actor)-{'instruction','joints_q','images','timestamp_s'}:
            raise ValueError('unexpected public actor fields')
        if observation['track']=='A' and 'timestamp_s' in actor:
            raise ValueError('track A cannot receive a clock')
        checked = public_observation(track=observation['track'], instruction=actor['instruction'],
            joints_q=actor['joints_q'], images=actor['images'],
            current_clock_s=0.0 if observation['track']=='A' else actor['timestamp_s'])
        if checked != observation:
            raise ValueError('public observation content/hash mismatch')
        summary = self.summary()
        if summary['requests']>=self.config['request_limit'] or summary['known_billed_tokens']>=self.config['token_limit']:
            raise ValueError('planner budget exhausted')
        if summary['unresolved_requests'] or summary['unknown_billing_receipts']:
            raise ValueError('unresolved request or billing requires reconciliation, not blind retry')
        index = summary['requests']
        publish(self.root/f'{index:04d}.request.json',encoded(dict(index=index,observation=checked,
            transport_mode=self.config['transport_mode'], model=self.config['model'])))
        receipt = dict(index=index, observation_sha256=checked['sha256'],
            transport_mode=self.config['transport_mode'], status='TRANSPORT_FAILURE',
            provider_response_observed=False, billed_tokens=None,
            physical_execution_observed=False, scientific_admission=False, training_admitted=False)
        try:
            response = invoke(json.loads(encoded(checked)))
        except Exception as error:
            # Provider exception strings may contain credentials/request contents.
            receipt['error_class'] = type(error).__name__ if type(error).__name__ in {
                'ConnectionError','TimeoutError','ValueError','RuntimeError'} else 'ProviderError'
        else:
            receipt['status'] = 'PROPOSAL_REJECTED'
            try:
                if not isinstance(response,dict) or len(encoded(response))>32768 or set(response)!={
                        'model','response_id','input_tokens','output_tokens','proposal'}:
                    raise ValueError('bounded typed provider response required')
                if response['model']!=self.config['model'] or not isinstance(response['response_id'],str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}',response['response_id']):
                    raise ValueError('provider model/response identity mismatch')
                for key in ('input_tokens','output_tokens'):
                    if type(response[key]) is not int or response[key]<0:
                        raise ValueError('observed nonnegative token counts required')
                receipt.update(provider_response_observed=True, model=response['model'],
                    response_id=response['response_id'], billed_tokens=response['input_tokens']+response['output_tokens'])
                proposal = response['proposal']
                if not isinstance(proposal,dict) or set(proposal)!={'observation_sha256','actions'} or proposal['observation_sha256']!=checked['sha256']:
                    raise ValueError('proposal must bind the current public observation')
                actions = proposal['actions']
                if not isinstance(actions,list) or not 1<=len(actions)<=3:
                    raise ValueError('one to three legal tool actions required')
                actions = [Action.from_dict(a).to_dict() for a in actions]
                if summary['known_billed_tokens']+receipt['billed_tokens']>self.config['token_limit']:
                    receipt['status'] = 'REJECTED_TOKEN_BUDGET_EXCEEDED'
                else:
                    receipt.update(status='VALIDATED_PROPOSAL_ONLY', actions=actions)
            except (ValueError,TypeError,KeyError,RecursionError):
                receipt['rejection_code'] = 'INVALID_PROVIDER_RECEIPT_OR_ACTION'
        publish(self.root/f'{index:04d}.response.json',encoded(receipt))
        return receipt
