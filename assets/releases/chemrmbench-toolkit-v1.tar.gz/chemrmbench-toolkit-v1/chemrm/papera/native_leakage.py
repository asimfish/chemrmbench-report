"""Frozen bank and sensor-only probes for a finite native leakage diagnostic.

Private labels are for supervised audit, never arguments to sensor_features.
All splits are by complete scene block, stricter than the historical frame CV gate.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np

from chemrm.papera.isaac_bridge_contract import Case

SCHEMA = 'papera-native-leakage-v1'
AGES = [4., 15., 35., 65.]
CHANNELS = ['rgb', 'joints', 'rgb_joints']
ALPHAS = [1e-4, 1e-2, 1.]


def dump(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(data, indent=2, sort_keys=True, allow_nan=False) + '\n')
    temp.replace(path)


def build_bank():
    geometry = np.random.default_rng(161008)
    timing = np.random.default_rng(261008)
    order = np.random.default_rng(361008)
    scenes, cases = [], []
    for i in range(48):
        split = 'train' if i < 16 else 'dev' if i < 24 else 'future'
        scene_id = f'scene_{i:03d}'
        x, spacing, height = geometry.uniform(.4, .55), geometry.uniform(.12, .18), geometry.uniform(1.5, 2.1)
        onset = float(timing.integers(300, 2401)) / 60.
        scene = {'scene_id': scene_id, 'split': split, 'scene_x': float(x),
                 'spacing': float(spacing), 'camera_height': float(height), 'onset_s': onset}
        scenes.append(scene)
        for target in order.permutation(5).tolist():
            case = Case(case_id=f'{scene_id}_t{target}', family='C13',
                        split='future' if split == 'future' else 'dev', seed=161008 + i,
                        target=target, onset_s=onset, wait_s=60., eta=.15, latency_s=0.,
                        scene_x=float(x), spacing=float(spacing), camera_height=float(height),
                        equivalence_ml=10.)
            cases.append({'scene_id': scene_id, 'split': split, 'case': case.to_dict()})
    return {'schema': SCHEMA, 'ages_s': AGES, 'fixed_query_s': 110.,
            'scenes': scenes, 'cases': cases, 'alphas': ALPHAS, 'channels': CHANNELS}


def require_disjoint_scenes(rows):
    seen = {}
    for row in rows:
        scene, split = row['scene_id'], row['split']
        if scene in seen and seen[scene] != split:
            raise ValueError('scene crosses train/development/future boundary')
        seen[scene] = split


def validate_bank(bank):
    if bank.get('schema') != SCHEMA or bank.get('ages_s') != AGES or bank.get('fixed_query_s') != 110.:
        raise ValueError('invalid bank schema/query schedule')
    if bank.get('channels') != CHANNELS or bank.get('alphas') != ALPHAS:
        raise ValueError('probe specification differs')
    if len(bank['scenes']) != 48 or len(bank['cases']) != 240:
        raise ValueError('incomplete bank')
    require_disjoint_scenes(bank['cases'])
    if len({r['scene_id'] for r in bank['scenes']}) != 48:
        raise ValueError('duplicate scene')
    if len({r['case']['case_id'] for r in bank['cases']}) != 240:
        raise ValueError('duplicate episode')
    counts = {'train': 0, 'dev': 0, 'future': 0}
    for scene in bank['scenes']:
        counts[scene['split']] += 1
        rows = [r for r in bank['cases'] if r['scene_id'] == scene['scene_id']]
        if sorted(r['case']['target'] for r in rows) != list(range(5)):
            raise ValueError('unbalanced target pairing')
        for row in rows:
            case = Case(**row['case'])
            if row['split'] != scene['split'] or case.split != ('future' if row['split'] == 'future' else 'dev'):
                raise ValueError('split differs from scene')
            for key in ('scene_x', 'spacing', 'camera_height', 'onset_s'):
                if getattr(case, key) != scene[key]:
                    raise ValueError('counterfactual geometry/timing differs')
    if counts != {'train': 16, 'dev': 8, 'future': 24}:
        raise ValueError('wrong scene split sizes')


def sensor_features(rgb, joints, channel):
    """No metadata, timestamps, history, label or episode identifier accepted."""
    if not isinstance(rgb, np.ndarray) or rgb.dtype != np.uint8 or rgb.shape != (320, 320, 3):
        raise ValueError('expected native uint8 RGB')
    joints = np.asarray(joints, dtype=np.float64)
    if joints.shape != (9,) or not np.isfinite(joints).all():
        raise ValueError('expected nine finite native joints')
    pixels = rgb.reshape(20, 16, 20, 16, 3).mean(axis=(1, 3)).reshape(-1) / 255.
    if channel == 'rgb':
        return pixels
    if channel == 'joints':
        return joints.copy()
    if channel == 'rgb_joints':
        return np.concatenate([pixels, joints])
    raise ValueError('unknown sensor channel')


class RidgeProbe:
    def __init__(self, alpha=.01):
        if isinstance(alpha, bool) or not math.isfinite(alpha) or alpha <= 0:
            raise ValueError('regularisation must be positive and finite')
        self.alpha = float(alpha)

    @staticmethod
    def expand(x):
        x = np.asarray(x, dtype=np.float64)
        if x.ndim != 2 or not np.isfinite(x).all():
            raise ValueError('finite feature matrix required')
        return np.concatenate([x, x * x], axis=1)

    def fit(self, x, y):
        x = self.expand(x)
        y = np.asarray(y, dtype=np.float64)
        if y.ndim not in (1, 2) or len(y) != len(x) or len(y) < 2 or not np.isfinite(y).all():
            raise ValueError('invalid probe labels')
        self.mean = x.mean(axis=0)
        sd = x.std(axis=0)
        self.scale = np.where(sd > 1e-12, sd, 1.)
        z = (x - self.mean) / self.scale
        self.intercept = y.mean(axis=0)
        centered = y - self.intercept
        n, d = z.shape
        # Algebraically identical primal/dual ridge; avoid large pixel inversions.
        if d <= n:
            self.weight = np.linalg.solve(z.T @ z + self.alpha * n * np.eye(d), z.T @ centered)
        else:
            self.weight = z.T @ np.linalg.solve(z @ z.T + self.alpha * n * np.eye(n), centered)
        return self

    def predict(self, x):
        z = (self.expand(x) - self.mean) / self.scale
        pred = z @ self.weight + self.intercept
        if not np.isfinite(pred).all():
            raise ValueError('nonfinite probe prediction')
        return pred

    def save(self, path):
        np.savez(path, alpha=self.alpha, mean=self.mean, scale=self.scale,
                 intercept=self.intercept, weight=self.weight)

    @classmethod
    def load(cls, path):
        with np.load(path, allow_pickle=False) as data:
            model = cls(float(data['alpha']))
            for field in ('mean', 'scale', 'intercept', 'weight'):
                setattr(model, field, data[field].copy())
        return model


def r_squared(y, pred):
    y, pred = np.asarray(y, dtype=float), np.asarray(pred, dtype=float)
    if y.shape != pred.shape or y.ndim != 1 or not np.isfinite(y).all() or not np.isfinite(pred).all():
        raise ValueError('invalid regression vectors')
    total = float(np.sum((y - y.mean()) ** 2))
    if total <= 0:
        raise ValueError('constant clock target')
    return 1. - float(np.sum((y - pred) ** 2)) / total


def scene_bootstrap(y, pred, scene, metric, draws=2000):
    y, pred, scene = np.asarray(y), np.asarray(pred), np.asarray(scene)
    groups = np.unique(scene)
    if y.shape != pred.shape or y.shape != scene.shape or len(groups) < 2:
        raise ValueError('at least two complete scene blocks required')
    if metric not in {'accuracy', 'r2'} or type(draws) is not int or draws < 1:
        raise ValueError('invalid bootstrap request')
    rng = np.random.default_rng(161008)
    scores = []
    rows = [np.where(scene == g)[0] for g in groups]
    for _ in range(draws):
        idx = np.concatenate([rows[i] for i in rng.integers(0, len(groups), len(groups))])
        scores.append(float(np.mean(y[idx] == pred[idx])) if metric == 'accuracy'
                      else r_squared(y[idx], pred[idx]))
    return np.quantile(scores, [.025, .975]).tolist()
