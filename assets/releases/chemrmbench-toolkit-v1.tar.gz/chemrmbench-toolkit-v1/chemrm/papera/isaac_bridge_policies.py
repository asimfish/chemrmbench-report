"""Frozen hand-coded resource controls, not learned VLA/memory baselines."""
from __future__ import annotations
import numpy as np
from chemrm.papera.isaac_bridge_contract import Action, TRACKS


def visual_features(rgb: np.ndarray) -> dict:
    r,g,b=[rgb[:,:,i].astype(float) for i in range(3)]
    band=np.zeros(r.shape,dtype=bool); band[110:195]=True
    status_band=np.zeros(r.shape,dtype=bool); status_band[30:135]=True
    green=(g>90)&(g>1.35*r)&(g>1.35*b)&band
    red=(r>90)&(r>1.35*g)&(r>1.35*b)&band
    pink=(r>100)&(b>90)&(r>1.8*g)&(b>1.8*g)&(b>.65*r)&(r>.65*b)&band
    blue=(b>100)&(b>1.6*r)&(b>1.6*g)&status_band
    # Five colored bench markers have separated horizontal projections.
    columns=np.where((red|green).sum(axis=0)>=2)[0]
    groups=np.split(columns,np.where(np.diff(columns)>2)[0]+1) if len(columns) else []
    centers=[float(x.mean()) for x in groups if len(x)>=3]
    target=None
    if green.sum()>=12 and len(centers)==5:
        gx=float(np.where(green)[1].mean())
        target=int(np.argmin(np.abs(np.array(centers)-gx)))
    return {'green_slot':target,'green_pixels':int(green.sum()),
            'marker_count':len(centers),'pink':bool(pink.sum()>=12),
            'blue':bool(blue.sum()>=12)}


class ReferencePolicy:
    def __init__(self, policy_id: str):
        if policy_id not in TRACKS: raise ValueError('unknown frozen policy')
        self.policy_id=policy_id
        self.track=TRACKS[policy_id]
        self.step=0; self.target=None; self.start=None; self.issued=False

    def act(self, obs):
        feature=visual_features(obs['rgb']); family=obs['instruction']['family']
        now=float(self.step) if self.track=='A' else obs['timestamp_s']
        self.step+=1
        delay=obs.get('latency_budget_s',0.)
        if family=='C13':
            slot=feature['green_slot']
            if self.policy_id=='reactive_A':
                if slot is not None and not self.issued:
                    self.issued=True; return Action('add_B',slot)
                return Action('wait')
            if slot is not None and self.target is None:
                self.target=slot; self.start=now
            duration=obs['instruction']['duration_s']
            # Development-only fixed skill lead. No access to hidden onset or slot.
            if self.target is not None and not self.issued and slot is None and now-self.start>=duration-1.-delay:
                self.issued=True; return Action('add_B',self.target)
        elif family=='C5':
            if feature['pink'] and not self.issued:
                self.issued=True; return Action('add_stop',0)
        else:
            if self.step==1: return Action('stir_start',0)
            if feature['blue'] and self.start is None: self.start=now
            if self.start is not None and not self.issued:
                if self.policy_id=='reactive_A' or now-self.start>=120.-delay:
                    self.issued=True; return Action('stir_stop',0)
        return Action('wait')
