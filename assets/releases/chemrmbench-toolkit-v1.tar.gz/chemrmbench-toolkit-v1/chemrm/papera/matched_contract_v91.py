"""Independent predeclared clock branches from one unused committed header.

Forking this logical ledger does not fork a physical simulation, attest an
event sensor, or create independent statistical repetitions.
"""
from pathlib import Path
import shutil

from .staged_collection import digest,write_once
from .task_clock_v88 import TaskClockLedger


BRANCHES=('no_fault','recovery','expired')


def fork_timer(template,destination,branch):
    if branch not in BRANCHES:raise ValueError('predeclared branch required')
    template=Path(template);destination=Path(destination)
    ledger=TaskClockLedger(template);header=ledger._header()
    if header['attempt_labels']!=['first','retry']:raise ValueError('shared matched attempt plan required')
    if (template/'attempts').exists():raise ValueError('cannot fork an already used timer')
    destination.mkdir(parents=True,exist_ok=False)
    for name in ('HEADER.json','HEADER_COMMITTED.json'):
        shutil.copyfile(template/name,destination/name)
        if digest(template/name)!=digest(destination/name):raise ValueError('forked header differs')
    write_once(destination/'BRANCH_SOURCE.json',dict(schema='chemrm-matched-clock-branch-v91',
        branch=branch,shared_header_sha256=digest(template/'HEADER.json'),
        checkpoint_sha256=header['checkpoint_sha256'],
        shared_original_event=True,attempt_time_shared_across_branches=False,
        independent_statistical_repetition=False,scientific_admission=False))
    return TaskClockLedger(destination)
