"""Typed boundary for the native engineering pilot (not a released F2/F3 bank)."""
from __future__ import annotations

from dataclasses import dataclass, asdict
import math
import re
from types import MappingProxyType
from typing import Any, Mapping, Protocol

import numpy as np


SCHEMA = 'papera-native-bridge-v1'
TRACKS = {'reactive_A': 'A', 'frame_memory_A': 'A', 'timestamp_B': 'B',
          'latency_timer_C': 'C'}


@dataclass(frozen=True)
class Case:
    case_id: str
    family: str
    split: str
    seed: int
    target: int
    onset_s: float
    wait_s: float
    eta: float
    latency_s: float
    scene_x: float
    spacing: float
    camera_height: float
    equivalence_ml: float

    def __post_init__(self):
        if not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', self.case_id):
            raise ValueError('invalid case identifier')
        if self.family not in {'C13','C5','C6'} or self.split not in {'dev','future'}:
            raise ValueError('unknown family/split')
        if type(self.seed) is not int or not 0 <= self.seed < 2**32:
            raise ValueError('invalid seed')
        if type(self.target) is not int or not 0 <= self.target < 5:
            raise ValueError('invalid vessel')
        bounds = {'onset_s': (5.,40.), 'wait_s': (30.,90.), 'eta': (.15,.15),
                  'latency_s': (0.,5.), 'scene_x': (.4,.55), 'spacing': (.12,.18),
                  'camera_height': (1.5,2.1), 'equivalence_ml': (8.,12.)}
        for field, (lo,hi) in bounds.items():
            value = getattr(self,field)
            if isinstance(value,bool) or not isinstance(value,(int,float)) or not math.isfinite(value) or not lo <= value <= hi:
                raise ValueError(f'invalid {field}')

    def to_dict(self) -> dict:
        return asdict(self)

    def tool_target(self, slot: int) -> list[float]:
        return [self.scene_x, (2-slot)*self.spacing, .23]

    def instruction(self) -> Mapping[str, Any]:
        # No hidden seed, case identifier, selected vessel, onset or endpoint time.
        return MappingProxyType({'family':self.family, 'vessel_order':'left_to_right',
            'duration_s':self.wait_s if self.family=='C13' else 120. if self.family=='C6' else None,
            'tolerance_s':self.eta*self.wait_s if self.family=='C13' else 10. if self.family=='C6' else 2.,
            'text': {'C13':'Remember the green vessel. After the cue disappears, add B to it at the instructed interval from cue onset.',
                     'C5':'Stop titrant when the indicator becomes pink, within two seconds.',
                     'C6':'Start stirring vessel 0; stop after 120 seconds, within ten seconds.'}[self.family]})


@dataclass(frozen=True)
class Action:
    kind: str
    slot: int | None = None

    def __post_init__(self):
        if self.kind not in {'wait','add_B','add_stop','stir_start','stir_stop'}:
            raise ValueError('unknown action kind')
        if self.kind == 'wait':
            if self.slot is not None: raise ValueError('wait has no slot')
        elif type(self.slot) is not int or not 0 <= self.slot < 5:
            raise ValueError('slot must be an integer in [0,4]')
        if self.kind in {'add_stop','stir_start','stir_stop'} and self.slot != 0:
            raise ValueError('C5/C6 act on vessel 0')

    @classmethod
    def from_dict(cls, raw: Mapping) -> 'Action':
        if not isinstance(raw,Mapping) or set(raw)-{'kind','slot'} or 'kind' not in raw:
            raise ValueError('invalid action fields')
        return cls(**raw)

    def to_dict(self):
        return {'kind':self.kind} if self.slot is None else asdict(self)


@dataclass(frozen=True)
class Snapshot:
    rgb: np.ndarray
    joints: np.ndarray
    captured_at: float
    rendered_at: float


class PixelBackend(Protocol):
    """Environment dependency; implementations own clocks and audit events."""
    events: list[dict]
    done: bool
    @property
    def now(self) -> float: ...
    def reset(self, case: Case) -> None: ...
    def capture(self) -> Snapshot: ...
    def advance(self, seconds: float) -> None: ...
    def submit(self, action: Action, capture_t: float, action_seq: int) -> None: ...


def actor_observation(case: Case, rgb: np.ndarray, joints: np.ndarray,
                      captured_at: float, track: str) -> Mapping:
    if track not in {'A','B','C'}:
        raise ValueError('invalid track')
    if rgb.dtype != np.uint8 or rgb.shape != (320,320,3):
        raise ValueError('RGB must be uint8 [320,320,3]')
    if joints.shape != (9,) or not np.isfinite(joints).all():
        raise ValueError('invalid proprioception')
    if not math.isfinite(captured_at) or captured_at < 0:
        raise ValueError('invalid capture timestamp')
    r = rgb.copy(); r.setflags(write=False)
    j = joints.copy(); j.setflags(write=False)
    data = {'rgb':r, 'joints':j, 'instruction':case.instruction()}
    if track in {'B','C'}: data['timestamp_s'] = float(captured_at)
    if track == 'C': data['latency_budget_s'] = float(case.latency_s)
    return MappingProxyType(data)
