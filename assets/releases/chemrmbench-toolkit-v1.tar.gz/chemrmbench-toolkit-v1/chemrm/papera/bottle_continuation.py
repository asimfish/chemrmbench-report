"""Released bottle boundary and a pinned controller cursor, not agent memory."""
import math
import numpy as np


def resume_cursor(context, policy_sha256, stage_plan, original_goal):
    required = {'schema','policy_sha256','completed_stages','next_stage',
                'next_command_index','original_return_goal','context_kind'}
    if (set(context) != required or context['schema'] != 'chemrm-bottle-cursor-v1'
            or context['context_kind'] != 'PINNED_EXPERT_CONTROLLER_ONLY'
            or context['policy_sha256'] != policy_sha256):
        raise ValueError('pinned controller identity required')
    ids = [s['id'] for s in stage_plan]
    boundary = ids.index('place_release')
    if (context['completed_stages'] != ids[:boundary+1]
            or context['next_stage'] != ids[boundary+1]
            or type(context['next_command_index']) is not int
            or context['next_command_index'] != stage_plan[boundary]['end_tick']
            or stage_plan[boundary+1]['start_tick'] != context['next_command_index']):
        raise ValueError('completed prefix, next stage and command cursor disagree')
    goal = context['original_return_goal']
    if (not isinstance(goal,list) or len(goal)!=3
            or any(isinstance(x,bool) or not isinstance(x,(int,float)) or not math.isfinite(x) for x in goal)
            or goal != list(original_goal)):
        raise ValueError('original return goal must survive reconstruction')
    return context['next_command_index']


def released_boundary(rows, contacts, object_prim, robot_prim, dt_s, grasp_width_m, goal):
    """Require 0.5 s without loaded fingers and bounded bottle pose before sealing."""
    count = math.ceil(.5 / dt_s)
    if len(rows) != len(contacts) or len(rows) < count:
        raise ValueError('complete released dwell evidence required')
    tail, contact_tail = rows[-count:], contacts[-count:]
    for i, (state, contact) in enumerate(zip(tail,contact_tail)):
        if state['command_index'] != contact['tick']:
            raise ValueError('state and contact clocks disagree')
        if abs(state['native_after_s']-state['native_before_s']-dt_s)>1e-7:
            raise ValueError('one actual integration per release sample required')
        if i and abs(tail[i-1]['native_after_s']-state['native_before_s'])>1e-9:
            raise ValueError('release dwell cannot cross a native clock gap')
    loaded = 0
    for row in contact_tail:
        for c in row['contacts']:
            paths=[c[k] for k in ('actor0','actor1','collider0','collider1')]
            target=any(p==object_prim or p.startswith(object_prim+'/') for p in paths)
            finger=any(p.startswith(robot_prim+'/') and 'finger' in p for p in paths)
            if target and finger and np.linalg.norm(c['impulse'])>1e-8:
                loaded+=1
    poses=np.asarray([r['object_pose'] for r in tail],dtype=float)
    if poses.shape!=(count,7) or not np.isfinite(poses).all():
        raise ValueError('finite observed bottle poses required')
    quats=poses[:,3:];norms=np.linalg.norm(quats,axis=1)
    if (norms<1e-12).any():raise ValueError('nonzero bottle quaternions required')
    quats=quats/norms[:,None]
    angles=2*np.arccos(np.clip(np.abs(quats@quats[-1]),0,1))
    drift=float(np.linalg.norm(poses[:,:3]-poses[-1,:3],axis=1).max())
    width=min(r['jaw_width_m'] for r in tail)
    goal_error=float(np.linalg.norm(poses[-1,:3]-np.asarray(goal)))
    passed=(loaded==0 and drift<=.001 and angles.max()<=math.radians(.5)
            and width>=grasp_width_m+.003 and goal_error<=.02)
    return dict(status='PASS_RELEASED_BOTTLE_BOUNDARY' if passed else 'BLOCKED_RELEASED_BOTTLE_BOUNDARY',
        sampled_dwell_s=count*dt_s, sample_count=count, loaded_finger_contacts=loaded,
        maximum_position_drift_mm=drift*1000, maximum_orientation_drift_deg=math.degrees(float(angles.max())),
        minimum_jaw_width_m=width, release_goal_error_mm=goal_error*1000,
        context_kind='PINNED_EXPERT_CONTROLLER_ONLY', agent_memory_verified=False,
        continuous_physical_dwell_claim=False, scientific_admission=False)
