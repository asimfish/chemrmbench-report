"""One declared restoration window for a pinned native experiment.

This audits the named public SDK state/property writers; it is not a sandbox
against arbitrary Python or a physical-restart admission mechanism.
"""
from contextlib import contextmanager
import copy

METHODS = frozenset(('write_root_pose_to_sim', 'write_root_velocity_to_sim',
                     'write_joint_state_to_sim', 'write_joint_stiffness_to_sim',
                     'write_joint_damping_to_sim', 'write_joint_effort_limit_to_sim',
                     'set_joint_position_target', 'set_joint_velocity_target',
                     'set_joint_effort_target'))


class BoundaryWriteFence:
    def __init__(self, cursor, planned_calls):
        if type(cursor) is not int or cursor < 0:
            raise ValueError('explicit nonnegative source cursor required')
        calls = list(planned_calls)
        if (not 1 <= len(calls) <= 4096 or
                any(type(x) is not tuple or len(x) != 2 or
                    type(x[0]) is not str or not x[0] or type(x[1]) is not str or
                    x[1] not in METHODS for x in calls)):
            raise ValueError('unique bounded entity/writer plan required')
        if len(calls) != len(set(calls)):
            raise ValueError('unique bounded entity/writer plan required')
        self.cursor = cursor
        self.plan = frozenset(calls)
        self.remaining = set(calls)
        self.active = False
        self.consumed = False
        self.broken = False
        self.events = []

    @contextmanager
    def restore_at(self, cursor):
        if type(cursor) is not int or cursor != self.cursor or self.active or self.consumed:
            self.broken = True
            raise RuntimeError('restoration window is unavailable at this cursor')
        if self.broken:
            raise RuntimeError('prior invalid state write poisons the trial')
        self.consumed = self.active = True
        try:
            yield
            if self.remaining or self.broken:
                raise RuntimeError('declared restoration is incomplete or invalid')
        finally:
            self.active = False

    def invoke(self, entity, method, forward, *args, **kwargs):
        key = (entity, method)
        if not self.active or self.broken or key not in self.remaining:
            self.broken = True
            self.events.append(dict(entity=entity, method=method, allowed=False,
                                    source_cursor=self.cursor, status='DENIED_NOT_FORWARDED'))
            raise RuntimeError('state/property write outside the declared restoration plan')
        self.remaining.remove(key)
        event = dict(entity=entity, method=method, allowed=True,
                     source_cursor=self.cursor, status='STARTED')
        self.events.append(event)
        try:
            value = forward(*args, **kwargs)
        except BaseException:
            self.broken = True
            event['status'] = 'FAILED'
            raise
        event['status'] = 'COMPLETED'
        return value

    def receipt(self):
        return dict(schema='chemrm-v95-declared-boundary-write-fence',
                    declared_source_cursor=self.cursor, window_consumed=self.consumed,
                    window_open=self.active, broken=self.broken,
                    planned_calls=len(self.plan), remaining_calls=len(self.remaining),
                    events=copy.deepcopy(self.events), physical_restart_admitted=False,
                    scientific_admission=False, training_admission=False)
