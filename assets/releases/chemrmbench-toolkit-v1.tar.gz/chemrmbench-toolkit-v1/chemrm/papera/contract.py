"""Serializable Paper A traces, verdicts and evidence bundles.

The file layout is part of the benchmark contract.  A bundle is useful only when another
operator can verify its hashes and replay the read-only verdict inputs without access to the
world or the policy.  JSON conversion is deliberately conservative so accidental numpy/tensor
objects fail at the boundary instead of being stringified into unverifiable evidence.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Mapping, Sequence

from chemrm.events import Event
from chemrm.task_program import TaskProgram


SCHEMA_VERSION = "paper-a-f0.1"
REQUIRED_ARTIFACTS = (
    "task.json",
    "observations.jsonl",
    "actions.jsonl",
    "events.jsonl",
    "verdict.json",
)


def _jsonable(value: Any) -> Any:
    """Return JSON-compatible data or fail closed for unsupported values."""
    if value is None or isinstance(value, (str, int, bool)):
        return value
    if isinstance(value, float):
        if not math.isfinite(value):
            raise ValueError("non-finite floats are not valid evidence values")
        return value
    if isinstance(value, Mapping):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    raise TypeError(f"value of type {type(value).__name__} is not JSON-compatible")


def _dump_json(path: Path, data: Any) -> None:
    path.write_text(json.dumps(_jsonable(data), ensure_ascii=False, sort_keys=True, indent=2) + "\n",
                    encoding="utf-8")


@dataclass(frozen=True)
class ObservationRecord:
    step: int
    t: float
    payload: Mapping[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {"step": int(self.step), "t": float(self.t), "observation": _jsonable(self.payload)}


@dataclass(frozen=True)
class ActionRecord:
    step: int
    t: float
    payload: Mapping[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {"step": int(self.step), "t": float(self.t), "action": _jsonable(self.payload)}


@dataclass(frozen=True)
class Trace:
    """The only input exposed to a Paper A verifier.

    Hidden world state never appears here.  Events are the world-owned audit stream; observations
    and actions are the policy-facing trace.  ``error`` records an invalid policy/world boundary
    and causes a fail-closed verdict.
    """

    task: TaskProgram
    seed: int
    policy_id: str
    policy_hash: str
    verifier_id: str
    observations: tuple[ObservationRecord, ...]
    actions: tuple[ActionRecord, ...]
    events: tuple[Event, ...]
    end_time: float
    completed: bool
    stop_reason: str
    error: str | None = None

    def validate(self) -> None:
        if not self.policy_id or not self.policy_hash or not self.verifier_id:
            raise ValueError("policy_id, policy_hash and verifier_id are required")
        if self.seed < 0:
            raise ValueError("seed must be non-negative")
        if self.end_time < 0:
            raise ValueError("end_time must be non-negative")
        if len(self.observations) != len(self.actions):
            raise ValueError("every policy action must have exactly one preceding observation")
        expected = tuple(range(len(self.actions)))
        if tuple(r.step for r in self.observations) != expected or tuple(r.step for r in self.actions) != expected:
            raise ValueError("trace steps must be contiguous and zero-based")
        if any(b.t < a.t for a, b in zip(self.events, self.events[1:])):
            raise ValueError("events must be in non-decreasing timestamp order")
        if any(ev.t > self.end_time + 1e-9 for ev in self.events):
            raise ValueError("event occurs after trace end_time")
        if self.completed and not self.stop_reason:
            raise ValueError("completed traces need a stop_reason")

    def task_dict(self) -> dict[str, Any]:
        return self.task.to_dict()


@dataclass(frozen=True)
class EpisodeVerdict:
    """Versioned pass/failure vector emitted by the independent verifier."""

    verifier_id: str
    pass_vector: Mapping[str, bool]
    failure_vector: tuple[Mapping[str, Any], ...] = ()
    metrics: Mapping[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "verifier_id": self.verifier_id,
            "pass_vector": {str(k): bool(v) for k, v in self.pass_vector.items()},
            "failure_vector": [_jsonable(x) for x in self.failure_vector],
            "metrics": _jsonable(self.metrics),
        }

    @property
    def valid(self) -> bool:
        return bool(self.pass_vector.get("valid", False))


@dataclass(frozen=True)
class BundleCheck:
    ok: bool
    errors: tuple[str, ...] = ()
    files: tuple[str, ...] = ()


class EvidenceBundle:
    """Write the canonical Paper A evidence files for one episode."""

    @staticmethod
    def write(out_dir: str | Path, trace: Trace, verdict: EpisodeVerdict) -> Path:
        trace.validate()
        if verdict.verifier_id != trace.verifier_id:
            raise ValueError("trace and verdict verifier ids differ")
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)

        _dump_json(out / "task.json", trace.task_dict())
        (out / "observations.jsonl").write_text(
            "".join(json.dumps(r.to_dict(), ensure_ascii=False, sort_keys=True) + "\n" for r in trace.observations),
            encoding="utf-8",
        )
        (out / "actions.jsonl").write_text(
            "".join(json.dumps(r.to_dict(), ensure_ascii=False, sort_keys=True) + "\n" for r in trace.actions),
            encoding="utf-8",
        )
        (out / "events.jsonl").write_text(
            "".join(json.dumps({"kind": e.kind, "t": e.t, "payload": _jsonable(e.payload)},
                                ensure_ascii=False, sort_keys=True) + "\n" for e in trace.events),
            encoding="utf-8",
        )
        _dump_json(out / "verdict.json", verdict.to_dict())

        artifacts = {
            "schema_version": SCHEMA_VERSION,
            "files": {name: _file_digest(out / name) for name in REQUIRED_ARTIFACTS},
        }
        _dump_json(out / "artifacts.json", artifacts)
        manifest = {
            "schema_version": SCHEMA_VERSION,
            "task_id": trace.task.task_id,
            "split": trace.task.split,
            "seed": int(trace.seed),
            "policy_id": trace.policy_id,
            "policy_hash": trace.policy_hash,
            "verifier_id": trace.verifier_id,
            "completed": bool(trace.completed),
            "stop_reason": trace.stop_reason,
            "error": trace.error,
            "artifact_index": "artifacts.json",
            "artifact_index_sha256": _sha256(out / "artifacts.json"),
        }
        _dump_json(out / "manifest.json", manifest)
        return out


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _file_digest(path: Path) -> dict[str, Any]:
    return {"sha256": _sha256(path), "bytes": path.stat().st_size}


def _read_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"cannot read JSON {path.name}: {exc}") from exc


def verify_bundle(bundle_dir: str | Path) -> BundleCheck:
    """Verify hashes, required files and basic row counts without running a world or policy."""
    root = Path(bundle_dir)
    errors: list[str] = []
    files = tuple(sorted(p.name for p in root.iterdir())) if root.is_dir() else ()
    if not root.is_dir():
        return BundleCheck(False, (f"bundle directory does not exist: {root}",), files)
    for name in (*REQUIRED_ARTIFACTS, "artifacts.json", "manifest.json"):
        if not (root / name).is_file():
            errors.append(f"missing {name}")
        elif (root / name).is_symlink():
            errors.append(f"symlink is not a valid evidence artifact: {name}")
    if errors:
        return BundleCheck(False, tuple(errors), files)
    try:
        manifest = _read_json(root / "manifest.json")
        artifacts = _read_json(root / "artifacts.json")
        verdict = _read_json(root / "verdict.json")
        task = _read_json(root / "task.json")
    except ValueError as exc:
        return BundleCheck(False, (str(exc),), files)
    if manifest.get("schema_version") != SCHEMA_VERSION or artifacts.get("schema_version") != SCHEMA_VERSION:
        errors.append("schema_version mismatch")
    if manifest.get("artifact_index") != "artifacts.json":
        errors.append("manifest artifact_index must be artifacts.json")
    if manifest.get("artifact_index_sha256") != _sha256(root / "artifacts.json"):
        errors.append("artifacts.json hash mismatch")
    indexed = artifacts.get("files", {})
    for name in REQUIRED_ARTIFACTS:
        entry = indexed.get(name)
        if not isinstance(entry, Mapping) or entry.get("sha256") != _sha256(root / name):
            errors.append(f"artifact hash mismatch: {name}")
        elif int(entry.get("bytes", -1)) != (root / name).stat().st_size:
            errors.append(f"artifact size mismatch: {name}")
    if not isinstance(task, Mapping) or not task.get("task_id"):
        errors.append("task.json missing task_id")
    if not isinstance(verdict, Mapping) or not isinstance(verdict.get("pass_vector"), Mapping):
        errors.append("verdict.json missing pass_vector")
    for name in ("observations.jsonl", "actions.jsonl", "events.jsonl"):
        line_no = 0
        try:
            for line_no, line in enumerate((root / name).read_text(encoding="utf-8").splitlines(), 1):
                json.loads(line)
        except (OSError, json.JSONDecodeError) as exc:
            errors.append(f"invalid {name} at line {line_no}: {exc}")
    return BundleCheck(not errors, tuple(errors), files)
