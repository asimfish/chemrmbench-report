"""Development detector for the explicit-light candidate; V16 gate is unchanged."""
from __future__ import annotations
import numpy as np


def fixed_light_features(rgb):
    if not isinstance(rgb, np.ndarray) or rgb.dtype != np.uint8 or rgb.shape != (320, 320, 3):
        raise ValueError('expected native uint8 RGB')
    r, g, b = [rgb[:, :, i].astype(float) for i in range(3)]
    band = np.zeros((320,320), dtype=bool)
    band[110:195] = True
    # Channel differences retain hue contrast when tone mapping compresses ratios.
    green = (g-r > 20) & (g-b > 20) & (g > 60) & band
    red = (r-g > 20) & (r-b > 20) & (r > 60) & band
    cols = np.where((red | green).sum(axis=0) >= 2)[0]
    groups = np.split(cols, np.where(np.diff(cols) > 2)[0]+1) if len(cols) else []
    centers = [float(x.mean()) for x in groups if len(x) >= 3]
    slot = None
    if green.sum() >= 12 and len(centers) == 5:
        slot = int(np.argmin(np.abs(np.asarray(centers)-np.where(green)[1].mean())))
    return {'green_slot': slot, 'green_pixels': int(green.sum()), 'marker_count': len(centers)}
