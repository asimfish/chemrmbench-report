"""Prospective loaded-state comparisons against a continuously live control.

The original numeric restoration limits are retained. A moving reference is
aligned by native hold-step index, rather than assumed stationary. These CPU
comparisons alone never admit an archive as a physical restart checkpoint.
"""
import copy
import math

from .legacy_reconstruction.checkpoint_schema import validate_checkpoint
from .reconstruction import compare_state,RestoreLimits,_observed_velocity_check


def validated_robot_bounds(contract,expected_joint_names):
    """Validate the actual per-joint archive schema before simulator startup."""
    bounds=contract.get('robot_state_bounds')
    if type(bounds) is not dict or bounds.get('joint_names')!=list(expected_joint_names):
        raise ValueError('matching archived robot joint names required')
    size=len(expected_joint_names)
    if not 1<=size<=128:raise ValueError('bounded robot joint registry required')
    for key in ('velocity_limit','position_tolerance'):
        values=bounds.get(key)
        if (type(values) is not list or len(values)!=size or
            any(type(v) not in (int,float) or not math.isfinite(v) or
                v<0 or (key=='velocity_limit' and v==0) for v in values)):
            raise ValueError('finite complete per-joint '+key+' required')
    limits=bounds.get('position_limits')
    if (type(limits) is not list or len(limits)!=size or any(
        type(v) is not list or len(v)!=2 or any(type(x) not in (int,float) or not math.isfinite(x) for x in v)
        or v[0]>=v[1] for v in limits)):
        raise ValueError('finite ordered per-joint position limits required')
    return copy.deepcopy(bounds)


def review_hold(source,initial,live,cold,*,expected_entity_ids,scene_has_particles):
    if scene_has_particles is not False:
        raise ValueError('registered rigid comparison cannot cover particles')
    if len(live)!=30 or len(cold)!=30:
        raise ValueError('exactly thirty aligned native hold samples required')
    source=validate_checkpoint(source);initial=validate_checkpoint(initial)
    ids=[r['id'] for group in ('bodies','articulations') for r in source['physics'][group]]
    if (type(expected_entity_ids) not in (list,set,tuple) or
        any(type(v) is not str for v in expected_entity_ids) or
        len(expected_entity_ids)!=len(set(expected_entity_ids)) or
        len(ids)!=len(set(ids)) or set(ids)!=set(expected_entity_ids) or
        not 1<=len(ids)<=512 or source['schema_version']<3):
        raise ValueError('complete registered version3 source state required')
    graph=source['task']['graph_position']
    if type(graph) is not dict or type(graph.get('next_command_index')) is not int:
        raise ValueError('explicit source-command graph required')
    limits=RestoreLimits();start=compare_state(source,initial,limits)
    velocity=_observed_velocity_check(source,initial)
    aligned=[];static=[];source_controls=[]
    for reference,actual in zip(live,cold):
        reference=validate_checkpoint(reference);actual=validate_checkpoint(actual)
        control=True
        for sample in (reference,actual):
            control &= sample['identity']==source['identity'] and sample['task']['graph_position']==graph
            observed={r['id']:r for r in sample['physics']['articulations']}
            for art in source['physics']['articulations']:
                row=observed.get(art['id'])
                control &= row is not None and all(row[k]==art[k] for k in (
                    'joint_position_target','joint_velocity_target','joint_effort_target','runtime_properties'))
        source_controls.append(bool(control))
        aligned.append(compare_state(reference,actual,limits))
        static.append(compare_state(source,actual,limits))
    passed=(start['status']=='PASS' and velocity['status']=='PASS' and all(source_controls)
        and all(r['status']=='PASS' and len(r['entity_errors'])==len(ids) for r in aligned))
    return dict(schema='chemrm-v93-loaded-hold-comparison',
        status='PASS_MATCHED_LIVE_HOLD' if passed else 'FAIL_MATCHED_LIVE_HOLD',
        initial_state=start,initial_velocity=velocity,aligned_samples=aligned,
        static_snapshot_diagnostic=static,source_drive_targets_held=source_controls,
        sample_count=30,entities_each_sample=len(ids),
        reference='CONTINUOUSLY_LIVE_SOURCE_FIXED_DRIVE_TARGETS_AT_SAME_NATIVE_STEP',
        position_limit_m=limits.position_m,orientation_limit_rad=limits.orientation_rad,
        joint_limit_rad=limits.joint_position_rad,static_release_contract_changed=False,
        physical_restart_admitted=False,agent_context_and_task_timer_rebound=False,
        hidden_solver_state_restored=False,scientific_admission=False,training_admission=False)


def compare_next_endpoint(reference,actual):
    """Pose/graph/position-drive comparison under the same gravity controller.

    Gravity-compensation efforts depend on measured joint state and need not
    match bit for bit between trajectories. The original full-state verdict is
    reported separately; it is never silently turned into a PASS.
    """
    reference=validate_checkpoint(reference);actual=validate_checkpoint(actual)
    limits=RestoreLimits();strict=compare_state(reference,actual,limits)
    drives=True
    observed={r['id']:r for r in actual['physics']['articulations']}
    for r in reference['physics']['articulations']:
        row=observed.get(r['id'])
        drives &= row is not None and all(row[k]==r[k] for k in (
            'joint_names','joint_position_target','joint_velocity_target','runtime_properties'))
    poses=all(r['position_m']<=limits.position_m and r['orientation_rad']<=limits.orientation_rad
        and r.get('joint_error_rad',0)<=limits.joint_position_rad and r.get('joint_names_equal',True)
        for r in strict['entity_errors'])
    passed=not strict['registry_errors'] and poses and drives and all(strict['host_checks'].values())
    return dict(status='PASS_MATCHED_NEXT_STAGE_ENDPOINT' if passed else 'FAIL_MATCHED_NEXT_STAGE_ENDPOINT',
        strict_original_state_comparison=strict,position_and_velocity_targets_equal=bool(drives),
        effort_comparison_scope='SAME_NATIVE_GRAVITY_COMPENSATION_PROGRAM_NOT_BITWISE_EFFORT_EQUALITY',
        physical_restart_admitted=False,scientific_admission=False,training_admission=False)
