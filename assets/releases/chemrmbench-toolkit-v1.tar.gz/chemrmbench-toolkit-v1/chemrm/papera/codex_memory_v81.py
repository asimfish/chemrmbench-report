"""Bounded tool-disabled Astra calls for cue memory and resumed skill decisions."""
from pathlib import Path
import json
import os
import shutil
import signal
import subprocess
import time

from .agent_memory_v81 import validate_packet
from .codex_vision_v75 import MODEL,DISABLED
from .staged_collection import digest


def nullable(value):return dict(anyOf=[value,dict(type='null')])
NUMBER=dict(type='number',minimum=0,maximum=1e6)
MEMORY_SCHEMA=dict(type='object',properties=dict(
    observation_sha256=dict(type='string'),cue_color=dict(type='string',enum=['green','amber','unknown']),
    delay_s=nullable(dict(type='number',enum=[10.,16.])),cue_observation_s=nullable(NUMBER),
    cue_clock_id=nullable(dict(type='string'))),
    required=['observation_sha256','cue_color','delay_s','cue_observation_s','cue_clock_id'],additionalProperties=False)
ACTION_SCHEMA=dict(type='object',properties=dict(
    observation_sha256=dict(type='string'),memory_sha256=nullable(dict(type='string')),
    decision=dict(type='string',enum=['schedule','wait','abort']),selected_skill=nullable(dict(type='string',enum=['A1_regrasp_return'])),
    desired_contact_after_resume_s=nullable(dict(type='number',enum=[10.,16.])),
    start_after_resume_s=nullable(dict(type='number',minimum=0,maximum=30)),
    remembered_cue_s=nullable(NUMBER),remembered_cue_clock_id=nullable(dict(type='string'))),
    required=['observation_sha256','memory_sha256','decision','selected_skill','desired_contact_after_resume_s',
              'start_after_resume_s','remembered_cue_s','remembered_cue_clock_id'],additionalProperties=False)
EVENT_MEMORY_SCHEMA=dict(type='object',properties=dict(
    observation_sha256=dict(type='string'),event=dict(type='string',enum=['bottle_lift_observed','unknown']),
    time_bucket=dict(type='string',enum=['early','late','unknown']),
    delay_s=nullable(dict(type='number',enum=[10.,16.])),cue_observation_s=nullable(NUMBER),
    cue_clock_id=nullable(dict(type='string'))),
    required=['observation_sha256','event','time_bucket','delay_s','cue_observation_s','cue_clock_id'],additionalProperties=False)


def invoke(directory,observation,image,*,mode,memory=None,memory_sha256=None,nominal_contact_latency_s=None,timeout_s=60):
    observation=validate_packet(observation)
    if mode not in ('INGEST','READOUT'):raise ValueError('declared memory call mode required')
    if (mode=='INGEST')!=(observation['packet']['phase']=='CUE'):raise ValueError('call mode and public phase disagree')
    image=Path(image)
    if image.suffix.lower() not in ('.jpg','.png') or digest(image)!=observation['packet']['observation']['actor']['images'][0]['sha256']:
        raise ValueError('actual public image does not match the request')
    directory=Path(directory);directory.mkdir(exist_ok=False,parents=True)
    filename='observation'+image.suffix.lower();shutil.copyfile(image,directory/filename)
    if mode=='INGEST':
        text=('Observe only the floating square beacon above the scale, not the colored bottle caps. '
              'Author a compact memory for a later call when this cue image will be unavailable. '
              'Use the public color mapping. Remember the supplied public timestamp and public clock id as cue_observation_s/clock. '
              'If the beacon cannot be identified, choose unknown and null memory values.')
        payload=dict(public_observation=observation)
        schema=MEMORY_SCHEMA
        if observation['packet']['schema']=='chemrm-public-memory-packet-v82':
            text=('Look at the actual laboratory image. If the bottle is being held above the worktop, '
                  'author event=bottle_lift_observed and remember the supplied public observation timestamp and clock id. '
                  'Classify its time bucket with the public 30-second rule and remember the corresponding delay. '
                  'This is not a request to infer a hidden lift-onset timestamp. If the operation is not visible, use unknown and null values.')
            schema=EVENT_MEMORY_SCHEMA
    else:
        text=('The attached image is the current resumed scene; the old cue pixels are not attached. '
              'Use only your supplied semantic memory, if present. No tools, retrieval or hidden state. '
              'Recall the old cue observation time with its original epoch separately. '
              'Schedule only A1_regrasp_return: start_after_resume_s plus the public nominal contact latency '
              'must equal the desired_contact_after_resume_s selected from the remembered color mapping. '
              'The new public resume clock is zero. Do not subtract an old epoch timestamp from it. '
              'If the cue/deadline is unknown, choose wait or abort rather than inventing a past event. '
              'For wait/abort set the skill, contact deadline and start time to null.')
        # No source packet, physical checkpoint, old image or private cue field.
        payload=dict(public_observation=observation,agent_semantic_memory=memory,
            memory_sha256=memory_sha256,public_nominal_contact_latency_s=nominal_contact_latency_s)
        schema=ACTION_SCHEMA
    prompt='Laboratory benchmark actor. No tool calls. Return only schema JSON; observation_sha256 must be the outer supplied public_observation.sha256. Do not claim chemical success.\n'+text+'\n'+json.dumps(payload,allow_nan=False)
    (directory/'prompt.txt').write_text(prompt)
    (directory/'public_request.json').write_text(json.dumps(payload,indent=2,allow_nan=False)+'\n')
    (directory/'schema.json').write_text(json.dumps(schema,indent=2)+'\n')
    command=['codex','exec','--ignore-user-config','--ignore-rules','--ephemeral','--skip-git-repo-check',
        '--model',MODEL,'--sandbox','read-only']
    for feature in DISABLED:command+=['--disable',feature]
    command+=['-c','web_search="disabled"','-c','approval_policy="never"','-c','model_reasoning_effort="low"',
        '-c','features.skip_host_skill_discovery=true','--json','--image',filename,
        '--output-schema','schema.json','--output-last-message','answer.json','-']
    (directory/'command.json').write_text(json.dumps(command,indent=2)+'\n')
    env=dict(os.environ)
    for key in ('LD_LIBRARY_PATH','LD_PRELOAD'):env.pop(key,None)
    before=time.monotonic()
    with (directory/'events.jsonl').open('xb') as output,(directory/'stderr.log').open('xb') as error:
        child=subprocess.Popen(command,cwd=directory,env=env,stdin=subprocess.PIPE,stdout=output,stderr=error,start_new_session=True)
        try:child.communicate(prompt.encode(),timeout=timeout_s)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=3)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
            raise TimeoutError('uncertain request/billing; no automatic retry') from None
    if child.returncode:raise RuntimeError('provider unsuccessful; no automatic retry')
    events=[json.loads(x) for x in (directory/'events.jsonl').read_text().splitlines()]
    if any(e.get('item',{}).get('type') not in (None,'agent_message','reasoning','error') for e in events):
        raise ValueError('provider tool use rejected')
    completed=[e for e in events if e.get('type')=='turn.completed']
    if len(completed)!=1:raise ValueError('unconfirmed provider completion/billing')
    usage=completed[0]['usage'];tokens=usage['input_tokens']+usage['output_tokens']
    if type(tokens) is not int or not 0<=tokens<=16384:raise ValueError('observed request token ceiling exceeded')
    result=dict(answer=json.loads((directory/'answer.json').read_text()),usage=usage,known_billed_tokens=tokens,
        host_elapsed_s=time.monotonic()-before,requested_model=MODEL,backend_model_id=None,
        model_identity_scope='EXPLICIT_CLI_SELECTION_BACKEND_ID_NOT_EXPOSED',tool_calls=0,
        provider_response_observed=True,mode=mode,scientific_admission=False)
    (directory/'receipt.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    return result
