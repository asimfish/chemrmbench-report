"""Run the Paper A F0 core-family reference and write a verifiable evidence bundle."""

from __future__ import annotations

import argparse
import json

from chemrm.papera.core_f0 import CoreFamilyVerifier, CoreFamilyWorld, DyeReferencePolicy, make_core_task
from chemrm.papera.runner import run_episode


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--out", required=True, help="episode evidence directory")
    ap.add_argument("--seed", type=int, default=19)
    ap.add_argument("--stratum", default="M0_relaxed")
    ap.add_argument("--mask", default="none")
    ap.add_argument("--clock", action="store_true", help="declare Track B timestamp channel")
    ap.add_argument("--perturbation", choices=("none", "tick_jitter", "rate_error"), default="none")
    ap.add_argument("--perturbation-level", type=float, default=0.0)
    ap.add_argument("--max-steps", type=int, default=1000)
    args = ap.parse_args(argv)
    if args.stratum != "M0_relaxed" or args.mask != "none":
        raise SystemExit("DyeReferencePolicy is declared only for the M0_relaxed, mask=none smoke run")
    task = make_core_task(args.stratum, args.mask, clock_on=args.clock, seed=args.seed)
    world = CoreFamilyWorld(args.stratum, args.mask, clock_on=args.clock,
                            perturbation=args.perturbation,
                            perturbation_level=args.perturbation_level)
    result = run_episode(task, world, DyeReferencePolicy(), CoreFamilyVerifier(), seed=args.seed,
                         max_steps=args.max_steps, out_dir=args.out)
    print(json.dumps({"bundle": result.bundle_dir, "pass_vector": result.verdict.pass_vector,
                      "failure_vector": result.verdict.failure_vector}, indent=2, sort_keys=True))
    return 0 if result.verdict.pass_vector.get("chem_ssr", False) else 1


if __name__ == "__main__":
    raise SystemExit(main())
