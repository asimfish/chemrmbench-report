"""L2 verifier: prove a task's memory (M) and memory x time claims empirically.

Release discipline (proposal v0.3, section 3.4): a task ships only if scripted
oracle policies on an abstract, physics-free episode model reproduce the
claimed structure. Two checks live here.

1. Aliasing gate (M(0) vs M(>0)).
   memoryless greedy vs ground-truth-memory oracle. The gate is normalized by
   the chance baseline so binary-choice tasks cannot pass by construction:

       normalized_gap = (S_mem - S_none) / (1 - S_none)  >  GATE (0.8)
       AND  S_none <= MAX_CHANCE (0.25)

   The normalized gap measures how much of the recoverable headroom memory
   recovers; it does NOT by itself exclude low-headroom tasks (a two-choice
   task has normalized gap 1.0). The chance ceiling is the second, separate
   condition that rules those out (review round 2, weakness 3). These two
   constants are the ONE formal gate quoted by code, tests and the proposal.

2. Memory-budget ladder (M(k) minimality).
   The oracle is restricted to k retained latent facts, k = 0..K. The
   empirical TMC is the smallest k whose success first exceeds
   LADDER_THRESHOLD x S_full. A task labelled M(n) must show a ladder that
   rises with k; a task labelled M(1) must saturate at k = 1.

Abstractions shipped:
- C1  Colorless Disambiguation: n identical beakers, one latent fact (which
      holds the base); M(1) by construction, chance = 1/n.
- C7  Parallel Samples: n identical tubes, latent facts = the set of tubes
      already treated; M(n-1) by construction (the last tube is forced).
- C13 / core family: delegated to chemrm.core_family, which runs ONE
      stateless decision rule under observation interventions on paired
      episode draws (identity oracle x timing oracle). No per-cell heuristics.
"""

from __future__ import annotations

import random
from dataclasses import dataclass

GATE = 0.8                 # normalized aliasing gap required to pass
MAX_CHANCE = 0.25          # chance ceiling: memoryless success must be <= this
LADDER_THRESHOLD = 0.95    # fraction of full-memory success that defines "solved"


@dataclass(frozen=True)
class AliasingReport:
    task_id: str
    memoryless_success: float
    memory_success: float

    @property
    def chance(self) -> float:
        return self.memoryless_success

    @property
    def normalized_gap(self) -> float:
        denom = 1.0 - self.memoryless_success
        if denom <= 1e-9:
            return 0.0
        return (self.memory_success - self.memoryless_success) / denom

    def passed(self, gate: float = GATE, max_chance: float = MAX_CHANCE) -> bool:
        return self.normalized_gap > gate and self.memoryless_success <= max_chance


@dataclass(frozen=True)
class LadderReport:
    task_id: str
    budgets: tuple[int, ...]
    success: tuple[float, ...]
    claimed_m: int
    step_ci_lower: tuple[float, ...] = ()   # paired-bootstrap 95% lower bound of S_{k+1}-S_k

    @property
    def empirical_m(self) -> int:
        full = self.success[-1]
        for k, s in zip(self.budgets, self.success):
            if s >= LADDER_THRESHOLD * full:
                return k
        return self.budgets[-1]

    def monotone(self, slack: float = 0.02) -> bool:
        """Release gate: no step may decrease beyond `slack` at the CI lower bound."""
        return all(lb >= -slack for lb in self.step_ci_lower)

    def consistent(self) -> bool:
        return self.empirical_m == self.claimed_m and self.monotone()


def paired_bootstrap_lower(a: list[int], b: list[int], resamples: int = 1000,
                           seed: int = 0, alpha: float = 0.05) -> float:
    """Lower bound of the paired bootstrap CI for mean(b) - mean(a)."""
    rng = random.Random(seed)
    n = len(a)
    diffs = [b[i] - a[i] for i in range(n)]
    stats = []
    for _ in range(resamples):
        idx = [rng.randrange(n) for _ in range(n)]
        stats.append(sum(diffs[i] for i in idx) / n)
    stats.sort()
    return stats[int(alpha / 2 * resamples)]


# --------------------------------------------------------------------------
# C1: n visually identical beakers, one holds the base. The cue phase reveals
# the pour target once; in the act phase all beakers project to "clear".
# Latent facts: 1 (index of the base). Budget k>=1 retains it.
# --------------------------------------------------------------------------

def c1_instances(episodes: int, seed: int, n_candidates: int = 5) -> list[int]:
    rng = random.Random(seed)
    return [rng.randrange(n_candidates) for _ in range(episodes)]


def run_c1_outcomes(budget: int, instances: list[int], seed: int,
                    n_candidates: int = 5) -> list[int]:
    """Per-episode outcomes on PRE-DRAWN instances (paired across budgets)."""
    rng = random.Random(f"policy-{seed}")        # policy randomness: one key shared by ALL budgets,
    out = []                                     # distinct from the instance stream
    for base_idx in instances:
        choice = base_idx if budget >= 1 else rng.randrange(n_candidates)
        out.append(int(choice == base_idx))
    return out


def run_c1(budget: int, episodes: int, rng: random.Random, n_candidates: int = 5) -> float:
    inst = c1_instances(episodes, rng.randrange(1 << 30), n_candidates)
    out = run_c1_outcomes(budget, inst, seed=0, n_candidates=n_candidates)
    return sum(out) / len(out)


# --------------------------------------------------------------------------
# C7: n identical tubes must each receive reagent A exactly once. After each
# addition all tubes look identical. The oracle with budget k remembers the
# LAST k tubes it treated (a FIFO of latent facts) and never re-treats a
# remembered tube; forgotten tubes are indistinguishable from untreated ones,
# so it picks uniformly among tubes it does not remember treating.
# Success = every tube treated exactly once within n + slack attempts.
# Latent facts needed for a perfect policy: n - 1 (the last choice is forced).
# --------------------------------------------------------------------------

def run_c7_outcomes(budget: int, episodes: int, seed: int, n_tubes: int = 6,
                    slack: int = 0) -> list[int]:
    """Per-episode outcomes; the episode key seeds the pick stream so that the
    SAME exogenous randomness is replayed for every budget (paired)."""
    out = []
    for ep in range(episodes):
        rng = random.Random((seed, ep))
        treated: set[int] = set()
        fifo: list[int] = []
        ok = True
        for _attempt in range(n_tubes + slack):
            candidates = [i for i in range(n_tubes) if i not in fifo]
            if not candidates:
                break
            pick = rng.choice(candidates)
            if pick in treated:          # double dose: protocol violation
                ok = False
                break
            treated.add(pick)
            if budget > 0:
                fifo.append(pick)
                if len(fifo) > budget:
                    fifo.pop(0)
            if len(treated) == n_tubes:
                break
        out.append(int(ok and len(treated) == n_tubes))
    return out


def run_c7(budget: int, episodes: int, rng: random.Random, n_tubes: int = 6,
           slack: int = 0) -> float:
    out = run_c7_outcomes(budget, episodes, seed=rng.randrange(1 << 30), n_tubes=n_tubes, slack=slack)
    return sum(out) / len(out)


# --------------------------------------------------------------------------
# Public verifier entry points
# --------------------------------------------------------------------------

_LADDER_RUNNERS = {"C1": (run_c1, 1), "C7": (run_c7, 5)}   # runner, claimed M


def _outcomes(task_id: str, budget: int, episodes: int, seed: int) -> list[int]:
    if task_id == "C1":
        return run_c1_outcomes(budget, c1_instances(episodes, seed), seed=seed)
    if task_id == "C7":
        return run_c7_outcomes(budget, episodes, seed=seed)
    raise KeyError(task_id)


def verify_aliasing(task_id: str, episodes: int = 2000, seed: int = 0) -> AliasingReport:
    if task_id == "C13":
        # memory (identity) intervention with the timing oracle FIXED ON, so the
        # gate measures identity recovery only (review round 3, weakness 3)
        from chemrm.core_family import oracle_factorial
        f = oracle_factorial(episodes, seed)
        return AliasingReport(task_id, memoryless_success=f["identity=0,timing=1"],
                              memory_success=f["identity=1,timing=1"])
    _, claimed = _LADDER_RUNNERS[task_id]
    none = _outcomes(task_id, 0, episodes, seed)
    full = _outcomes(task_id, claimed, episodes, seed)
    return AliasingReport(task_id, memoryless_success=sum(none) / len(none),
                          memory_success=sum(full) / len(full))


def verify_ladder(task_id: str, max_budget: int | None = None, episodes: int = 2000,
                  seed: int = 0) -> LadderReport:
    """Ladder on IDENTICAL pre-drawn instances for every budget, with the
    paired-bootstrap lower bound of each step as the monotonicity gate."""
    _, claimed = _LADDER_RUNNERS[task_id]
    K = max_budget if max_budget is not None else claimed + 1
    budgets = tuple(range(K + 1))
    outcomes = [_outcomes(task_id, k, episodes, seed) for k in budgets]
    success = tuple(sum(o) / len(o) for o in outcomes)
    lowers = tuple(paired_bootstrap_lower(outcomes[i], outcomes[i + 1], seed=seed)
                   for i in range(len(outcomes) - 1))
    return LadderReport(task_id, budgets, success, claimed, lowers)
