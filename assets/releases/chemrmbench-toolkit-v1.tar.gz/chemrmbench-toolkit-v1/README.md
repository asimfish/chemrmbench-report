# Reproduce a ChemRMBench contract release

This entry point composes the existing frozen task manifest, controlled world,
frozen reference policy, read-only verifier and evidence bundle. Its current
backends are CPU contracts or an uncalibrated process diagnostic. They do not
claim a complete native benchmark, calibrated chemistry, formal M1 data or training admission.

Install the versions recorded in a delivered toolkit's `requirements.txt`.
From that toolkit's root, run:

```bash
python3 -m chemrm.papera.run_benchmark_release freeze-tasks --seed 19 --out /tmp/chemrm-tasks-demo
python3 -m chemrm.papera.run_benchmark_release run --manifest /tmp/chemrm-tasks-demo --backend task-contract --out /tmp/chemrm-release-demo
python3 -m chemrm.papera.run_benchmark_release verify /tmp/chemrm-release-demo
python3 -m chemrm.papera.run_benchmark_release run --manifest /tmp/chemrm-tasks-demo --backend task-contract --policy abstain --max-steps 3 --out /tmp/chemrm-abstention-demo
```

Every output directory must be new. `run` accepts no split, seed, task count or
novelty-axis override: those belong to the already frozen manifest. All tasks
and the backend are checked before creating output or starting an episode.
The caller selects a registered backend, policy and bounded action budget.
No model, native simulator, training or cloud process is started.

For the existing public graph grammar:

```bash
python3 -m chemrm.papera.run_generate --grammar pilot/paperA/task_grammar_v2.json --split closed --count 12 --seed 19 --manifest-id graph-closed-demo --out /tmp/chemrm-graph-tasks
python3 -m chemrm.papera.run_benchmark_release run --manifest /tmp/chemrm-graph-tasks --backend graph-contract --out /tmp/chemrm-graph-release
```

The complete grammar has 12 closed, 8 compositional-held-out and 4 open **public
graph fixtures**. These labels do not establish physical or learned-policy generalization.

Each release contains:

- `tasks/`: the original frozen `manifest.json` and `tasks.jsonl` bytes.
- `config.json`, `source.json`, `preflight.json`: backend, policy, budgets,
  installed source/dependency identities and evaluated/unevaluated capabilities.
- `episodes/task-NNNNN/`: ordinary task, observations, actions, events, verdict,
  artifact index and manifest, plus terminal `execution.json`. Task IDs are data,
  never filesystem paths.
- `episodes.json`, `summary.json`: task associations, split denominators and
  failure-episode counts recomputed from individual verdicts.
- `INDEX.json`, `COMMITTED.json`: exact file inventory and final commit marker.
  Incomplete output has no successful final marker and is retained for diagnosis.

`verify` reads the copied task manifest, validates installed source/dependencies,
reconstructs every trace, invokes only the independent verifier and recomputes
the complete summary. It constructs no world, policy or process model. Missing,
malformed, nonfinite, duplicated, symlinked or extra evidence is refused.
Resealing file hashes does not make a false summary agree with replay.

An exit code of 0 means the evidence was correctly recorded and verified. A
failed or abstaining episode stays in its denominator and can have correctly
verified evidence. Exit code 2 denotes refused/incomplete release evidence.
Pin the `release_sha256` returned by a trusted producer with
`verify --expected-sha256 DIGEST` when transporting a release. Hashes do not
authenticate a publisher; artifacts must be locally owned and quiescent during checking.
No rollback or migration is needed: older evidence formats and experiments are unchanged.

The existing reconstructed scenes and native videos can be audited separately:

```bash
python3 -m chemrm.papera.run_benchmark_release audit-native --site /path/to/report-checkout --expected-manifest-sha256 TRUSTED_MANIFEST_DIGEST --decode
```

This binds video bytes, decoded frame counts, frame clocks, task-clock offsets,
source-command cursors, original receipts, entity registries and stage archive
digests in the published projection. It does not rerun the original raw physics
reader or confer restart admission. In particular, a stage projection is not a
restartable checkpoint. Native/derived videos remain separately labeled on the
existing benchmark page; ordinary verified cold coverage remains 1/8.

The public scene catalog does not belong to the policy-facing task observation.
Private truth, restoration records and future action traces must stay outside
actor inputs. See `proposal/BENCHMARK_READINESS_CURRENT_cn.md` for the remaining
native, memory, timing, chemistry, split and statistical acceptance work.
